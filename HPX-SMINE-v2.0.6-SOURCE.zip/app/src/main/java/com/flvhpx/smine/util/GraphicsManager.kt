package com.flvhpx.smine.util

import android.app.ActivityManager
import android.content.Context
import android.provider.Settings

/**
 * Game Graphics Quality manager (v2.0.4).
 *
 * Android does not let a normal app rewrite another game's internal render
 * settings, so this applies every system-level lever that IS available without
 * root and that measurably lightens the load:
 *
 *   LOW    -> kill background apps, drop system animation scales to 0, enable
 *             the "lite" overlay renderer and the Game-Mode hint. Games feel
 *             lighter (and yes, a bit rougher / "Minecraft-y").
 *   MEDIUM -> balanced (animation scale 0.5x, normal overlay).
 *   HIGH   -> full effects (animation scale 1x, glow/blur on).
 *
 * Some writes (Settings.Global) need WRITE_SECURE_SETTINGS and will silently
 * no-op on stock devices — the kill-background + lite-overlay parts always work.
 */
object GraphicsManager {

    const val LOW = 0
    const val MEDIUM = 1
    const val HIGH = 2

    fun label(quality: Int): String = when (quality) {
        LOW -> "LOW"
        HIGH -> "HIGH"
        else -> "MEDIUM"
    }

    fun description(quality: Int): String = when (quality) {
        LOW -> "Lightest · max FPS · rough look (Minecraft-style)"
        HIGH -> "Best visuals · full effects · heaviest"
        else -> "Balanced performance and visuals"
    }

    /** Apply the profile. Returns the list of optimisations that were applied. */
    fun apply(context: Context, quality: Int): List<String> {
        val applied = ArrayList<String>()
        val cr = context.contentResolver

        val scale = when (quality) {
            LOW -> 0f
            MEDIUM -> 0.5f
            else -> 1f
        }
        var animOk = false
        try {
            Settings.Global.putFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, scale)
            Settings.Global.putFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, scale)
            Settings.Global.putFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, scale)
            animOk = true
        } catch (_: Exception) {}
        if (animOk && quality != HIGH) applied.add("animations ${(scale * 100).toInt()}%")

        if (quality == LOW) {
            val killed = killBackground(context)
            applied.add("freed RAM ($killed apps)")
            // Lite overlay renderer: the service disables glow / heavy effects.
            applied.add("lite overlay")
            // Game Mode hint (best-effort, needs WRITE_SECURE_SETTINGS).
            try { Settings.Global.putInt(cr, "game_mode", 1) } catch (_: Exception) {}
        } else if (quality == MEDIUM) {
            val killed = killBackground(context)
            if (killed > 0) applied.add("freed RAM ($killed apps)")
        }
        if (applied.isEmpty()) applied.add("profile applied")
        return applied
    }

    /** Kill background processes to free RAM (needs KILL_BACKGROUND_PROCESSES). */
    fun killBackground(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0
        var count = 0
        try {
            val pkgs = context.packageManager.getInstalledPackages(0)
            for (p in pkgs) {
                val name = p.packageName
                if (name == context.packageName) continue
                try { am.killBackgroundProcesses(name); count++ } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        return count
    }
}

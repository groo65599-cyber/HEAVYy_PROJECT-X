package com.flvhpx.smine.ui

import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.flvhpx.smine.MainActivity
import com.flvhpx.smine.R
import com.flvhpx.smine.util.AccountStore
import com.flvhpx.smine.util.Prefs
import com.flvhpx.smine.util.RegistrySync
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Animated loading screen shown before the dashboard.
 */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Make sure an account exists as early as possible.
        AccountStore(this).ensureAccount()
        Prefs(this).splashShown = true

        // Apply any cloud upgrade (from the private developer panel) in the
        // background while the splash animates — never blocks the UI.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try { RegistrySync(applicationContext).sync() } catch (_: Exception) { }
        }

        val logo = findViewById<ImageView>(R.id.splashLogo)
        val ring = findViewById<View>(R.id.splashRing)
        val progress = findViewById<ProgressBar>(R.id.splashProgress)
        val status = findViewById<TextView>(R.id.splashStatus)

        logo.alpha = 0f
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
        ring.animate().rotation(360f).setDuration(2600)
            .setInterpolator(LinearInterpolator()).start()

        val stages = listOf(
            "INITIALIZING GAME SPACE",
            "LOADING OPTIMIZER",
            "CALIBRATING OVERLAY",
            "READY"
        )
        val anim = ValueAnimator.ofInt(0, 100).setDuration(1700)
        anim.addUpdateListener {
            val p = it.animatedValue as Int
            progress.progress = p
            status.text = stages[(p / 26).coerceIn(0, stages.size - 1)]
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }
        })
        anim.start()
    }
}

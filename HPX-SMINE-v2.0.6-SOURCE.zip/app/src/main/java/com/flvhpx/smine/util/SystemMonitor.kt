package com.flvhpx.smine.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Real-time system metrics reader: FPS (via Choreographer), CPU, GPU, RAM,
 * battery level and clock time. All readings are best-effort and never throw.
 */
class SystemMonitor(
    private val context: Context? = null,
    private val onUpdate: (Snapshot) -> Unit
) {

    data class Snapshot(
        val fps: Int,
        val cpu: Float,
        val gpu: Float,
        val ramUsedMb: Int,
        val ramTotalMb: Int,
        val batteryPercent: Int,
        val charging: Boolean,
        val ping: Int,
        val time: String
    ) {
        val ramPercent: Int
            get() = if (ramTotalMb <= 0) 0 else (ramUsedMb * 100 / ramTotalMb)
    }

    private val main = Handler(Looper.getMainLooper())
    private var running = false

    private val cpuReader = CpuReader()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    // Live ping (ICMP to a public host), refreshed on a background thread.
    @Volatile private var pingMs = -1
    private var pingThread: Thread? = null

    // FPS counters
    private var frames = 0
    private var lastFpsTime = 0L
    private var currentFps = 0

    private val choreographer: Choreographer by lazy { Choreographer.getInstance() }

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            frames++
            val now = System.currentTimeMillis()
            if (lastFpsTime == 0L) lastFpsTime = now
            if (now - lastFpsTime >= 1000) {
                currentFps = frames
                frames = 0
                lastFpsTime = now
            }
            choreographer.postFrameCallback(this)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            val cpu = cpuReader.read()
            val gpu = GpuReader.read()
            val (used, total) = readRam()
            val (bat, charging) = readBattery()
            onUpdate(
                Snapshot(
                    currentFps, cpu, gpu, used, total,
                    bat, charging, pingMs, timeFmt.format(Date())
                )
            )
            main.postDelayed(this, 1000)
        }
    }

    fun start() {
        if (running) return
        running = true
        lastFpsTime = 0L
        frames = 0
        choreographer.postFrameCallback(frameCallback)
        main.post(ticker)
        startPing()
    }

    fun stop() {
        running = false
        choreographer.removeFrameCallback(frameCallback)
        main.removeCallbacks(ticker)
        pingThread?.interrupt()
        pingThread = null
    }

    // ---------------- PING ----------------
    private fun startPing() {
        if (pingThread != null) return
        pingThread = Thread {
            while (running) {
                pingMs = doPing()
                try { Thread.sleep(3000) } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun doPing(): Int {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("ping", "-c", "1", "-W", "1", "8.8.8.8"))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            Regex("time=([0-9.]+)").find(out)?.groupValues?.get(1)?.toFloatOrNull()?.toInt() ?: -1
        } catch (_: Exception) {
            -1
        }
    }

    // ---------------- CPU ----------------
    private class CpuReader {
        private var lastTotal = 0L
        private var lastIdle = 0L

        fun read(): Float {
            return try {
                val line = File("/proc/stat").readLines()
                    .firstOrNull { it.startsWith("cpu ") } ?: return 0f
                val p = line.trim().split(Regex("\\s+"))
                val idle = p[4].toLong() + (p.getOrNull(5)?.toLongOrNull() ?: 0L)
                var total = 0L
                for (i in 1 until p.size) total += p[i].toLongOrNull() ?: 0L
                val dTotal = total - lastTotal
                val dIdle = idle - lastIdle
                lastTotal = total
                lastIdle = idle
                if (dTotal <= 0) 0f else (((dTotal - dIdle).toFloat() / dTotal) * 100f)
                    .coerceIn(0f, 100f)
            } catch (e: Exception) {
                0f
            }
        }
    }

    // ---------------- GPU ----------------
    private object GpuReader {
        private val busyPaths = listOf(
            "/sys/class/kgsl/kgsl-3d0/gpubusy",
            "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",
            "/sys/class/devfreq/gpufreq/load",
            "/sys/kernel/gpu/gpu_busy",
            "/sys/class/misc/mali0/device/utilization",
            "/sys/devices/platform/mali.0/utilization",
            "/sys/devices/platform/soc/*.mali/utilization"
        )

        fun read(): Float {
            try {
                val f = File("/sys/class/kgsl/kgsl-3d0/gpubusy")
                if (f.exists()) {
                    val parts = f.readText().trim().split(Regex("\\s+"))
                    if (parts.size >= 2) {
                        val busy = parts[0].toFloatOrNull() ?: return -1f
                        val total = parts[1].toFloatOrNull() ?: return -1f
                        if (total > 0) return (busy / total * 100f).coerceIn(0f, 100f)
                    }
                }
            } catch (_: Exception) {}

            for (path in busyPaths) {
                try {
                    val f = File(path)
                    if (f.exists() && f.canRead()) {
                        val txt = f.readText().trim().replace("%", "")
                        val v = txt.toFloatOrNull() ?: continue
                        return if (v <= 1f && v > 0f) v * 100f else v.coerceIn(0f, 100f)
                    }
                } catch (_: Exception) {}
            }
            return -1f // unavailable
        }
    }

    // ---------------- RAM ----------------
    private fun readRam(): Pair<Int, Int> {
        return try {
            val lines = File("/proc/meminfo").readLines()
            fun value(key: String): Long {
                val l = lines.firstOrNull { it.startsWith(key) } ?: return 0
                return l.replace(Regex("[^0-9]"), "").toLongOrNull() ?: 0
            }
            val totalKb = value("MemTotal")
            val availKb = value("MemAvailable")
            val usedKb = totalKb - availKb
            Pair((usedKb / 1024).toInt(), (totalKb / 1024).toInt())
        } catch (e: Exception) {
            Pair(0, 0)
        }
    }

    // ---------------- Battery ----------------
    private fun readBattery(): Pair<Int, Boolean> {
        return try {
            val ctx = context ?: return Pair(-1, false)
            val intent: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
            Pair(pct, charging)
        } catch (e: Exception) {
            Pair(-1, false)
        }
    }
}

package com.flvhpx.smine.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.flvhpx.smine.model.Crosshair

/**
 * Renders a configurable crosshair. Used both in the editor preview and as an
 * on-screen overlay above games. Supports shape, color, size, gap, thickness,
 * transparency (alpha), position offset and glow.
 */
class CrosshairView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var style: Int = Crosshair.STYLE_CROSS_DOT
    var color: Int = Color.parseColor("#00FF88")
    var sizePx: Float = 42f
    var gapPx: Float = 8f
    var thicknessPx: Float = 3f
    var dot: Boolean = true
    var glow: Boolean = true

    /** 10..100 (%) */
    var alphaPct: Int = 100

    /** offset from center in px */
    var offsetX: Float = 0f
    var offsetY: Float = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        style = Paint.Style.STROKE
    }

    fun applyConfig(
        s: Int, c: Int, size: Float, gap: Float, thick: Float,
        d: Boolean, g: Boolean, alpha: Int = 100, offX: Float = 0f, offY: Float = 0f
    ) {
        style = s; color = c; sizePx = size; gapPx = gap; thicknessPx = thick
        dot = d; glow = g; alphaPct = alpha.coerceIn(10, 100)
        offsetX = offX; offsetY = offY
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f + offsetX
        val cy = height / 2f + offsetY
        val s = sizePx
        val g = gapPx
        val t = thicknessPx

        val a = (alphaPct * 255 / 100).coerceIn(0, 255)

        paint.color = color
        paint.strokeWidth = t
        paint.style = Paint.Style.STROKE
        paint.alpha = a

        if (glow) {
            glowPaint.color = color
            glowPaint.style = Paint.Style.STROKE
            // Outer soft halo (wide, faint) ...
            glowPaint.strokeWidth = t + 11f
            glowPaint.alpha = (a * 28 / 255).coerceIn(0, 255)
            drawShape(canvas, cx, cy, s, g, t, glowPaint)
            // ... plus a tighter, brighter inner halo for a neon look.
            glowPaint.strokeWidth = t + 5f
            glowPaint.alpha = (a * 75 / 255).coerceIn(0, 255)
            drawShape(canvas, cx, cy, s, g, t, glowPaint)
        }
        drawShape(canvas, cx, cy, s, g, t, paint)
    }

    private fun drawShape(canvas: Canvas, cx: Float, cy: Float, s: Float, g: Float, t: Float, p: Paint) {
        when (style) {
            Crosshair.STYLE_CROSS -> drawCross(canvas, cx, cy, s, g, p)
            Crosshair.STYLE_DOT -> drawDot(canvas, cx, cy, t, p)
            Crosshair.STYLE_CIRCLE -> drawCircle(canvas, cx, cy, s, p)
            Crosshair.STYLE_CROSS_DOT -> {
                drawCross(canvas, cx, cy, s, g, p); drawDot(canvas, cx, cy, t, p)
            }
            Crosshair.STYLE_CROSS_CIRCLE -> {
                drawCross(canvas, cx, cy, s, g, p); drawCircle(canvas, cx, cy, s * 0.7f, p)
            }
            Crosshair.STYLE_T -> drawT(canvas, cx, cy, s, g, p)
            Crosshair.STYLE_X -> drawX(canvas, cx, cy, s, g, p)
            Crosshair.STYLE_BRACKETS -> drawBrackets(canvas, cx, cy, s, g, p)
            Crosshair.STYLE_CHEVRON -> drawChevron(canvas, cx, cy, s, g, p)
            Crosshair.STYLE_DOT_RING -> {
                drawDot(canvas, cx, cy, t, p); drawCircle(canvas, cx, cy, s * 0.75f, p)
            }
            else -> drawCross(canvas, cx, cy, s, g, p)
        }
    }

    private fun drawCross(c: Canvas, cx: Float, cy: Float, s: Float, g: Float, p: Paint) {
        c.drawLine(cx, cy - g, cx, cy - g - s, p)
        c.drawLine(cx, cy + g, cx, cy + g + s, p)
        c.drawLine(cx - g, cy, cx - g - s, cy, p)
        c.drawLine(cx + g, cy, cx + g + s, cy, p)
    }

    private fun drawDot(c: Canvas, cx: Float, cy: Float, t: Float, p: Paint) {
        val old = p.style
        p.style = Paint.Style.FILL
        c.drawCircle(cx, cy, (t * 1.4f).coerceAtLeast(2f), p)
        p.style = old
    }

    private fun drawCircle(c: Canvas, cx: Float, cy: Float, r: Float, p: Paint) {
        c.drawCircle(cx, cy, r, p)
    }

    private fun drawT(c: Canvas, cx: Float, cy: Float, s: Float, g: Float, p: Paint) {
        c.drawLine(cx, cy - g, cx, cy - g - s, p)
        c.drawLine(cx - g, cy, cx - g - s, cy, p)
        c.drawLine(cx + g, cy, cx + g + s, cy, p)
    }

    private fun drawX(c: Canvas, cx: Float, cy: Float, s: Float, g: Float, p: Paint) {
        val o = g * 0.7071f
        val e = s * 0.7071f
        c.drawLine(cx - o, cy - o, cx - o - e, cy - o - e, p)
        c.drawLine(cx + o, cy + o, cx + o + e, cy + o + e, p)
        c.drawLine(cx + o, cy - o, cx + o + e, cy - o - e, p)
        c.drawLine(cx - o, cy + o, cx - o - e, cy + o + e, p)
    }

    private fun drawBrackets(c: Canvas, cx: Float, cy: Float, s: Float, g: Float, p: Paint) {
        val len = s
        val d = g
        c.drawLine(cx - d, cy - d, cx - d - len, cy - d, p)
        c.drawLine(cx - d, cy - d, cx - d, cy - d - len, p)
        c.drawLine(cx + d, cy - d, cx + d + len, cy - d, p)
        c.drawLine(cx + d, cy - d, cx + d, cy - d - len, p)
        c.drawLine(cx - d, cy + d, cx - d - len, cy + d, p)
        c.drawLine(cx - d, cy + d, cx - d, cy + d + len, p)
        c.drawLine(cx + d, cy + d, cx + d + len, cy + d, p)
        c.drawLine(cx + d, cy + d, cx + d, cy + d + len, p)
    }

    private fun drawChevron(c: Canvas, cx: Float, cy: Float, s: Float, g: Float, p: Paint) {
        val rect = RectF(cx - s, cy - s, cx + s, cy + s)
        val inset = g
        val r2 = RectF(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset)
        c.drawLine(cx - s * 0.5f, cy - g - s * 0.4f, cx, cy - g, p)
        c.drawLine(cx, cy - g, cx + s * 0.5f, cy - g - s * 0.4f, p)
        c.drawLine(cx - s * 0.5f, cy + g + s * 0.4f, cx, cy + g, p)
        c.drawLine(cx, cy + g, cx + s * 0.5f, cy + g + s * 0.4f, p)
        c.drawLine(cx - g - s * 0.4f, cy - s * 0.5f, cx - g, cy, p)
        c.drawLine(cx - g, cy, cx - g - s * 0.4f, cy + s * 0.5f, p)
        c.drawLine(cx + g + s * 0.4f, cy - s * 0.5f, cx + g, cy, p)
        c.drawLine(cx + g, cy, cx + g + s * 0.4f, cy + s * 0.5f, p)
    }
}

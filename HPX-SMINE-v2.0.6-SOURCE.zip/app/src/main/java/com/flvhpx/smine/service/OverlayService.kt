package com.flvhpx.smine.service

import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.model.Crosshair
import com.flvhpx.smine.util.ClearCacheManager
import com.flvhpx.smine.util.EnergyManager
import com.flvhpx.smine.util.GraphicsManager
import com.flvhpx.smine.util.MacroManager
import com.flvhpx.smine.util.Notifications
import com.flvhpx.smine.util.Permissions
import com.flvhpx.smine.util.Prefs
import com.flvhpx.smine.util.SystemMonitor
import com.flvhpx.smine.view.CrosshairView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The heart of HPX SMINE: a foreground service that renders the crosshair,
 * the real-time ROG-style lifetime monitor, the right-edge swipe handle and the
 * ROG / Armoury-Crate style side panel on top of any running game.
 *
 * v2.0.4 note: every overlay window now carries FLAG_NOT_TOUCH_MODAL so touches
 * outside a window's bounds fall through to the game behind it. The crosshair
 * view is non-clickable, so the whole screen stays touchable while the crosshair
 * is active (fixes the "screen can't be touched when crosshair is on" bug).
 * The edge handle now lives on the LEFT edge and is enlarged for visibility.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_RELOAD = "hpx.overlay.RELOAD"
        const val ACTION_TOGGLE_PANEL = "hpx.overlay.TOGGLE_PANEL"
        const val ACTION_SHOW_LOGIN = "hpx.overlay.SHOW_LOGIN"

        fun start(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun reload(ctx: Context) {
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_RELOAD))
        }

        fun togglePanel(ctx: Context) {
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_TOGGLE_PANEL))
        }

        fun showLogin(ctx: Context) {
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_SHOW_LOGIN))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var monitor: SystemMonitor? = null

    private var crosshair: CrosshairView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null
    private var monitorView: View? = null
    private var monitorParams: WindowManager.LayoutParams? = null
    private var handle: View? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var panelRoot: View? = null
    private var loginView: View? = null
    private var dock: View? = null
    private var wakeLock: PowerManager.WakeLock? = null

    // Macro recording state
    private var macroCapture: View? = null
    private var macroStopBtn: View? = null
    private var macroFab: View? = null
    private var macroFabParams: WindowManager.LayoutParams? = null
    private var macroFabExpanded = false
    private var macroRecording = false
    private val macroSteps = ArrayList<MacroManager.Step>()

    // Floating browser (mini window)
    private var floatBrowser: View? = null
    private var floatBrowserParams: WindowManager.LayoutParams? = null

    // Screen dim (brightness fallback)
    private var dimView: View? = null

    // Floating game timer
    private var gameTimer: View? = null
    private var timerStart = 0L
    private var timerAccum = 0L
    private var timerRunning = false

    private val density get() = resources.displayMetrics.density

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        prefs = Prefs(this)
        Notifications.ensureChannels(this)
        ensureForeground()
        acquireWakeLock()
        buildAll()
        if (prefs.loginAnimEnabled) handler.postDelayed({ showLoginAnim() }, 350)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RELOAD -> rebuild()
            ACTION_TOGGLE_PANEL -> togglePanel()
            ACTION_SHOW_LOGIN -> showLoginAnim()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Keep-alive: relaunch the overlay if the user swipes the app away.
        try {
            val restart = Intent(applicationContext, OverlayService::class.java)
            val pi = PendingIntent.getService(
                this, 4711, restart,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, pi)
        } catch (_: Exception) {}
    }

    private fun ensureForeground() {
        val n = Notifications.build(
            this, Notifications.CH_OVERLAY,
            "HPX SMINE is running", "Overlay active \u00b7 swipe from right edge",
            Notifications.ID_OVERLAY
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                Notifications.ID_OVERLAY, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(Notifications.ID_OVERLAY, n)
        }
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HPX:overlay")
            wakeLock?.setReferenceCounted(false)
            wakeLock?.acquire(6 * 60 * 60 * 1000L) // max 6h, auto-released
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------
    //  Build / rebuild
    // ------------------------------------------------------------------
    private fun buildAll() {
        if (prefs.crosshairEnabled) addCrosshair()
        if (prefs.monitorEnabled) addMonitor()
        if (prefs.edgePanelEnabled) addEdgeHandle()
        addDock()
        if (prefs.macroEnabled) addMacroFab()
        if (prefs.floatBrowserEnabled) addFloatBrowser()
        if (prefs.gameTimerEnabled) addGameTimer()
        applyDim()
    }

    private fun rebuild() {
        removeCrosshair(); removeMonitor(); removeEdgeHandle(); removeDock()
        removeMacroFab(); removeFloatBrowser(); removeGameTimer()
        closePanel(immediate = true)
        buildAll()
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ------------------------------------------------------------------
    //  Crosshair
    // ------------------------------------------------------------------
    private fun addCrosshair() {
        if (crosshair != null) return
        // IMPORTANT (v2.0.5 fix): the crosshair window is a SMALL BOX around the
        // crosshair itself — NOT a full-screen window. A full-screen overlay can
        // be treated as "obscuring" by several OEM ROMs (MIUI/HyperOS, OneUI,
        // ColorOS...) which then block EVERY touch to the game underneath, even
        // when the window is FLAG_NOT_TOUCHABLE. A tiny non-touchable box never
        // triggers that protection, so the screen stays fully touchable.
        val v = CrosshairView(this).apply {
            isClickable = false
            isFocusable = false
            isLongClickable = false
        }
        applyCrosshairConfigTo(v)
        val box = crosshairBoxPx()
        val dm = resources.displayMetrics
        val cx = dm.widthPixels / 2f + prefs.crosshairOffsetX * density
        val cy = dm.heightPixels / 2f + prefs.crosshairOffsetY * density
        val lp = WindowManager.LayoutParams(
            box, box,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (cx - box / 2f).toInt()
        lp.y = (cy - box / 2f).toInt()
        try { wm.addView(v, lp); crosshair = v; crosshairParams = lp } catch (_: Exception) {}
    }

    /** Small square that just fits the crosshair (size + gap + thickness + glow). */
    private fun crosshairBoxPx(): Int {
        val size = prefs.crosshairSize * density
        val gap = prefs.crosshairGap * density
        val thick = prefs.crosshairThickness * density
        val half = size + gap + thick + 20f * density
        return (half * 2f).toInt().coerceIn((140 * density).toInt(), (520 * density).toInt())
    }

    private fun applyCrosshairConfigTo(v: CrosshairView) {
        // The window itself is positioned at the offset, so the view draws at its
        // own centre (offset 0).
        v.applyConfig(
            prefs.crosshairStyle, prefs.crosshairColor,
            prefs.crosshairSize * density, prefs.crosshairGap * density,
            prefs.crosshairThickness * density, prefs.crosshairDot,
            prefs.crosshairGlow && !prefs.graphicsLiteOverlay,
            prefs.crosshairAlpha,
            0f, 0f
        )
    }

    /** Live-update the crosshair while the user drags sliders in the panel. */
    private fun updateCrosshairLive() {
        val v = crosshair
        if (v != null) {
            applyCrosshairConfigTo(v)
            repositionCrosshair()
        } else if (prefs.crosshairEnabled) addCrosshair()
    }

    private fun repositionCrosshair() {
        val v = crosshair ?: return
        val lp = crosshairParams ?: return
        val box = crosshairBoxPx()
        val dm = resources.displayMetrics
        val cx = dm.widthPixels / 2f + prefs.crosshairOffsetX * density
        val cy = dm.heightPixels / 2f + prefs.crosshairOffsetY * density
        lp.width = box; lp.height = box
        lp.x = (cx - box / 2f).toInt()
        lp.y = (cy - box / 2f).toInt()
        safeUpdate(v, lp)
    }

    private fun refreshCrosshair() {
        removeCrosshair()
        if (prefs.crosshairEnabled) addCrosshair()
    }

    private fun removeCrosshair() {
        crosshair?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        crosshair = null; crosshairParams = null
    }

    // ------------------------------------------------------------------
    //  ROG-style lifetime monitor
    // ------------------------------------------------------------------
    private fun addMonitor() {
        if (monitorView != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_monitor, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        applyMonitorGravity(lp)
        try { wm.addView(v, lp); monitorView = v; monitorParams = lp } catch (_: Exception) {}
        applyMonitorVisibility(v)
        attachMonitorTouch(v, lp)

        val m = SystemMonitor(this) { s ->
            v.findViewById<TextView>(R.id.txtFps)?.text = "${s.fps}"
            v.findViewById<TextView>(R.id.txtCpu)?.text = "${s.cpu.roundToInt()}%"
            v.findViewById<TextView>(R.id.txtGpu)?.text =
                if (s.gpu < 0f) "N/A" else "${s.gpu.roundToInt()}%"
            v.findViewById<TextView>(R.id.txtRam)?.text =
                String.format("%.1fG", s.ramUsedMb / 1024f)
            v.findViewById<TextView>(R.id.txtBattery)?.text =
                if (s.batteryPercent < 0) "--" else "${s.batteryPercent}%"
            v.findViewById<TextView>(R.id.txtPing)?.text =
                if (s.ping < 0) "--" else "${s.ping}"
            v.findViewById<TextView>(R.id.txtTime)?.text = s.time
        }
        monitor = m
        m.start()
    }

    private fun applyMonitorVisibility(v: View) {
        val expanded = prefs.monitorExpanded
        fun vis(id: Int, on: Boolean) {
            v.findViewById<View>(id)?.visibility = if (on) View.VISIBLE else View.GONE
        }
        vis(R.id.rowFps, prefs.monitorShowFps)
        vis(R.id.rowCpu, expanded && prefs.monitorShowCpu)
        vis(R.id.rowGpu, expanded && prefs.monitorShowGpu)
        vis(R.id.rowRam, expanded && prefs.monitorShowRam)
        vis(R.id.rowBattery, expanded && prefs.monitorShowBattery)
        vis(R.id.rowPing, prefs.monitorShowPing)
        vis(R.id.rowTime, prefs.monitorShowTime)
    }

    private fun applyMonitorGravity(lp: WindowManager.LayoutParams) {
        val m = (density * 10).toInt()
        if (prefs.monitorX >= 0 && prefs.monitorY >= 0) {
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = prefs.monitorX
            lp.y = prefs.monitorY
            return
        }
        when (prefs.monitorPosition) {
            0 -> { lp.gravity = Gravity.TOP or Gravity.START; lp.x = m; lp.y = m }
            1 -> { lp.gravity = Gravity.TOP or Gravity.END; lp.x = m; lp.y = m }
            2 -> { lp.gravity = Gravity.BOTTOM or Gravity.START; lp.x = m; lp.y = m }
            else -> { lp.gravity = Gravity.BOTTOM or Gravity.END; lp.x = m; lp.y = m }
        }
    }

    private fun attachMonitorTouch(v: View, lp: WindowManager.LayoutParams) {
        val plus = v.findViewById<View>(R.id.btnMonitorPlus) ?: return
        var lastX = 0f; var lastY = 0f
        var downX = 0f; var downY = 0f
        var moved = false
        val slop = (density * 6).toInt()

        plus.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX; lastY = e.rawY
                    downX = e.rawX; downY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > slop || abs(e.rawY - downY) > slop) moved = true
                    lp.x += (e.rawX - lastX).toInt()
                    lp.y += (e.rawY - lastY).toInt()
                    lastX = e.rawX; lastY = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.monitorX = lp.x
                        prefs.monitorY = lp.y
                    } else {
                        prefs.monitorExpanded = !prefs.monitorExpanded
                        applyMonitorVisibility(v)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshMonitor() {
        removeMonitor()
        if (prefs.monitorEnabled) addMonitor()
    }

    private fun refreshMonitorVisibility() {
        monitorView?.let { applyMonitorVisibility(it) }
    }

    private fun repositionMonitor() {
        val v = monitorView ?: return
        val lp = monitorParams ?: return
        applyMonitorGravity(lp)
        safeUpdate(v, lp)
    }

    private fun removeMonitor() {
        monitor?.stop(); monitor = null
        monitorView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        monitorView = null; monitorParams = null
    }

    // ------------------------------------------------------------------
    //  Right-edge handle
    // ------------------------------------------------------------------
    private fun addEdgeHandle() {
        if (handle != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_edge_handle, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        // Red-Corner style: pinned to the TOP-LEFT corner (not the middle).
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = if (prefs.edgeY > 0) prefs.edgeY else (density * 150).toInt()
        try { wm.addView(v, lp); handle = v; handleParams = lp } catch (_: Exception) {}
        attachHandleTouch(v, lp)
    }

    private fun removeEdgeHandle() {
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null; handleParams = null
    }

    private fun attachHandleTouch(v: View, lp: WindowManager.LayoutParams) {
        var downX = 0f; var downY = 0f
        var startY = 0; var moved = false
        val slop = (density * 6).toInt()
        val openThreshold = (density * 24).toInt()

        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startY = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (abs(dy) > abs(dx)) {
                        lp.y = (startY + dy.toInt()).coerceAtLeast(0)
                        safeUpdate(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - downX
                    // v2.0.5: open the panel with a SWIPE to the right (no tap).
                    if (dx > openThreshold) {
                        openPanel()
                    } else if (moved) {
                        prefs.edgeY = lp.y
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------------
    //  ROG / Armoury-Crate style side panel
    // ------------------------------------------------------------------
    private fun togglePanel() { if (panel == null) openPanel() else closePanel() }

    private fun panelWidth(): Int {
        val screenW = resources.displayMetrics.widthPixels
        return minOf((density * 340).toInt(), (screenW * 0.9f).toInt())
    }

    private fun openPanel() {
        if (panel != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_side_panel, null)
        val lp = WindowManager.LayoutParams(
            panelWidth(),
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            // NOT full-screen: only the panel width is covered, so the game
            // underneath stays touchable everywhere else. FLAG_NOT_TOUCH_MODAL
            // guarantees taps outside the panel bounds fall through to the game.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(v, lp); panel = v } catch (_: Exception) { return }

        val root = v.findViewById<View>(R.id.panelRoot)
        panelRoot = root
        bindPanel(v)
        attachPanelGestures(v, root)

        root.post {
            root.translationX = -root.width.toFloat()
            root.animate().translationX(0f).setDuration(240)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closePanel(immediate: Boolean = false) {
        val v = panel ?: return
        val root = panelRoot
        if (immediate || root == null) {
            try { wm.removeView(v) } catch (_: Exception) {}
            panel = null; panelRoot = null
            return
        }
        root.animate().translationX(-root.width.toFloat()).setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                try { wm.removeView(v) } catch (_: Exception) {}
                if (panel === v) { panel = null; panelRoot = null }
            }.start()
    }

    private fun attachPanelGestures(v: View, root: View) {
        var downX = 0f; var dragging = false
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; dragging = false; false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    if (dx < 0) {
                        dragging = true
                        root.translationX = dx
                    }
                    dragging
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging && root.translationX < -root.width / 4f) {
                        closePanel()
                    } else if (dragging) {
                        root.animate().translationX(0f).setDuration(160).start()
                    }
                    dragging
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------------
    //  Panel content
    // ------------------------------------------------------------------
    private enum class PanelView { MAIN, CROSSHAIR, MONITOR, MACRO }

    private fun showPanelView(v: View, which: PanelView) {
        v.findViewById<View>(R.id.panelMain)?.visibility =
            if (which == PanelView.MAIN) View.VISIBLE else View.GONE
        v.findViewById<View>(R.id.panelCrosshair)?.visibility =
            if (which == PanelView.CROSSHAIR) View.VISIBLE else View.GONE
        v.findViewById<View>(R.id.panelMonitor)?.visibility =
            if (which == PanelView.MONITOR) View.VISIBLE else View.GONE
        v.findViewById<View>(R.id.panelMacro)?.visibility =
            if (which == PanelView.MACRO) View.VISIBLE else View.GONE
    }

    private fun bindPanel(v: View) {
        v.findViewById<View>(R.id.btnClosePanel)?.setOnClickListener { closePanel() }

        val em = EnergyManager(this)
        v.findViewById<TextView>(R.id.txtTierBadge)?.text =
            when {
                prefs.isDeveloper() -> "DEVELOPER"
                prefs.isPremiumTier() -> "PREMIUM"
                else -> "FREE"
            }
        v.findViewById<TextView>(R.id.txtAppQuota)?.text =
            if (prefs.isPremiumTier()) "PREMIUM \u221E" else "FREE 3"

        setupBrightness(v)
        setupVolume(v)
        setupQuickActions(v)
        setupAppShortcuts(v)
        setupCrosshairPanel(v)
        setupMonitorPanel(v)
        setupMacroPanel(v)
        showPanelView(v, PanelView.MAIN)
    }

    // ----- Brightness -----
    private fun setupBrightness(v: View) {
        val seek = v.findViewById<SeekBar>(R.id.seekBrightness) ?: return
        val txt = v.findViewById<TextView>(R.id.txtBrightness)
        val canWrite = Permissions.canWriteSettings(this)
        // Force manual mode so writes are honoured (fixes "only decreases" bug).
        if (canWrite) {
            try {
                Settings.System.putInt(
                    contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
            } catch (_: Exception) {}
        }

        val cur = Permissions.getSystemBrightness(this).coerceIn(0, 255)
        seek.progress = cur
        txt?.text = "${cur * 100 / 255}%"

        fun apply(p: Int) {
            txt?.text = "${p * 100 / 255}%"
            if (canWrite) {
                Permissions.setSystemBrightness(this@OverlayService, p)
            } else {
                // No WRITE_SETTINGS permission → drive the dim overlay instead so
                // the slider ALWAYS has a visible effect (v2.0.5 fix).
                prefs.dimLevel = ((255 - p) * 70 / 255).coerceIn(0, 90)
                applyDim()
            }
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) apply(p) else txt?.text = "${p * 100 / 255}%"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        v.findViewById<View>(R.id.btnBrightMinus)?.setOnClickListener {
            val np = (seek.progress - 25).coerceIn(0, 255)
            seek.progress = np; apply(np)
        }
        v.findViewById<View>(R.id.btnBrightPlus)?.setOnClickListener {
            val np = (seek.progress + 25).coerceIn(0, 255)
            seek.progress = np; apply(np)
        }
        // Show a "grant" button only when the permission is missing.
        v.findViewById<View>(R.id.btnBrightGrant)?.apply {
            visibility = if (canWrite) View.GONE else View.VISIBLE
            setOnClickListener { Permissions.requestWriteSettings(this@OverlayService) }
        }
        // Night-mode dim toggle (works with or without the permission).
        v.findViewById<View>(R.id.chipDim)?.apply {
            isSelected = prefs.dimLevel > 0
            setOnClickListener { chip ->
                prefs.dimLevel = if (prefs.dimLevel > 0) 0 else 55
                chip.isSelected = prefs.dimLevel > 0
                applyDim()
            }
        }
    }

    // ----- Volume -----
    private fun setupVolume(v: View) {
        val seek = v.findViewById<SeekBar>(R.id.seekVolume) ?: return
        val txt = v.findViewById<TextView>(R.id.txtVolume)
        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

        fun write(progress: Int) {
            val vol = (progress * maxV / 100f).roundToInt().coerceIn(0, maxV)
            try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0) } catch (_: Exception) {}
            txt?.text = "$progress%"
        }

        val curP = (audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / maxV).coerceIn(0, 100)
        seek.progress = curP
        txt?.text = "$curP%"

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) write(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        v.findViewById<View>(R.id.btnVolMinus)?.setOnClickListener {
            val np = (seek.progress - 10).coerceIn(0, 100)
            seek.progress = np; write(np)
        }
        v.findViewById<View>(R.id.btnVolPlus)?.setOnClickListener {
            val np = (seek.progress + 10).coerceIn(0, 100)
            seek.progress = np; write(np)
        }
    }

    // ----- Quick actions -----
    private fun setupQuickActions(v: View) {
        val grid = v.findViewById<GridLayout>(R.id.quickGrid) ?: return
        grid.removeAllViews()
        val gap = (density * 8).toInt()

        addQuickAction(grid, R.drawable.ic_screenshot, "Shot", 0, gap) {
            if (!ScreenCaptureManager.isReady()) toast("Enable screen capture in app first")
            else ScreenCaptureService.screenshot(this)
        }
        addQuickAction(grid, R.drawable.ic_record, "Record", 1, gap) {
            if (!ScreenCaptureManager.isReady()) toast("Enable screen capture in app first")
            else ScreenCaptureService.startRecord(this)
        }
        addQuickAction(grid, R.drawable.ic_stop, "Stop", 2, gap) {
            ScreenCaptureService.stopRecord(this)
        }
        // Cross / Monitor now OPEN their settings sub-panel instead of toggling off.
        addQuickAction(grid, R.drawable.ic_crosshair, "Cross", 3, gap) {
            syncCrosshairPanel(v)
            showPanelView(v, PanelView.CROSSHAIR)
        }
        addQuickAction(grid, R.drawable.ic_monitor, "Monitor", 4, gap) {
            syncMonitorPanel(v)
            showPanelView(v, PanelView.MONITOR)
        }
        addQuickAction(grid, R.drawable.ic_float, "Dock", 5, gap) {
            if (!prefs.isPremiumTier()) toast("Floating dock is a Premium feature")
            else {
                prefs.floatingWindowEnabled = !prefs.floatingWindowEnabled
                if (prefs.floatingWindowEnabled) addDock() else removeDock()
                toast(if (prefs.floatingWindowEnabled) "Dock ON" else "Dock OFF")
            }
        }
        addQuickAction(grid, R.drawable.ic_network, "Net", 6, gap) {
            if (!prefs.isPremiumTier()) toast("Network optimizer is Premium")
            else {
                prefs.netOptimizerEnabled = !prefs.netOptimizerEnabled
                toast(if (prefs.netOptimizerEnabled) "Net optimizer ON" else "Net optimizer OFF")
            }
        }
        // Clear Cache — frees the currently-open app's memory (best effort).
        addQuickAction(grid, R.drawable.ic_cache, "Cache", 7, gap) {
            val res = ClearCacheManager.clearForegroundApp(this, MacroAccessibilityService.foregroundPackage)
            if (res.cleared) toast("Cache cleared · ${res.appLabel}")
            else toast("Freed ${res.appLabel} · tap 'Clear cache'")
        }
        // Macro sub-panel
        addQuickAction(grid, R.drawable.ic_gamepad, "Macro", 8, gap) {
            syncMacroPanel(v)
            showPanelView(v, PanelView.MACRO)
        }
        // Boost — kill background apps to free RAM
        addQuickAction(grid, R.drawable.ic_rocket, "Boost", 9, gap) {
            val n = GraphicsManager.killBackground(this)
            toast(if (n > 0) "Boosted · freed $n apps" else "Already optimized")
        }
        // Do-Not-Disturb toggle
        addQuickAction(grid, R.drawable.ic_lock, "DND", 10, gap) {
            prefs.dndEnabled = !prefs.dndEnabled
            Notifications.setDnd(this, prefs.dndEnabled)
            toast(if (prefs.dndEnabled) "Do Not Disturb ON" else "Do Not Disturb OFF")
        }
        addQuickAction(grid, R.drawable.ic_close, "Close", 11, gap) { closePanel() }
        // v2.0.5 — Floating window (jendela mengambang): watch TikTok/YouTube
        // while you keep playing the game.
        addQuickAction(grid, R.drawable.ic_float, "Float", 12, gap) {
            prefs.floatBrowserEnabled = !prefs.floatBrowserEnabled
            if (prefs.floatBrowserEnabled) { closePanel(); addFloatBrowser() }
            else removeFloatBrowser()
            toast(if (prefs.floatBrowserEnabled) "Floating window ON" else "Floating window OFF")
        }
        // v2.0.5 — Floating game timer / stopwatch.
        addQuickAction(grid, R.drawable.ic_clock, "Timer", 13, gap) {
            prefs.gameTimerEnabled = !prefs.gameTimerEnabled
            if (prefs.gameTimerEnabled) { closePanel(); addGameTimer() }
            else removeGameTimer()
            toast(if (prefs.gameTimerEnabled) "Game timer ON" else "Game timer OFF")
        }
        // v2.0.5 — Stop / kill the app that is currently in the foreground.
        addQuickAction(grid, R.drawable.ic_power, "Kill", 14, gap) {
            stopForegroundApp()
        }
        // v2.0.5 — Dim screen (night mode) — works even without WRITE_SETTINGS.
        addQuickAction(grid, R.drawable.ic_brightness, "Dim", 15, gap) {
            prefs.dimLevel = if (prefs.dimLevel > 0) 0 else 55
            applyDim()
            toast(if (prefs.dimLevel > 0) "Screen dimmed" else "Dim off")
        }
    }

    /** Best-effort: send the foreground app to the background and free its RAM. */
    private fun stopForegroundApp() {
        val pkg = MacroAccessibilityService.foregroundPackage ?: ""
        try {
            val home = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(home)
        } catch (_: Exception) {}
        var ok = false
        if (pkg.isNotBlank() && pkg != packageName) {
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                am.killBackgroundProcesses(pkg)
                ok = true
            } catch (_: Exception) {}
        }
        closePanel()
        toast(if (ok) "Stopped ${pkg.substringAfterLast('.')}" else "Returned to home")
    }

    private fun addQuickAction(
        grid: GridLayout, icon: Int, label: String, index: Int, gap: Int, action: () -> Unit
    ) {
        val item = LayoutInflater.from(this).inflate(R.layout.item_quick_action, grid, false)
        item.findViewById<ImageView>(R.id.qaIcon).setImageResource(icon)
        item.findViewById<TextView>(R.id.qaLabel).text = label
        item.setOnClickListener { action() }
        val lp = GridLayout.LayoutParams()
        lp.width = 0
        lp.height = GridLayout.LayoutParams.WRAP_CONTENT
        lp.columnSpec = GridLayout.spec(index % 4, 1f)
        lp.rowSpec = GridLayout.spec(index / 4)
        lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
        item.layoutParams = lp
        grid.addView(item)
    }

    // ----- Crosshair settings sub-panel -----
    private fun setupCrosshairPanel(v: View) {
        v.findViewById<View>(R.id.btnCrossBack)?.setOnClickListener {
            showPanelView(v, PanelView.MAIN)
        }
        v.findViewById<View>(R.id.btnCrossToggle)?.setOnClickListener {
            prefs.crosshairEnabled = !prefs.crosshairEnabled
            refreshCrosshair()
            syncCrosshairPanel(v)
            toast(if (prefs.crosshairEnabled) "Crosshair ON" else "Crosshair OFF")
        }

        val sx = v.findViewById<SeekBar>(R.id.seekCrossX)
        val sy = v.findViewById<SeekBar>(R.id.seekCrossY)
        val ss = v.findViewById<SeekBar>(R.id.seekCrossSize)
        val sg = v.findViewById<SeekBar>(R.id.seekCrossGap)
        val st = v.findViewById<SeekBar>(R.id.seekCrossThick)
        val sa = v.findViewById<SeekBar>(R.id.seekCrossAlpha)
        val tx = v.findViewById<TextView>(R.id.txtCrossX)
        val ty = v.findViewById<TextView>(R.id.txtCrossY)
        val ts = v.findViewById<TextView>(R.id.txtCrossSize)
        val tg = v.findViewById<TextView>(R.id.txtCrossGap)
        val tt = v.findViewById<TextView>(R.id.txtCrossThick)
        val ta = v.findViewById<TextView>(R.id.txtCrossAlpha)

        sx?.setOnSeekBarChangeListener(simpleSeek { p ->
            val off = p - 200
            prefs.crosshairOffsetX = off
            tx?.text = "$off"
            updateCrosshairLive()
        })
        sy?.setOnSeekBarChangeListener(simpleSeek { p ->
            val off = p - 200
            prefs.crosshairOffsetY = off
            ty?.text = "$off"
            updateCrosshairLive()
        })
        ss?.setOnSeekBarChangeListener(simpleSeek { p ->
            val size = p.coerceAtLeast(10)
            prefs.crosshairSize = size
            ts?.text = "$size"
            updateCrosshairLive()
        })
        // v2.0.5 — quick +/- buttons to grow / shrink the crosshair.
        v.findViewById<View>(R.id.btnCrossMinus)?.setOnClickListener {
            val size = (prefs.crosshairSize - 4).coerceIn(10, 110)
            prefs.crosshairSize = size
            ss?.progress = size
            ts?.text = "$size"
            updateCrosshairLive()
        }
        v.findViewById<View>(R.id.btnCrossPlus)?.setOnClickListener {
            val size = (prefs.crosshairSize + 4).coerceIn(10, 110)
            prefs.crosshairSize = size
            ss?.progress = size
            ts?.text = "$size"
            updateCrosshairLive()
        }
        sg?.setOnSeekBarChangeListener(simpleSeek { p ->
            prefs.crosshairGap = p
            tg?.text = "$p"
            updateCrosshairLive()
        })
        st?.setOnSeekBarChangeListener(simpleSeek { p ->
            val th = p.coerceAtLeast(1)
            prefs.crosshairThickness = th
            tt?.text = "$th"
            updateCrosshairLive()
        })
        sa?.setOnSeekBarChangeListener(simpleSeek { p ->
            val alpha = (p + 10).coerceIn(10, 100)
            prefs.crosshairAlpha = alpha
            ta?.text = "$alpha%"
            updateCrosshairLive()
        })

        // Style chips
        val styleRow = v.findViewById<LinearLayout>(R.id.crossStyleRow)
        styleRow?.removeAllViews()
        val gapPx = (density * 8).toInt()
        for ((i, name) in Crosshair.STYLE_NAMES.withIndex()) {
            val chip = TextView(this).apply {
                text = name
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(0xFFF5F7FF.toInt())
                background = getDrawable(R.drawable.bg_rog_chip)
                setPadding((density * 14).toInt(), (density * 8).toInt(),
                    (density * 14).toInt(), (density * 8).toInt())
                isSelected = i == prefs.crosshairStyle
                setOnClickListener {
                    prefs.crosshairStyle = i
                    for (k in 0 until (styleRow?.childCount ?: 0))
                        styleRow?.getChildAt(k)?.isSelected = k == i
                    updateCrosshairLive()
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = gapPx
            chip.layoutParams = lp
            styleRow?.addView(chip)
        }

        // Color chips
        val colorRow = v.findViewById<LinearLayout>(R.id.crossColorRow)
        colorRow?.removeAllViews()
        for (pair in Crosshair.COLORS) {
            val dot = View(this)
            val s = (density * 34).toInt()
            val lp = LinearLayout.LayoutParams(s, s)
            lp.marginEnd = (density * 10).toInt()
            dot.layoutParams = lp
            dot.background = colorDotDrawable(pair.second, pair.second == prefs.crosshairColor)
            dot.setOnClickListener {
                prefs.crosshairColor = pair.second
                for (k in 0 until (colorRow?.childCount ?: 0)) {
                    val child = colorRow?.getChildAt(k)
                    val c = Crosshair.COLORS[k].second
                    child?.background = colorDotDrawable(c, c == pair.second)
                }
                updateCrosshairLive()
            }
            colorRow?.addView(dot)
        }

        // v2.0.5 — one-tap pro presets (style + size + colour in a single tap).
        val presetRow = v.findViewById<LinearLayout>(R.id.crossPresetRow)
        presetRow?.removeAllViews()
        data class Preset(
            val name: String, val style: Int, val size: Int, val gap: Int,
            val thick: Int, val dot: Boolean, val glow: Boolean, val color: Int
        )
        val presets = listOf(
            Preset("SNIPER", Crosshair.STYLE_CROSS_DOT, 34, 10, 2, true, false, 0xFF00FF88.toInt()),
            Preset("RUSH", Crosshair.STYLE_CROSS, 60, 6, 5, false, true, 0xFFFF2D9B.toInt()),
            Preset("NEON", Crosshair.STYLE_CROSS_CIRCLE, 46, 8, 3, true, true, 0xFF00E5FF.toInt()),
            Preset("DOT", Crosshair.STYLE_DOT_RING, 40, 8, 3, true, true, 0xFFFFFFFF.toInt()),
            Preset("PRO", Crosshair.STYLE_BRACKETS, 52, 10, 3, false, false, 0xFFFFB300.toInt()),
            Preset("TACT", Crosshair.STYLE_T, 48, 8, 3, false, false, 0xFFFF3D57.toInt())
        )
        for ((i, pr) in presets.withIndex()) {
            val chip = TextView(this).apply {
                text = pr.name
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(0xFFF5F7FF.toInt())
                background = getDrawable(R.drawable.bg_rog_chip)
                setPadding((density * 14).toInt(), (density * 8).toInt(),
                    (density * 14).toInt(), (density * 8).toInt())
                isSelected = prefs.crosshairPreset == i + 1
                setOnClickListener {
                    prefs.crosshairStyle = pr.style
                    prefs.crosshairSize = pr.size
                    prefs.crosshairGap = pr.gap
                    prefs.crosshairThickness = pr.thick
                    prefs.crosshairDot = pr.dot
                    prefs.crosshairGlow = pr.glow
                    prefs.crosshairColor = pr.color
                    prefs.crosshairPreset = i + 1
                    for (k in 0 until (presetRow?.childCount ?: 0))
                        presetRow?.getChildAt(k)?.isSelected = k == i
                    for (k in 0 until (styleRow?.childCount ?: 0))
                        styleRow?.getChildAt(k)?.isSelected = k == pr.style
                    for (k in 0 until (colorRow?.childCount ?: 0)) {
                        val c = Crosshair.COLORS[k].second
                        colorRow?.getChildAt(k)?.background = colorDotDrawable(c, c == pr.color)
                    }
                    syncCrosshairPanel(v)
                    updateCrosshairLive()
                    toast("Preset: ${pr.name}")
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = gapPx
            chip.layoutParams = lp
            presetRow?.addView(chip)
        }

        v.findViewById<View>(R.id.chipCrossDot)?.setOnClickListener { chip ->
            prefs.crosshairDot = !prefs.crosshairDot
            chip.isSelected = prefs.crosshairDot
            updateCrosshairLive()
        }
        v.findViewById<View>(R.id.chipCrossGlow)?.setOnClickListener { chip ->
            prefs.crosshairGlow = !prefs.crosshairGlow
            chip.isSelected = prefs.crosshairGlow
            updateCrosshairLive()
        }
        v.findViewById<View>(R.id.btnCrossReset)?.setOnClickListener {
            prefs.crosshairOffsetX = 0
            prefs.crosshairOffsetY = 0
            prefs.crosshairSize = 42
            prefs.crosshairGap = 8
            prefs.crosshairThickness = 3
            prefs.crosshairAlpha = 100
            syncCrosshairPanel(v)
            updateCrosshairLive()
            toast("Crosshair reset to center")
        }

        syncCrosshairPanel(v)
    }

    private fun syncCrosshairPanel(v: View) {
        val on = prefs.crosshairEnabled
        v.findViewById<TextView>(R.id.btnCrossToggle)?.apply {
            text = if (on) "ON" else "OFF"
            isSelected = on
        }
        val sx = v.findViewById<SeekBar>(R.id.seekCrossX)
        val sy = v.findViewById<SeekBar>(R.id.seekCrossY)
        sx?.progress = (prefs.crosshairOffsetX + 200).coerceIn(0, 400)
        sy?.progress = (prefs.crosshairOffsetY + 200).coerceIn(0, 400)
        v.findViewById<TextView>(R.id.txtCrossX)?.text = "${prefs.crosshairOffsetX}"
        v.findViewById<TextView>(R.id.txtCrossY)?.text = "${prefs.crosshairOffsetY}"
        v.findViewById<SeekBar>(R.id.seekCrossSize)?.progress = prefs.crosshairSize.coerceIn(0, 110)
        v.findViewById<TextView>(R.id.txtCrossSize)?.text = "${prefs.crosshairSize}"
        v.findViewById<SeekBar>(R.id.seekCrossGap)?.progress = prefs.crosshairGap.coerceIn(0, 40)
        v.findViewById<TextView>(R.id.txtCrossGap)?.text = "${prefs.crosshairGap}"
        v.findViewById<SeekBar>(R.id.seekCrossThick)?.progress = prefs.crosshairThickness.coerceIn(0, 10)
        v.findViewById<TextView>(R.id.txtCrossThick)?.text = "${prefs.crosshairThickness}"
        v.findViewById<SeekBar>(R.id.seekCrossAlpha)?.progress =
            (prefs.crosshairAlpha - 10).coerceIn(0, 90)
        v.findViewById<TextView>(R.id.txtCrossAlpha)?.text = "${prefs.crosshairAlpha}%"
        v.findViewById<View>(R.id.chipCrossDot)?.isSelected = prefs.crosshairDot
        v.findViewById<View>(R.id.chipCrossGlow)?.isSelected = prefs.crosshairGlow
    }

    // ----- Monitor settings sub-panel -----
    private fun setupMonitorPanel(v: View) {
        v.findViewById<View>(R.id.btnMonBack)?.setOnClickListener {
            showPanelView(v, PanelView.MAIN)
        }
        v.findViewById<View>(R.id.btnMonToggle)?.setOnClickListener {
            prefs.monitorEnabled = !prefs.monitorEnabled
            refreshMonitor()
            syncMonitorPanel(v)
            toast(if (prefs.monitorEnabled) "Monitor ON" else "Monitor OFF")
        }

        // Position presets
        val posGrid = v.findViewById<GridLayout>(R.id.monPosGrid)
        posGrid?.removeAllViews()
        val names = listOf("TOP L", "TOP R", "BOT L", "BOT R")
        val gap = (density * 8).toInt()
        for (i in names.indices) {
            val tv = TextView(this).apply {
                text = names[i]
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(0xFFF5F7FF.toInt())
                background = getDrawable(R.drawable.bg_rog_chip)
                setPadding(0, (density * 10).toInt(), 0, (density * 10).toInt())
                isSelected = prefs.monitorPosition == i && prefs.monitorX < 0
                setOnClickListener {
                    prefs.monitorPosition = i
                    prefs.monitorX = -1
                    prefs.monitorY = -1
                    for (k in 0 until (posGrid?.childCount ?: 0))
                        posGrid?.getChildAt(k)?.isSelected = k == i
                    repositionMonitor()
                    syncMonitorPanel(v)
                }
            }
            val lp = GridLayout.LayoutParams()
            lp.width = 0
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT
            lp.columnSpec = GridLayout.spec(i % 2, 1f)
            lp.rowSpec = GridLayout.spec(i / 2)
            lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
            tv.layoutParams = lp
            posGrid?.addView(tv)
        }

        val smx = v.findViewById<SeekBar>(R.id.seekMonX)
        val smy = v.findViewById<SeekBar>(R.id.seekMonY)
        smx?.setOnSeekBarChangeListener(simpleSeek { p ->
            prefs.monitorX = p
            if (prefs.monitorY < 0) prefs.monitorY = (density * 10).toInt()
            v.findViewById<TextView>(R.id.txtMonX)?.text = "$p"
            repositionMonitor()
        })
        smy?.setOnSeekBarChangeListener(simpleSeek { p ->
            prefs.monitorY = p
            if (prefs.monitorX < 0) prefs.monitorX = (density * 10).toInt()
            v.findViewById<TextView>(R.id.txtMonY)?.text = "$p"
            repositionMonitor()
        })

        // Item toggles
        val itemGrid = v.findViewById<GridLayout>(R.id.monItemGrid)
        itemGrid?.removeAllViews()
        data class Item(val label: String, val get: () -> Boolean, val set: (Boolean) -> Unit)
        val items = listOf(
            Item("FPS", { prefs.monitorShowFps }, { prefs.monitorShowFps = it }),
            Item("CPU", { prefs.monitorShowCpu }, { prefs.monitorShowCpu = it }),
            Item("GPU", { prefs.monitorShowGpu }, { prefs.monitorShowGpu = it }),
            Item("RAM", { prefs.monitorShowRam }, { prefs.monitorShowRam = it }),
            Item("BAT", { prefs.monitorShowBattery }, { prefs.monitorShowBattery = it }),
            Item("PING", { prefs.monitorShowPing }, { prefs.monitorShowPing = it }),
            Item("TIME", { prefs.monitorShowTime }, { prefs.monitorShowTime = it })
        )
        for ((i, item) in items.withIndex()) {
            val tv = TextView(this).apply {
                text = item.label
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(0xFFF5F7FF.toInt())
                background = getDrawable(R.drawable.bg_rog_chip)
                setPadding(0, (density * 10).toInt(), 0, (density * 10).toInt())
                isSelected = item.get()
                setOnClickListener {
                    val now = !item.get()
                    item.set(now)
                    isSelected = now
                    refreshMonitorVisibility()
                }
            }
            val lp = GridLayout.LayoutParams()
            lp.width = 0
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT
            lp.columnSpec = GridLayout.spec(i % 3, 1f)
            lp.rowSpec = GridLayout.spec(i / 3)
            lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
            tv.layoutParams = lp
            itemGrid?.addView(tv)
        }

        v.findViewById<View>(R.id.chipMonExpanded)?.setOnClickListener { chip ->
            prefs.monitorExpanded = !prefs.monitorExpanded
            chip.isSelected = prefs.monitorExpanded
            refreshMonitorVisibility()
        }

        syncMonitorPanel(v)
    }

    private fun syncMonitorPanel(v: View) {
        val on = prefs.monitorEnabled
        v.findViewById<TextView>(R.id.btnMonToggle)?.apply {
            text = if (on) "ON" else "OFF"
            isSelected = on
        }
        val mx = if (prefs.monitorX >= 0) prefs.monitorX else (density * 10).toInt()
        val my = if (prefs.monitorY >= 0) prefs.monitorY else (density * 10).toInt()
        v.findViewById<SeekBar>(R.id.seekMonX)?.progress = mx.coerceIn(0, 900)
        v.findViewById<SeekBar>(R.id.seekMonY)?.progress = my.coerceIn(0, 900)
        v.findViewById<TextView>(R.id.txtMonX)?.text = "$mx"
        v.findViewById<TextView>(R.id.txtMonY)?.text = "$my"
        v.findViewById<View>(R.id.chipMonExpanded)?.isSelected = prefs.monitorExpanded
    }

    // ----- Macro sub-panel -----
    private fun setupMacroPanel(v: View) {
        v.findViewById<View>(R.id.btnMacroBack)?.setOnClickListener {
            showPanelView(v, PanelView.MAIN)
        }
        v.findViewById<View>(R.id.btnMacroRecord)?.setOnClickListener {
            if (macroRecording) stopMacroRecord(v) else startMacroRecord(v)
        }
        v.findViewById<View>(R.id.btnMacroPlay)?.setOnClickListener {
            playMacro(v)
        }
        v.findViewById<View>(R.id.btnMacroStop)?.setOnClickListener {
            MacroAccessibilityService.stopPlayback()
            if (macroRecording) stopMacroRecord(v)
            syncMacroPanel(v)
            toast("Macro stopped")
        }
        v.findViewById<View>(R.id.btnMacroClear)?.setOnClickListener {
            macroSteps.clear()
            prefs.macroSteps = ""
            syncMacroPanel(v)
            toast("Macro cleared")
        }
        v.findViewById<View>(R.id.btnMacroA11y)?.setOnClickListener {
            openAccessibilitySettings()
        }
        val seek = v.findViewById<SeekBar>(R.id.seekMacroSpeed)
        val txt = v.findViewById<TextView>(R.id.txtMacroSpeed)
        seek?.progress = prefs.macroSpeed.coerceIn(5, 30)
        txt?.text = String.format("%.1fx", prefs.macroSpeed / 10f)
        seek?.setOnSeekBarChangeListener(simpleSeek { p ->
            val sp = (p + 5).coerceIn(5, 30)
            prefs.macroSpeed = sp
            txt?.text = String.format("%.1fx", sp / 10f)
        })
        v.findViewById<View>(R.id.chipMacroLoop)?.setOnClickListener { chip ->
            prefs.macroLoop = !prefs.macroLoop
            chip.isSelected = prefs.macroLoop
        }
        v.findViewById<View>(R.id.chipMacroFab)?.setOnClickListener { chip ->
            prefs.macroEnabled = !prefs.macroEnabled
            chip.isSelected = prefs.macroEnabled
            if (prefs.macroEnabled) addMacroFab() else removeMacroFab()
            toast(if (prefs.macroEnabled) "Floating macro button ON" else "Floating macro button OFF")
        }
        syncMacroPanel(v)
    }

    private fun syncMacroPanel(v: View) {
        // Load persisted steps if we have none in memory.
        if (macroSteps.isEmpty() && prefs.macroSteps.isNotBlank()) {
            macroSteps.addAll(MacroManager.parse(prefs.macroSteps))
        }
        v.findViewById<TextView>(R.id.txtMacroInfo)?.text = MacroManager.summary(macroSteps)
        v.findViewById<TextView>(R.id.btnMacroRecord)?.text = if (macroRecording) "STOP REC" else "RECORD"
        v.findViewById<View>(R.id.chipMacroLoop)?.isSelected = prefs.macroLoop
        v.findViewById<View>(R.id.chipMacroFab)?.isSelected = prefs.macroEnabled
        val status = when {
            macroRecording -> "REC"
            MacroAccessibilityService.isPlaying() -> "PLAY"
            else -> "IDLE"
        }
        v.findViewById<TextView>(R.id.txtMacroStatus)?.text = status
        val a11y = v.findViewById<View>(R.id.btnMacroA11y)
        a11y?.visibility = if (MacroAccessibilityService.isConnected()) View.GONE else View.VISIBLE
    }

    private fun startMacroRecord(v: View) {
        if (macroRecording) return
        macroRecording = true
        macroSteps.clear()
        addMacroCapture()
        syncMacroPanel(v)
        toast("Recording… tap the STOP button when done")
    }

    private fun stopMacroRecord(v: View) {
        macroRecording = false
        removeMacroCapture()
        prefs.macroSteps = MacroManager.serialize(macroSteps)
        syncMacroPanel(v)
        toast("Recorded ${macroSteps.size} step(s)")
    }

    private fun playMacro(v: View) {
        if (macroSteps.isEmpty() && prefs.macroSteps.isNotBlank())
            macroSteps.addAll(MacroManager.parse(prefs.macroSteps))
        if (macroSteps.isEmpty()) { toast("No macro recorded yet"); return }
        if (!MacroAccessibilityService.isConnected()) {
            toast("Enable HPX SMINE Macro in Accessibility first")
            openAccessibilitySettings()
            return
        }
        // Close the panel so it doesn't block the replay.
        closePanel()
        val ok = MacroAccessibilityService.play(macroSteps, prefs.macroLoop, prefs.macroSpeed)
        toast(if (ok) "Macro playing (${macroSteps.size} steps)" else "Macro already running")
    }

    private fun openAccessibilitySettings() {
        try {
            val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            toast("Enable HPX SMINE Macro")
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------
    //  Floating window (jendela mengambang) — mini WebView browser
    // ------------------------------------------------------------------
    private fun addFloatBrowser() {
        if (floatBrowser != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_float_browser, null)
        val dm = resources.displayMetrics
        val defW = (dm.widthPixels * 0.64f).toInt()
        val defH = (dm.heightPixels * 0.44f).toInt()
        val w = if (prefs.browserW > 0) prefs.browserW else defW
        val h = if (prefs.browserH > 0) prefs.browserH else defH
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        flags = flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!prefs.browserFocus) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(w, h, overlayType(), flags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (prefs.browserX >= 0) prefs.browserX else ((dm.widthPixels - w) / 2)
        lp.y = if (prefs.browserY >= 0) prefs.browserY else (dm.heightPixels * 0.16f).toInt()
        try { wm.addView(v, lp); floatBrowser = v; floatBrowserParams = lp } catch (_: Exception) { return }

        val web = v.findViewById<WebView>(R.id.browserWeb)
        try {
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.settings.setSupportZoom(true)
            web.settings.builtInZoomControls = true
            web.settings.displayZoomControls = false
            web.settings.loadWithOverviewMode = true
            web.settings.useWideViewPort = true
            web.settings.mediaPlaybackRequiresUserGesture = false
            web.webViewClient = WebViewClient()
            web.webChromeClient = WebChromeClient()
            web.setBackgroundColor(0xFF0A0C14.toInt())
            web.loadUrl(prefs.browserUrl)
        } catch (_: Exception) {}

        fun load(url: String) { prefs.browserUrl = url; try { web.loadUrl(url) } catch (_: Exception) {} }
        v.findViewById<View>(R.id.bShortYt)?.setOnClickListener { load("https://m.youtube.com") }
        v.findViewById<View>(R.id.bShortTt)?.setOnClickListener { load("https://www.tiktok.com") }
        v.findViewById<View>(R.id.bShortWa)?.setOnClickListener { load("https://web.whatsapp.com") }
        v.findViewById<View>(R.id.bShortG)?.setOnClickListener { load("https://www.google.com") }
        v.findViewById<View>(R.id.browserReload)?.setOnClickListener { try { web.reload() } catch (_: Exception) {} }
        v.findViewById<View>(R.id.browserClose)?.setOnClickListener {
            prefs.floatBrowserEnabled = false
            removeFloatBrowser()
            toast("Floating window closed")
        }
        v.findViewById<View>(R.id.browserFocus)?.setOnClickListener {
            prefs.browserFocus = !prefs.browserFocus
            val keepUrl = prefs.browserUrl
            removeFloatBrowser()
            prefs.browserUrl = keepUrl
            addFloatBrowser()
            toast(
                if (prefs.browserFocus) "Focus ON \u00b7 keyboard works (game may pause)"
                else "Focus OFF \u00b7 game keeps running"
            )
        }

        // Drag the window by its title bar.
        val grab = v.findViewById<View>(R.id.browserGrab)
        var lx = 0f; var ly = 0f
        grab?.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x += (e.rawX - lx).toInt(); lp.y += (e.rawY - ly).toInt()
                    lx = e.rawX; ly = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> { prefs.browserX = lp.x; prefs.browserY = lp.y; true }
                else -> false
            }
        }

        // Resize from the bottom-right corner.
        val rz = v.findViewById<View>(R.id.browserResize)
        var rx = 0f; var ry = 0f
        rz?.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (lp.width + (e.rawX - rx).toInt())
                        .coerceIn((density * 200).toInt(), dm.widthPixels)
                    lp.height = (lp.height + (e.rawY - ry).toInt())
                        .coerceIn((density * 150).toInt(), dm.heightPixels)
                    rx = e.rawX; ry = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> { prefs.browserW = lp.width; prefs.browserH = lp.height; true }
                else -> false
            }
        }
    }

    private fun removeFloatBrowser() {
        floatBrowser?.let { v ->
            try {
                v.findViewById<WebView>(R.id.browserWeb)?.let { w ->
                    w.stopLoading(); w.destroy()
                }
            } catch (_: Exception) {}
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        floatBrowser = null; floatBrowserParams = null
    }

    // ------------------------------------------------------------------
    //  Floating game timer / stopwatch
    // ------------------------------------------------------------------
    private val timerTick = object : Runnable {
        override fun run() {
            val v = gameTimer ?: return
            val secs = timerElapsed()
            v.findViewById<TextView>(R.id.timerText)?.text =
                String.format("%02d:%02d", secs / 60, secs % 60)
            if (timerRunning) handler.postDelayed(this, 500)
        }
    }

    private fun timerElapsed(): Long {
        val ms = if (timerRunning) timerAccum + (SystemClock.elapsedRealtime() - timerStart) else timerAccum
        return ms / 1000
    }

    private fun addGameTimer() {
        if (gameTimer != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_game_timer, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (density * 12).toInt()
        lp.y = (resources.displayMetrics.heightPixels * 0.30f).toInt()
        try { wm.addView(v, lp); gameTimer = v } catch (_: Exception) { return }

        val toggle = v.findViewById<ImageView>(R.id.timerToggle)
        fun render() {
            val secs = timerElapsed()
            v.findViewById<TextView>(R.id.timerText)?.text =
                String.format("%02d:%02d", secs / 60, secs % 60)
            toggle?.setImageResource(if (timerRunning) R.drawable.ic_stop else R.drawable.ic_play)
            toggle?.setColorFilter(if (timerRunning) 0xFFFF3D57.toInt() else 0xFF00E676.toInt())
        }
        toggle?.setOnClickListener {
            if (timerRunning) {
                timerAccum += SystemClock.elapsedRealtime() - timerStart
                timerRunning = false
                handler.removeCallbacks(timerTick)
            } else {
                timerStart = SystemClock.elapsedRealtime()
                timerRunning = true
                handler.post(timerTick)
            }
            render()
        }
        v.findViewById<View>(R.id.timerReset)?.setOnClickListener {
            timerRunning = false; timerAccum = 0L
            handler.removeCallbacks(timerTick); render()
        }
        v.findViewById<View>(R.id.timerClose)?.setOnClickListener {
            prefs.gameTimerEnabled = false
            removeGameTimer()
        }

        var lx = 0f; var ly = 0f
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x += (e.rawX - lx).toInt(); lp.y += (e.rawY - ly).toInt()
                    lx = e.rawX; ly = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                else -> false
            }
        }
        render()
    }

    private fun removeGameTimer() {
        handler.removeCallbacks(timerTick)
        gameTimer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        gameTimer = null
    }

    // ------------------------------------------------------------------
    //  Screen dim overlay (brightness fallback / night mode)
    // ------------------------------------------------------------------
    private fun applyDim() {
        val level = prefs.dimLevel.coerceIn(0, 90)
        if (level <= 0) { removeDim(); return }
        if (dimView == null) {
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            try { wm.addView(v, lp); dimView = v } catch (_: Exception) { return }
        }
        dimView?.setBackgroundColor(Color.argb(level * 255 / 100, 0, 0, 0))
    }

    private fun removeDim() {
        dimView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        dimView = null
    }

    // ----- Floating macro button (Touch-Macro-Pro style) -----
    private fun addMacroFab() {
        if (macroFab != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_macro_fab, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val defX = (resources.displayMetrics.widthPixels - density * 72).toInt()
        val defY = (resources.displayMetrics.heightPixels * 0.45f).toInt()
        lp.x = if (prefs.macroFabX >= 0) prefs.macroFabX else defX
        lp.y = if (prefs.macroFabY >= 0) prefs.macroFabY else defY
        try { wm.addView(v, lp); macroFab = v; macroFabParams = lp } catch (_: Exception) { return }

        val main = v.findViewById<View>(R.id.macroFabMain)
        val controls = v.findViewById<View>(R.id.macroFabControls)

        v.findViewById<View>(R.id.fabRec)?.setOnClickListener {
            if (macroRecording) stopMacroRecordFab() else startMacroRecordFab()
        }
        v.findViewById<View>(R.id.fabPlay)?.setOnClickListener { playMacroFab() }
        v.findViewById<View>(R.id.fabStop)?.setOnClickListener {
            MacroAccessibilityService.stopPlayback()
            if (macroRecording) stopMacroRecordFab()
            toast("Macro stopped")
        }

        // Drag to move; tap (no move) toggles the mini controls.
        var lx = 0f; var ly = 0f; var moved = false
        main.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - lx; val dy = e.rawY - ly
                    if (abs(dx) > 6 || abs(dy) > 6) moved = true
                    lp.x += dx.toInt(); lp.y += dy.toInt()
                    lx = e.rawX; ly = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.macroFabX = lp.x; prefs.macroFabY = lp.y
                    if (!moved) {
                        macroFabExpanded = !macroFabExpanded
                        controls?.visibility = if (macroFabExpanded) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun removeMacroFab() {
        macroFab?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        macroFab = null; macroFabParams = null; macroFabExpanded = false
    }

    private fun startMacroRecordFab() {
        if (macroRecording) return
        macroRecording = true
        macroSteps.clear()
        addMacroCapture()
        toast("Recording\u2026 tap STOP when done")
    }

    private fun stopMacroRecordFab() {
        macroRecording = false
        removeMacroCapture()
        prefs.macroSteps = MacroManager.serialize(macroSteps)
        toast("Recorded ${macroSteps.size} step(s)")
    }

    private fun playMacroFab() {
        if (macroSteps.isEmpty() && prefs.macroSteps.isNotBlank())
            macroSteps.addAll(MacroManager.parse(prefs.macroSteps))
        if (macroSteps.isEmpty()) { toast("No macro recorded yet"); return }
        if (!MacroAccessibilityService.isConnected()) {
            toast("Enable HPX SMINE Macro in Accessibility first")
            openAccessibilitySettings()
            return
        }
        val ok = MacroAccessibilityService.play(macroSteps, prefs.macroLoop, prefs.macroSpeed)
        toast(if (ok) "Macro playing (${macroSteps.size} steps)" else "Macro already running")
    }

    /** Full-screen transparent layer that records raw touches during macro recording. */
    private fun addMacroCapture() {
        if (macroCapture != null) return
        val v = View(this)
        v.setBackgroundColor(0x22000000)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        var downX = 0f; var downY = 0f; var downT = 0L
        val slop = density * 12f
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; downT = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val upT = System.currentTimeMillis()
                    val dm = resources.displayMetrics
                    val w = dm.widthPixels.toFloat().coerceAtLeast(1f)
                    val h = dm.heightPixels.toFloat().coerceAtLeast(1f)
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val dur = (upT - downT).coerceIn(30L, 3000L)
                    val delay = if (macroSteps.isEmpty()) 0L else 120L
                    val step = if (abs(dx) > slop || abs(dy) > slop)
                        MacroManager.Step(downX / w, downY / h, e.rawX / w, e.rawY / h, delay, dur)
                    else
                        MacroManager.Step(downX / w, downY / h, downX / w, downY / h, delay, dur)
                    macroSteps.add(step)
                    true
                }
                else -> true
            }
        }
        try { wm.addView(v, lp); macroCapture = v } catch (_: Exception) { return }

        // Floating STOP button on top of the capture layer.
        val btn = LayoutInflater.from(this).inflate(R.layout.overlay_macro_stop, null)
        val blp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        blp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        blp.y = (density * 60).toInt()
        btn.setOnClickListener {
            macroRecording = false
            removeMacroCapture()
            prefs.macroSteps = MacroManager.serialize(macroSteps)
            toast("Recorded ${macroSteps.size} step(s)")
        }
        try { wm.addView(btn, blp); macroStopBtn = btn } catch (_: Exception) {}
    }

    private fun removeMacroCapture() {
        macroCapture?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        macroCapture = null
        macroStopBtn?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        macroStopBtn = null
    }

    private fun simpleSeek(onChange: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }

    private fun colorDotDrawable(color: Int, selected: Boolean): android.graphics.drawable.Drawable {
        val d = android.graphics.drawable.GradientDrawable()
        d.shape = android.graphics.drawable.GradientDrawable.OVAL
        d.setColor(color)
        d.setStroke(if (selected) (density * 3).toInt() else (density * 1).toInt(),
            0xFFFFFFFF.toInt())
        return d
    }

    // ----- App shortcuts -----
    private fun setupAppShortcuts(v: View) {
        val row = v.findViewById<LinearLayout>(R.id.appShortcuts) ?: return
        row.removeAllViews()
        val apps = prefs.launcherList()
        if (apps.isEmpty()) {
            val t = TextView(this).apply {
                text = if (prefs.isPremiumTier()) "Add apps in the launcher (unlimited)"
                else "Add apps in the launcher (free: 3)"
                setTextColor(0xFF5A6178.toInt())
                textSize = 11f
            }
            row.addView(t)
        } else {
            for (pkg in apps) row.addView(buildAppShortcut(pkg))
        }
    }

    private fun buildAppShortcut(pkg: String): View {
        val size = (density * 52).toInt()
        val iv = ImageView(this)
        val lp = LinearLayout.LayoutParams(size, size)
        lp.marginEnd = (density * 10).toInt()
        iv.layoutParams = lp
        iv.background = getDrawable(R.drawable.bg_glass_inner)
        val p = (density * 10).toInt()
        iv.setPadding(p, p, p, p)
        try { iv.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {
            iv.setImageResource(R.drawable.ic_apps)
        }
        iv.setOnClickListener { launchApp(pkg) }
        return iv
    }

    private fun launchApp(pkg: String) {
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                closePanel()
            } else toast("App not installed")
        } catch (_: Exception) { toast("Cannot open app") }
    }

    // ------------------------------------------------------------------
    //  Floating app dock (premium)
    // ------------------------------------------------------------------
    private fun addDock() {
        if (dock != null) return
        if (!prefs.floatingWindowEnabled || !prefs.isPremiumTier()) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_float_dock, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val defX = (density * 14).toInt()
        val defY = (resources.displayMetrics.heightPixels * 0.62f).toInt()
        lp.x = if (prefs.floatDockX >= 0) prefs.floatDockX else defX
        lp.y = if (prefs.floatDockY >= 0) prefs.floatDockY else defY
        try { wm.addView(v, lp); dock = v } catch (_: Exception) { return }

        val row = v.findViewById<LinearLayout>(R.id.dockApps)
        row.removeAllViews()
        val apps = prefs.launcherList()
        if (apps.isEmpty()) {
            val t = TextView(this).apply {
                text = "Add apps in launcher"
                setTextColor(0xFF5A6178.toInt()); textSize = 10f
                setPadding((density * 6).toInt(), 0, (density * 6).toInt(), 0)
            }
            row.addView(t)
        } else {
            for (pkg in apps) {
                val size = (density * 40).toInt()
                val iv = ImageView(this)
                val ilp = LinearLayout.LayoutParams(size, size)
                ilp.marginEnd = (density * 6).toInt()
                iv.layoutParams = ilp
                iv.background = getDrawable(R.drawable.bg_glass_inner)
                val p = (density * 7).toInt()
                iv.setPadding(p, p, p, p)
                try { iv.setImageDrawable(packageManager.getApplicationIcon(pkg)) }
                catch (_: Exception) { iv.setImageResource(R.drawable.ic_apps) }
                iv.setOnClickListener { launchApp(pkg) }
                row.addView(iv)
            }
        }

        v.findViewById<View>(R.id.dockMinimize)?.setOnClickListener {
            prefs.floatingWindowEnabled = false
            removeDock()
        }

        // Drag via grab handle
        val grab = v.findViewById<View>(R.id.dockGrab) ?: return
        var lx = 0f; var ly = 0f
        grab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x += (e.rawX - lx).toInt()
                    lp.y += (e.rawY - ly).toInt()
                    lx = e.rawX; ly = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.floatDockX = lp.x; prefs.floatDockY = lp.y; true
                }
                else -> false
            }
        }
    }

    private fun removeDock() {
        dock?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        dock = null
    }

    // ------------------------------------------------------------------
    //  Login animation (ROG style)
    // ------------------------------------------------------------------
    private fun showLoginAnim() {
        if (!prefs.loginAnimEnabled || loginView != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_login, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(v, lp); loginView = v } catch (_: Exception) { return }

        val progress = v.findViewById<ProgressBar>(R.id.loginProgress)
        val status = v.findViewById<TextView>(R.id.loginStatus)
        val logo = v.findViewById<ImageView>(R.id.loginLogo)
        logo?.animate()?.rotation(360f)?.setDuration(1400)?.start()

        val stages = listOf(
            "INITIALIZING GAME SPACE...",
            "LOADING OPTIMIZER...",
            "CALIBRATING OVERLAY...",
            "READY"
        )
        val anim = ValueAnimator.ofInt(0, 100).setDuration(1500)
        anim.addUpdateListener {
            val p = it.animatedValue as Int
            progress?.progress = p
            status?.text = stages[(p / 26).coerceIn(0, stages.size - 1)]
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                handler.postDelayed({ removeLoginAnim() }, 300)
            }
        })
        anim.start()
    }

    private fun removeLoginAnim() {
        loginView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        loginView = null
    }

    // ------------------------------------------------------------------
    //  Helpers
    // ------------------------------------------------------------------
    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        removeCrosshair(); removeMonitor(); removeEdgeHandle(); removeDock()
        removeMacroFab(); removeFloatBrowser(); removeGameTimer(); removeDim()
        removeMacroCapture()
        closePanel(immediate = true)
        removeLoginAnim()
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

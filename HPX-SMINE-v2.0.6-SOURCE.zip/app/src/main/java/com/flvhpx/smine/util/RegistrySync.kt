package com.flvhpx.smine.util

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cloud upgrade registry sync (v2.0.6).
 *
 * Accounts in HPX SMINE are stored locally on each device, so a website cannot
 * touch them directly. To let the private developer panel upgrade an account
 * "automatically", the panel writes a small JSON registry to the project's
 * GitHub repo:
 *
 *     docs/registry.json
 *     {
 *       "version": 1,
 *       "updated": 1699999999999,
 *       "accounts": {
 *         "HPX-HGY68XC": { "tier": "VVIP", "days": 30, "exp": 1699999999999, "passHash": "<sha256>" }
 *       }
 *     }
 *
 * On launch (and whenever the user taps "Sync") the app downloads this file,
 * looks up its own username and, if it finds an entry, applies the tier +
 * expiry locally. If the entry carries a password, it must match the account
 * password — that is what makes the panel's "username + password" step real.
 *
 * The registry is developer-controlled (writing it requires a GitHub token),
 * so its contents are treated as authoritative for upgrades.
 */
class RegistrySync(private val context: Context) {

    private val prefs = Prefs(context)

    /** Outcome of a sync attempt, used to show feedback in the UI. */
    sealed class Result {
        /** No local account yet — nothing to do. */
        object NoAccount : Result()

        /** Registry reachable, but this device has no entry (not upgraded). */
        object NotFound : Result()

        /** Entry exists but the stored password does not match this account. */
        object PasswordMismatch : Result()

        /** Upgrade applied (or already up to date). */
        data class Applied(val tier: String, val expiry: Long, val changed: Boolean) : Result()

        /** Network / parse failure. */
        data class Failed(val message: String) : Result()
    }

    /**
     * Fetch the registry and apply any upgrade for this device.
     * Blocking — call from a background thread (e.g. Dispatchers.IO).
     */
    fun sync(): Result {
        val username = prefs.accountUsername
        if (username.isBlank()) {
            val r = Result.NoAccount
            prefs.lastSyncStatus = statusText(r)
            return r
        }

        val body = try {
            fetch()
        } catch (e: Exception) {
            val r = Result.Failed(e.message ?: "network error")
            prefs.lastSyncStatus = statusText(r)
            return r
        }

        val result = try {
            applyRegistry(body, username)
        } catch (e: Exception) {
            Result.Failed("parse error")
        }

        if (result !is Result.Failed) {
            prefs.lastSyncAt = System.currentTimeMillis()
        }
        prefs.lastSyncStatus = statusText(result)
        return result
    }

    // ------------------------------------------------------------------

    private fun fetch(): String {
        // Cache-buster so GitHub's CDN always returns the freshest registry.
        val url = URL(REGISTRY_URL + "?t=" + System.currentTimeMillis())
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Cache-Control", "no-cache")
            setRequestProperty("User-Agent", "HPX-SMINE")
        }
        try {
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw Exception("HTTP $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun applyRegistry(body: String, username: String): Result {
        val root = JSONObject(body)
        val accounts = root.optJSONObject("accounts") ?: return Result.NotFound
        val entry = accounts.optJSONObject(username) ?: return Result.NotFound

        val tier = entry.optString("tier", "").uppercase()
        if (tier !in VALID_TIERS) return Result.NotFound

        val expiry = entry.optLong("exp", 0L)

        // Password gate: the panel stores only a SHA-256 hash of the target
        // password (never plaintext), so the public cloud file cannot leak
        // passwords. We hash this device's password and compare. Enforced
        // only when the panel recorded a hash (or a legacy plaintext value).
        val passHash = entry.optString("passHash", "")
        val legacyPass = entry.optString("pass", "")
        if (passHash.isNotBlank()) {
            if (!sha256(prefs.accountPassword).equals(passHash, ignoreCase = true)) {
                return Result.PasswordMismatch
            }
        } else if (legacyPass.isNotBlank() && legacyPass != prefs.accountPassword) {
            return Result.PasswordMismatch
        }

        val changed = prefs.accountTier != tier || prefs.accountExpiry != expiry
        prefs.accountTier = tier
        prefs.accountExpiry = expiry
        prefs.lastSyncTier = tier
        prefs.lastSyncExpiry = expiry
        return Result.Applied(tier, expiry, changed)
    }

    // ------------------------------------------------------------------

    /** Lower-case hex SHA-256 of the given string (UTF-8). */
    private fun sha256(input: String): String {
        val bytes = java.security.MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val i = b.toInt() and 0xff
            if (i < 0x10) sb.append('0')
            sb.append(Integer.toHexString(i))
        }
        return sb.toString()
    }

    /** Short, user-facing text for the last sync outcome. */
    fun statusText(r: Result): String = when (r) {
        is Result.NoAccount -> "NO ACCOUNT"
        is Result.NotFound -> "NOT UPGRADED"
        is Result.PasswordMismatch -> "PASSWORD MISMATCH"
        is Result.Applied -> if (r.changed) "UPGRADED → ${r.tier}" else "UP TO DATE (${r.tier})"
        is Result.Failed -> "SYNC FAILED (${r.message})"
    }

    companion object {
        /** Raw registry URL (public repo, no auth needed to read). */
        const val REGISTRY_URL =
            "https://raw.githubusercontent.com/groo65599-cyber/HEAVYy_PROJECT-X/main/docs/registry.json"

        val VALID_TIERS = setOf("FREE", "PREMIUM", "VVIP", "DEVELOPER")
    }
}

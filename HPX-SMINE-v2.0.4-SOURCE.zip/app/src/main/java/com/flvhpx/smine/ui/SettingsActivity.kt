package com.flvhpx.smine.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.flvhpx.smine.R
import com.flvhpx.smine.service.OverlayService
import com.flvhpx.smine.service.ScreenCaptureManager
import com.flvhpx.smine.service.ScreenCaptureService
import com.flvhpx.smine.util.GraphicsManager
import com.flvhpx.smine.util.Permissions
import com.flvhpx.smine.util.Prefs

/**
 * Permission hub + overlay preferences. Also hosts the MediaProjection
 * consent flow required by the screenshot & screen-recording features.
 */
class SettingsActivity : BaseActivity() {

    private lateinit var prefs: Prefs

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                ScreenCaptureManager.save(result.resultCode, result.data)
                // Spin up the capture service so the projection stays alive.
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, ScreenCaptureService::class.java)
                        .setAction(ScreenCaptureService.ACTION_START)
                )
                toast("Screen capture enabled")
            } else {
                toast("Screen capture denied")
            }
            refresh()
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            toast(if (granted) "Notifications enabled" else "Notifications denied")
            refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setupHeader("SETTINGS", "Permissions & overlay preferences")
        prefs = Prefs(this)

        // ---- Permission rows ----
        findViewById<android.view.View>(R.id.rowOverlayPerm).setOnClickListener {
            if (Permissions.canDrawOverlays(this)) Permissions.openAppDetails(this)
            else Permissions.requestOverlay(this)
        }
        findViewById<android.view.View>(R.id.rowWritePerm).setOnClickListener {
            if (Permissions.canWriteSettings(this)) Permissions.openAppDetails(this)
            else Permissions.requestWriteSettings(this)
        }
        findViewById<android.view.View>(R.id.rowNotifPerm).setOnClickListener {
            requestNotifications()
        }
        findViewById<android.view.View>(R.id.rowMediaPerm).setOnClickListener {
            requestScreenCapture()
        }
        findViewById<android.view.View>(R.id.rowBattery).setOnClickListener {
            Permissions.requestBatteryOptimization(this)
        }

        // ---- Overlay content switches ----
        val swCross = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.swCrosshair)
        swCross.isChecked = prefs.crosshairEnabled
        swCross.setOnCheckedChangeListener { _, b -> prefs.crosshairEnabled = b; reloadIfRunning() }

        val swMon = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.swMonitor)
        swMon.isChecked = prefs.monitorEnabled
        swMon.setOnCheckedChangeListener { _, b -> prefs.monitorEnabled = b; reloadIfRunning() }

        val swEdge = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.swEdge)
        swEdge.isChecked = prefs.edgePanelEnabled
        swEdge.setOnCheckedChangeListener { _, b -> prefs.edgePanelEnabled = b; reloadIfRunning() }

        findViewById<Button>(R.id.btnReloadOverlay).setOnClickListener {
            if (!Permissions.canDrawOverlays(this)) {
                toast("Grant 'Draw over other apps' first")
                Permissions.requestOverlay(this)
                return@setOnClickListener
            }
            if (prefs.overlayEnabled) {
                OverlayService.reload(this)
                toast("Overlay reloaded")
            } else {
                ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
                prefs.overlayEnabled = true
                toast("Overlay started")
            }
        }

        findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            Permissions.openAppDetails(this)
        }

        // ---- Game graphics quality ----
        findViewById<android.view.View>(R.id.chipGfxLow).setOnClickListener { setGraphics(0) }
        findViewById<android.view.View>(R.id.chipGfxMedium).setOnClickListener { setGraphics(1) }
        findViewById<android.view.View>(R.id.chipGfxHigh).setOnClickListener { setGraphics(2) }
        syncGraphics()

        // ---- Macro accessibility ----
        findViewById<android.view.View>(R.id.rowMacroA11y).setOnClickListener {
            if (isMacroA11yEnabled()) {
                toast("Macro accessibility is enabled")
            } else {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    toast("Enable 'HPX SMINE' under Installed apps")
                } catch (_: Exception) {}
            }
        }

        findViewById<TextView>(R.id.txtVersion).text = "HPX SMINE v${appVersion()}"
    }

    private fun setGraphics(quality: Int) {
        prefs.graphicsQuality = quality
        prefs.graphicsLiteOverlay = quality == 0
        val applied = GraphicsManager.apply(this, quality)
        syncGraphics()
        reloadIfRunning()
        val msg = buildString {
            append("Graphics: ").append(GraphicsManager.label(quality))
            if (applied.isNotEmpty()) append(" · ").append(applied.joinToString(", "))
        }
        toast(msg)
    }

    private fun syncGraphics() {
        val q = prefs.graphicsQuality
        val chips = mapOf(
            0 to R.id.chipGfxLow, 1 to R.id.chipGfxMedium, 2 to R.id.chipGfxHigh
        )
        for ((k, id) in chips) findViewById<TextView>(id).isSelected = k == q
        findViewById<TextView>(R.id.txtGfxDesc).text = GraphicsManager.description(q)
    }

    private fun isMacroA11yEnabled(): Boolean = try {
        val enabled = android.provider.Settings.Secure.getString(
            contentResolver,
            android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        enabled.contains("$packageName/${com.flvhpx.smine.service.MacroAccessibilityService::class.java.name}") ||
                enabled.contains("$packageName/.service.MacroAccessibilityService")
    } catch (_: Exception) { false }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun reloadIfRunning() {
        if (prefs.overlayEnabled) OverlayService.reload(this)
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED
            if (granted) Permissions.openAppDetails(this) else notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            toast("Notifications always allowed on this Android version")
        }
    }

    private fun requestScreenCapture() {
        if (ScreenCaptureManager.isReady()) {
            toast("Screen capture already enabled")
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun refresh() {
        setPill(R.id.txtOverlayPerm, Permissions.canDrawOverlays(this))
        setPill(R.id.txtWritePerm, Permissions.canWriteSettings(this))
        setPill(R.id.txtNotifPerm, notificationsGranted())
        setPill(R.id.txtMediaPerm, ScreenCaptureManager.isReady())
        findViewById<TextView>(R.id.txtBattery).text = "OPEN"
        setPill(R.id.txtMacroA11y, isMacroA11yEnabled())
        syncGraphics()
    }

    private fun notificationsGranted(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED
        else true

    private fun setPill(id: Int, ok: Boolean) {
        val tv = findViewById<TextView>(id)
        if (ok) {
            tv.text = "GRANTED"
            tv.setTextColor(ContextCompat.getColor(this, R.color.success))
            tv.background = ContextCompat.getDrawable(this, R.drawable.bg_pill)
        } else {
            tv.text = "GRANT"
            tv.setTextColor(ContextCompat.getColor(this, R.color.warning))
            tv.background = ContextCompat.getDrawable(this, R.drawable.bg_pill)
        }
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
    } catch (_: Exception) {
        "1.0"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}

package com.flvhpx.smine.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.flvhpx.smine.R
import com.flvhpx.smine.util.AccountStore
import com.flvhpx.smine.util.EnergyManager
import com.flvhpx.smine.util.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AccountActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var account: AccountStore
    private lateinit var energy: EnergyManager
    private var passwordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account)
        setupHeader(getString(R.string.account_title), getString(R.string.account_sub))

        prefs = Prefs(this)
        account = AccountStore(this)
        energy = EnergyManager(this)
        account.ensureAccount()

        findViewById<TextView>(R.id.txtUsername).text = account.username()
        findViewById<TextView>(R.id.txtPassword).text = "••••••••"

        findViewById<ImageView>(R.id.btnCopyUser).setOnClickListener {
            copy(account.username()); toast(getString(R.string.account_copied))
        }
        findViewById<ImageView>(R.id.btnCopyPass).setOnClickListener {
            copy(account.password()); toast(getString(R.string.account_copied))
        }
        findViewById<ImageView>(R.id.btnTogglePass).setOnClickListener {
            passwordVisible = !passwordVisible
            findViewById<TextView>(R.id.txtPassword).text =
                if (passwordVisible) account.password() else "••••••••"
        }

        findViewById<Button>(R.id.btnWatchAd).setOnClickListener { watchAd() }
        findViewById<Button>(R.id.btnUpgrade).setOnClickListener { openWhatsApp() }
        findViewById<Button>(R.id.btnEditCreds).setOnClickListener { editCredentials() }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val tier = account.tierLabel()
        findViewById<TextView>(R.id.txtTierBig).text = tier
        findViewById<TextView>(R.id.txtTierBadge).text = tier
        findViewById<TextView>(R.id.txtTierBadge).setBackgroundResource(
            when {
                prefs.isDeveloper() -> R.drawable.bg_tier_dev
                tier.startsWith("VVIP") -> R.drawable.bg_tier_vvip
                prefs.isPremiumTier() -> R.drawable.bg_tier_premium
                else -> R.drawable.bg_tier_free
            }
        )
        findViewById<ImageView>(R.id.imgTierIcon).setColorFilter(
            ContextCompat.getColor(
                this,
                when {
                    prefs.isDeveloper() -> R.color.neon_cyan
                    tier.startsWith("VVIP") -> R.color.neon_magenta
                    prefs.isPremiumTier() -> R.color.warning
                    else -> R.color.neon_pink
                }
            )
        )

        val exp = account.expiry()
        findViewById<TextView>(R.id.txtTierExpiry).text =
            if (exp == 0L) "EXPIRES: ${getString(R.string.account_forever)}"
            else "EXPIRES: " + SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(exp))

        // Energy
        val bar = findViewById<ProgressBar>(R.id.energyBar)
        val valTxt = findViewById<TextView>(R.id.txtEnergyValue)
        val tag = findViewById<TextView>(R.id.txtEnergyTag)
        if (energy.isUnlimited()) {
            bar.max = 100; bar.progress = 100
            valTxt.text = "UNLIMITED"
            tag.text = "PREMIUM"
        } else {
            bar.max = energy.max()
            bar.progress = energy.current()
            valTxt.text = "${energy.current()} / ${energy.max()}"
            tag.text = "100 / RUN"
        }
    }

    private fun refreshCreds() {
        findViewById<TextView>(R.id.txtUsername).text = account.username()
        findViewById<TextView>(R.id.txtPassword).text =
            if (passwordVisible) account.password() else "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
    }

    private fun editCredentials() {
        val view = layoutInflater.inflate(R.layout.dialog_edit_creds, null)
        val eUser = view.findViewById<EditText>(R.id.editCredUser)
        val ePass = view.findViewById<EditText>(R.id.editCredPass)
        eUser.setText(account.username())
        ePass.setText(account.password())
        eUser.setSelection(eUser.text.length)

        AlertDialog.Builder(this)
            .setTitle(R.string.account_edit_title)
            .setView(view)
            .setPositiveButton(R.string.account_edit_save) { _, _ ->
                if (account.setCredentials(eUser.text.toString(), ePass.text.toString())) {
                    toast(getString(R.string.account_edit_saved))
                    refreshCreds()
                } else {
                    toast(getString(R.string.account_edit_empty))
                }
            }
            .setNegativeButton(R.string.account_edit_cancel, null)
            .setNeutralButton(R.string.account_edit_reset) { _, _ ->
                account.resetCredentials()
                refreshCreds()
                toast(getString(R.string.account_edit_saved))
            }
            .show()
    }

    private fun watchAd() {
        if (energy.isUnlimited()) { toast("Premium has unlimited energy"); return }
        if (energy.current() >= energy.max()) { toast("Energy is already full"); return }
        val btn = findViewById<Button>(R.id.btnWatchAd)
        btn.isEnabled = false
        object : CountDownTimer(15_000, 1000) {
            override fun onTick(ms: Long) {
                btn.text = "WATCHING AD\u2026 ${ms / 1000 + 1}s"
            }
            override fun onFinish() {
                val gained = energy.rewardAd()
                btn.text = getString(R.string.account_watch_ad)
                btn.isEnabled = true
                toast("+$gained energy")
                refresh()
            }
        }.start()
    }

    private fun openWhatsApp() {
        val msg = "Halo, saya mau upgrade akun HPX SMINE ke PREMIUM.%0A" +
                "Username: ${account.username()}%0ATier saat ini: ${account.tierLabel()}"
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/628569035254?text=$msg"))
            startActivity(i)
        } catch (_: Exception) {
            toast("WhatsApp not installed \u2014 number: 08569035254")
        }
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("HPX SMINE", text))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}

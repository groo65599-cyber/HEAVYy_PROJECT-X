package com.flvhpx.smine.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.flvhpx.smine.R

class AboutActivity : BaseActivity() {

    private data class Item(val icon: Int, val title: String, val desc: String, val tint: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        setupHeader("ABOUT", "HPX SMINE \u00b7 HEAVY PROJECT X")

        findViewById<TextView>(R.id.txtAboutVersion).text = "v${appVersion()}"
        buildFeatures()
    }

    private fun buildFeatures() {
        val items = listOf(
            Item(R.drawable.ic_sensi, "Sensitivity Presets", "LOW & HIGH sensi tuned for Free Fire", R.color.neon_pink),
            Item(R.drawable.ic_fps, "FPS Optimizer", "Boost frame rate & smoothness", R.color.neon_cyan),
            Item(R.drawable.ic_crosshair, "Crosshair", "10 styles, 10 colors, live overlay", R.color.neon_magenta),
            Item(R.drawable.ic_monitor, "Lifetime Monitor", "Real-time FPS, CPU, GPU & RAM", R.color.neon_purple),
            Item(R.drawable.ic_apps, "App Launcher", "Run & login up to 3 apps at once", R.color.neon_blue),
            Item(R.drawable.ic_swipe, "Edge Panel", "Game Genie-style left swipe controls", R.color.neon_pink),
            Item(R.drawable.ic_screenshot, "Capture Suite", "Screenshot, record, brightness, volume", R.color.success),
            Item(R.drawable.ic_cache, "Cache Cleaner", "Free up memory & storage instantly", R.color.warning)
        )

        val container = findViewById<LinearLayout>(R.id.aboutFeatureList)
        container.removeAllViews()
        val d = resources.displayMetrics.density

        for (it in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = ContextCompat.getDrawable(this@AboutActivity, R.drawable.bg_glass_inner)
                setPadding((d * 14).toInt(), (d * 12).toInt(), (d * 14).toInt(), (d * 12).toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (d * 10).toInt() }
            }

            val icon = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams((d * 38).toInt(), (d * 38).toInt())
                setPadding((d * 8).toInt(), (d * 8).toInt(), (d * 8).toInt(), (d * 8).toInt())
                background = ContextCompat.getDrawable(this@AboutActivity, R.drawable.bg_icon_box)
                setImageResource(it.icon)
                setColorFilter(ContextCompat.getColor(this@AboutActivity, it.tint))
            }

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { marginStart = (d * 12).toInt() }
            }

            val title = TextView(this).apply {
                text = it.title
                textSize = 14f
                setTextColor(ContextCompat.getColor(this@AboutActivity, R.color.text_primary))
                typeface = androidx.core.content.res.ResourcesCompat.getFont(this@AboutActivity, R.font.rajdhani_semibold)
            }
            val desc = TextView(this).apply {
                text = it.desc
                textSize = 11f
                setTextColor(ContextCompat.getColor(this@AboutActivity, R.color.text_secondary))
                typeface = androidx.core.content.res.ResourcesCompat.getFont(this@AboutActivity, R.font.rajdhani_medium)
            }

            textCol.addView(title)
            textCol.addView(desc)
            row.addView(icon)
            row.addView(textCol)
            container.addView(row)
        }
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
    } catch (_: Exception) {
        "1.0"
    }
}

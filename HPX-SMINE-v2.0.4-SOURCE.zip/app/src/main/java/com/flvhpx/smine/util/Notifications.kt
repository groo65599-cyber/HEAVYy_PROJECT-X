package com.flvhpx.smine.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.flvhpx.smine.MainActivity
import com.flvhpx.smine.R

object Notifications {

    const val CH_OVERLAY = "hpx_overlay"
    const val CH_CAPTURE = "hpx_capture"
    const val ID_OVERLAY = 1001
    const val ID_CAPTURE = 1002

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH_OVERLAY) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CH_OVERLAY, "HPX SMINE Overlay",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply { description = "Floating overlay service" }
                )
            }
            if (nm.getNotificationChannel(CH_CAPTURE) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CH_CAPTURE, "HPX SMINE Capture",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply { description = "Screenshot & screen recording" }
                )
            }
        }
    }

    fun build(ctx: Context, channel: String, title: String, text: String, id: Int): Notification {
        val intent = Intent(ctx, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            ctx, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_rocket)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setColor(0xFFFF2D9B.toInt())
            .build()
    }

    /**
     * Toggle Do-Not-Disturb (best effort). Requires notification-policy access;
     * if it is not granted this silently no-ops.
     */
    fun setDnd(ctx: Context, enable: Boolean): Boolean {
        return try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!nm.isNotificationPolicyAccessGranted) return false
                nm.setInterruptionFilter(
                    if (enable) NotificationManager.INTERRUPTION_FILTER_NONE
                    else NotificationManager.INTERRUPTION_FILTER_ALL
                )
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}

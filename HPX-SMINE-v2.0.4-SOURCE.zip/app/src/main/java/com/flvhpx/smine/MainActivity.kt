package com.flvhpx.smine

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.flvhpx.smine.databinding.ActivityMainBinding
import com.flvhpx.smine.service.OverlayService
import com.flvhpx.smine.ui.AccountActivity
import com.flvhpx.smine.ui.AppLauncherActivity
import com.flvhpx.smine.ui.CacheCleanerActivity
import com.flvhpx.smine.ui.CrosshairActivity
import com.flvhpx.smine.ui.FpsOptimizerActivity
import com.flvhpx.smine.ui.MonitorActivity
import com.flvhpx.smine.ui.NetworkActivity
import com.flvhpx.smine.ui.SensitivityActivity
import com.flvhpx.smine.ui.SettingsActivity
import com.flvhpx.smine.util.AccountStore
import com.flvhpx.smine.util.EnergyManager
import com.flvhpx.smine.util.Permissions
import com.flvhpx.smine.util.Prefs

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs
    private lateinit var account: AccountStore

    private data class Feature(
        val title: String,
        val desc: String,
        val icon: Int,
        val action: () -> Unit
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = Prefs(this)
        account = AccountStore(this)
        account.ensureAccount()

        buildFeatures()
        buildDashboardApps()

        b.btnOverlay.setOnClickListener { toggleOverlay() }
        b.statusCard.setOnClickListener { open(SettingsActivity::class.java) }
        b.txtTierBadge.setOnClickListener { open(AccountActivity::class.java) }
        b.imgLogo.alpha = 0f
        b.imgLogo.animate().alpha(1f).setDuration(600).start()

        // Bottom navigation
        findViewById<View>(R.id.navHome).setOnClickListener { /* already home */ }
        findViewById<View>(R.id.navSettings).setOnClickListener { open(SettingsActivity::class.java) }
        findViewById<View>(R.id.navAccount).setOnClickListener { open(AccountActivity::class.java) }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        buildDashboardApps()
    }

    private fun buildFeatures() {
        val features = listOf(
            Feature(getString(R.string.feat_sensi), getString(R.string.feat_sensi_desc), R.drawable.ic_sensi) { open(SensitivityActivity::class.java) },
            Feature(getString(R.string.feat_fps), getString(R.string.feat_fps_desc), R.drawable.ic_fps) { open(FpsOptimizerActivity::class.java) },
            Feature(getString(R.string.feat_crosshair), getString(R.string.feat_crosshair_desc), R.drawable.ic_crosshair) { open(CrosshairActivity::class.java) },
            Feature(getString(R.string.feat_monitor), getString(R.string.feat_monitor_desc), R.drawable.ic_monitor) { open(MonitorActivity::class.java) },
            Feature(getString(R.string.feat_launcher), getString(R.string.feat_launcher_desc), R.drawable.ic_apps) { open(AppLauncherActivity::class.java) },
            Feature(getString(R.string.feat_network), getString(R.string.feat_network_desc), R.drawable.ic_network) { open(NetworkActivity::class.java) },
            Feature(getString(R.string.feat_cache), getString(R.string.feat_cache_desc), R.drawable.ic_cache) { open(CacheCleanerActivity::class.java) },
            Feature(getString(R.string.feat_settings), getString(R.string.feat_settings_desc), R.drawable.ic_settings) { open(SettingsActivity::class.java) }
        )

        val gap = (resources.displayMetrics.density * 10).toInt()
        b.featureGrid.removeAllViews()
        for ((i, f) in features.withIndex()) {
            val card = LayoutInflater.from(this).inflate(R.layout.item_feature_card, b.featureGrid, false)
            card.findViewById<TextView>(R.id.cardTitle).text = f.title
            card.findViewById<TextView>(R.id.cardDesc).text = f.desc
            card.findViewById<ImageView>(R.id.cardIcon).setImageResource(f.icon)
            card.setOnClickListener { f.action() }

            val lp = GridLayout.LayoutParams()
            lp.width = 0
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT
            lp.columnSpec = GridLayout.spec(i % 2, 1f)
            lp.rowSpec = GridLayout.spec(i / 2)
            lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
            card.layoutParams = lp
            b.featureGrid.addView(card)
        }
    }

    private fun buildDashboardApps() {
        b.appRow.removeAllViews()
        val apps = prefs.launcherList()
        for (pkg in apps) {
            val tile = LayoutInflater.from(this).inflate(R.layout.item_dash_app, b.appRow, false)
            val icon = tile.findViewById<ImageView>(R.id.dashAppIcon)
            val label = tile.findViewById<TextView>(R.id.dashAppLabel)
            try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {}
            label.text = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) { pkg }
            tile.setOnClickListener { launchApp(pkg) }
            b.appRow.addView(tile)
        }

        // "Add" tile — always present
        val add = LayoutInflater.from(this).inflate(R.layout.item_dash_app, b.appRow, false)
        add.findViewById<ImageView>(R.id.dashAppIcon).apply {
            setImageResource(R.drawable.ic_add)
            setColorFilter(ContextCompat.getColor(this@MainActivity, R.color.neon_pink))
        }
        add.findViewById<TextView>(R.id.dashAppLabel).text = "Add"
        add.setOnClickListener { open(AppLauncherActivity::class.java) }
        b.appRow.addView(add)

        b.txtAppQuota.text =
            if (prefs.isPremiumTier()) "PREMIUM \u00b7 UNLIMITED" else "FREE \u00b7 3 MAX"
    }

    private fun launchApp(pkg: String) {
        val em = EnergyManager(this)
        if (!em.canRun()) {
            toast("Not enough energy \u2014 watch an ad in Account")
            return
        }
        em.tryConsumeForRun()
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } else toast("App not installed")
    }

    private fun toggleOverlay() {
        if (!Permissions.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant 'Draw over other apps' to use the overlay", Toast.LENGTH_LONG).show()
            Permissions.requestOverlay(this)
            return
        }
        if (prefs.overlayEnabled) {
            stopService(Intent(this, OverlayService::class.java))
            prefs.overlayEnabled = false
            toast("Overlay stopped")
        } else {
            OverlayService.start(this)
            prefs.overlayEnabled = true
            toast("Overlay started \u2014 swipe from the right edge in game")
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        val on = prefs.overlayEnabled
        b.txtStatus.text = getString(if (on) R.string.overlay_on else R.string.overlay_off)
        b.btnOverlay.text = getString(if (on) R.string.stop_overlay else R.string.start_overlay)
        b.statusDot.background.setTint(
            ContextCompat.getColor(this, if (on) R.color.success else R.color.text_dim)
        )

        val overlayOk = Permissions.canDrawOverlays(this)
        val writeOk = Permissions.canWriteSettings(this)
        if (overlayOk && writeOk) {
            b.txtPermBadge.text = "READY"
            b.txtPermBadge.setTextColor(ContextCompat.getColor(this, R.color.success))
        } else {
            b.txtPermBadge.text = "PERMS"
            b.txtPermBadge.setTextColor(ContextCompat.getColor(this, R.color.warning))
        }

        val tier = account.tierLabel()
        b.txtTierBadge.text = tier
        b.txtTierBadge.setBackgroundResource(
            when {
                prefs.isDeveloper() -> R.drawable.bg_tier_dev
                tier.startsWith("VVIP") -> R.drawable.bg_tier_vvip
                prefs.isPremiumTier() -> R.drawable.bg_tier_premium
                else -> R.drawable.bg_tier_free
            }
        )
    }

    private fun open(cls: Class<*>) {
        startActivity(Intent(this, cls))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}

package com.flvhpx.smine.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.util.CacheUtils
import com.flvhpx.smine.util.Prefs

class FpsOptimizerActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var sp: android.content.SharedPreferences

    private var killBg = false
    private var clearCache = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fps_optimizer)
        setupHeader("FPS OPTIMIZER", "Boost frame rate & smoothness")
        prefs = Prefs(this)
        sp = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        killBg = sp.getBoolean("opt_killbg", true)
        clearCache = sp.getBoolean("opt_clearcache", true)

        buildToggles()
        findViewById<Button>(R.id.btnBoost).setOnClickListener { boost() }
        findViewById<TextView>(R.id.txtDevice).text = deviceInfo()
        refreshStats()
    }

    private fun deviceInfo(): String {
        val cores = Runtime.getRuntime().availableProcessors()
        return "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} · ${cores} cores"
    }

    private fun buildToggles() {
        val c = findViewById<LinearLayout>(R.id.optContainer)
        c.removeAllViews()
        addToggle(c, "Kill Background Apps", "Force-stop background processes to free RAM", killBg) {
            killBg = it; sp.edit().putBoolean("opt_killbg", it).apply()
        }
        addToggle(c, "Clear Cache On Boost", "Wipe HPX SMINE cache during boost", clearCache) {
            clearCache = it; sp.edit().putBoolean("opt_clearcache", it).apply()
        }
    }

    private fun addToggle(
        parent: LinearLayout, title: String, desc: String, checked: Boolean,
        onChange: (Boolean) -> Unit
    ) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_toggle_row, parent, false)
        row.findViewById<TextView>(R.id.toggleTitle).text = title
        row.findViewById<TextView>(R.id.toggleDesc).text = desc
        val sw = row.findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.toggleSwitch)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
        parent.addView(row)
    }

    private fun refreshStats() {
        val ram = CacheUtils.ram(this)
        findViewById<TextView>(R.id.txtRam).text =
            "${CacheUtils.formatSize(ram.used)} / ${CacheUtils.formatSize(ram.total)}"
        findViewById<ProgressBar>(R.id.barRam).progress = ram.usedPercent

        val st = CacheUtils.storage()
        findViewById<TextView>(R.id.txtStorage).text =
            "${CacheUtils.formatSize(st.used)} / ${CacheUtils.formatSize(st.total)}"
        findViewById<ProgressBar>(R.id.barStorage).progress = st.usedPercent
    }

    private fun boost() {
        val before = CacheUtils.ram(this).avail
        var freedCache = 0L

        if (killBg) CacheUtils.killBackgroundProcesses(this)
        if (clearCache) freedCache = CacheUtils.clearAppCache(this)

        // nudge GC / drop caches of our own process
        System.gc()

        refreshStats()
        val after = CacheUtils.ram(this).avail
        val gained = (after - before).coerceAtLeast(0)

        val msg = buildString {
            append("⚡ Boost complete\n")
            append("• RAM freed: ${CacheUtils.formatSize(gained)}\n")
            if (clearCache) append("• Cache cleared: ${CacheUtils.formatSize(freedCache)}\n")
            if (killBg) append("• Background apps stopped\n")
            append("• Available RAM: ${CacheUtils.formatSize(after)}")
        }
        findViewById<TextView>(R.id.txtBoostResult).text = msg
        Toast.makeText(this, "Boost complete", Toast.LENGTH_SHORT).show()
    }
}

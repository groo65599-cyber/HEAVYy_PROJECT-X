package com.flvhpx.smine.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File

/**
 * Storage / memory helpers for the Cache Cleaner feature.
 */
object CacheUtils {

    fun appCacheSize(context: Context): Long = dirSize(context.cacheDir)

    fun appExternalCacheSize(context: Context): Long {
        val dir = context.externalCacheDir ?: return 0
        return dirSize(dir)
    }

    fun totalAppCache(context: Context): Long = appCacheSize(context) + appExternalCacheSize(context)

    fun clearAppCache(context: Context): Long {
        val before = totalAppCache(context)
        try {
            context.cacheDir?.listFiles()?.forEach { it.deleteRecursively() }
            context.externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
        } catch (_: Exception) {}
        return before
    }

    private fun dirSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0
        return try {
            dir.walkBottomUp().filter { it.isFile }.sumOf { it.length() }
        } catch (_: Exception) {
            0
        }
    }

    data class Storage(val total: Long, val free: Long) {
        val used: Long get() = total - free
        val usedPercent: Int get() = if (total <= 0) 0 else ((used * 100) / total).toInt()
    }

    fun storage(): Storage {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            Storage(stat.blockCountLong * stat.blockSizeLong, stat.availableBlocksLong * stat.blockSizeLong)
        } catch (e: Exception) {
            Storage(0, 0)
        }
    }

    data class Ram(val total: Long, val avail: Long) {
        val used: Long get() = total - avail
        val usedPercent: Int get() = if (total <= 0) 0 else ((used * 100) / total).toInt()
    }

    fun ram(context: Context): Ram {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            Ram(mi.totalMem, mi.availMem)
        } catch (e: Exception) {
            Ram(0, 0)
        }
    }

    fun killBackgroundProcesses(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pm = context.packageManager
            for (pkg in pm.getInstalledPackages(0)) {
                if (pkg.packageName == context.packageName) continue
                try {
                    am.killBackgroundProcesses(pkg.packageName)
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digit = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, 4)
        val value = bytes / Math.pow(1024.0, digit.toDouble())
        return String.format("%.2f %s", value, units[digit])
    }
}

package com.flvhpx.smine.util

import android.content.Context
import android.provider.Settings

/**
 * Local account store for HPX SMINE.
 *
 * v2.0.4: accounts are now PER-DEVICE. Instead of the old shared default
 * (HPX-USER / HPX-2025 on every phone) each device derives a stable, unique
 * username + password from its ANDROID_ID, e.g.
 *
 *     device 1 -> HPX-HGY68XC / HPX0001
 *     device 2 -> HPX-HHJK997L / HPX09887
 *
 * The credentials are persisted locally and exposed to the companion app
 * (HPX PREMM ACCESS) through [com.flvhpx.smine.provider.AccountProvider] so a
 * free account can still be upgraded. The user may override the password from
 * the Account screen, but the generated username is the device identity.
 */
class AccountStore(private val context: Context) {

    private val prefs = Prefs(context)

    /** Ensure an account exists; returns true if a new one was created. */
    fun ensureAccount(): Boolean {
        if (prefs.accountUsername.isNotBlank()) return false
        prefs.accountUsername = deviceUsername()
        prefs.accountPassword = devicePassword()
        prefs.accountTier = "FREE"
        prefs.accountExpiry = 0L
        prefs.accountCreatedAt = System.currentTimeMillis()
        prefs.energy = 300
        return true
    }

    fun username(): String = prefs.accountUsername
    fun password(): String = prefs.accountPassword
    fun tier(): String = prefs.accountTier
    fun expiry(): Long = prefs.accountExpiry
    fun createdAt(): Long = prefs.accountCreatedAt

    /**
     * Update the locally stored login credentials. Blank values are ignored so
     * the account can never end up without a username/password.
     */
    fun setCredentials(newUsername: String, newPassword: String): Boolean {
        val u = newUsername.trim()
        val p = newPassword.trim()
        if (u.isEmpty() || p.isEmpty()) return false
        prefs.accountUsername = u
        prefs.accountPassword = p
        return true
    }

    /** Reset the credentials back to this device's generated defaults. */
    fun resetCredentials() {
        prefs.accountUsername = deviceUsername()
        prefs.accountPassword = devicePassword()
    }

    /** Apply an upgrade coming from the admin app. */
    fun upgrade(tier: String, durationDays: Int) {
        prefs.accountTier = tier
        prefs.accountExpiry = if (durationDays <= 0) 0L
        else System.currentTimeMillis() + durationDays.toLong() * 86_400_000L
    }

    fun isPremium(): Boolean = prefs.isPremiumTier()
    fun isDeveloper(): Boolean = prefs.isDeveloper()

    fun tierLabel(): String {
        val t = prefs.accountTier
        if (t == "FREE") return "FREE"
        val exp = prefs.accountExpiry
        if (exp != 0L && exp <= System.currentTimeMillis()) return "FREE (expired)"
        return t
    }

    // ------------------------------------------------------------------
    //  Per-device identity
    // ------------------------------------------------------------------

    /** Stable seed for this device: ANDROID_ID, or a persisted fallback. */
    private fun deviceSeed(): String {
        val id = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) {
            null
        }
        if (!id.isNullOrBlank()) return id.uppercase()
        if (prefs.deviceSeed.isBlank()) {
            prefs.deviceSeed = java.util.UUID.randomUUID().toString()
                .replace("-", "").take(16).uppercase()
        }
        return prefs.deviceSeed
    }

    /** e.g. "HPX-HGY68XC" — 8-char alphanumeric device code. */
    fun deviceUsername(): String {
        val seed = deviceSeed()
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        var h = (seed.hashCode().toLong() and 0xFFFFFFFFL) or 1L
        val code = buildString {
            repeat(8) {
                h = (h * 1103515245L + 12345L) and 0x7FFFFFFFL
                append(alphabet[((h shr 3) % alphabet.length).toInt()])
            }
        }
        return "HPX-$code"
    }

    /** e.g. "HPX0001" — 4-digit numeric password. */
    fun devicePassword(): String {
        val seed = deviceSeed()
        var h = (seed.hashCode().toLong() and 0xFFFFFFFFL) or 1L
        h = (h * 2654435761L) and 0x7FFFFFFFL
        val n = ((h shr 5) % 10000L).toInt()
        return "HPX" + n.toString().padStart(4, '0')
    }

    companion object {
        /** Fallback shown only if the device id cannot be read at all. */
        const val DEFAULT_USERNAME = "HPX-USER"
        const val DEFAULT_PASSWORD = "HPX-0000"
    }
}

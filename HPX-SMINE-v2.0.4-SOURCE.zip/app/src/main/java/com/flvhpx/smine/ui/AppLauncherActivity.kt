package com.flvhpx.smine.ui

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.flvhpx.smine.R
import com.flvhpx.smine.service.OverlayService
import com.flvhpx.smine.util.EnergyManager
import com.flvhpx.smine.util.Prefs

class AppLauncherActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var energy: EnergyManager
    private val selected = mutableListOf<String>()

    private data class AppEntry(val label: String, val pkg: String, val icon: Drawable)

    private val isPremium: Boolean get() = prefs.isPremiumTier()
    private val maxSlots: Int get() = if (isPremium) Int.MAX_VALUE else 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_launcher)
        setupHeader("APP LAUNCHER", "Run apps while gaming")
        prefs = Prefs(this)
        energy = EnergyManager(this)
        selected.clear()
        selected.addAll(prefs.launcherList())

        findViewById<Button>(R.id.btnAddApp).setOnClickListener { showPicker() }
        findViewById<Button>(R.id.btnLaunchAll).setOnClickListener { launchAll() }
        val sw = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.switchAutoLogin)
        sw.isChecked = prefs.autoLogin
        sw.setOnCheckedChangeListener { _, b -> prefs.autoLogin = b }

        refreshQuotaLabel()
        renderSlots()
    }

    private fun refreshQuotaLabel() {
        val tv = findViewById<TextView>(R.id.txtQuota)
        tv.text = if (isPremium) {
            "PREMIUM \u2022 unlimited apps \u2022 unlimited energy"
        } else {
            "FREE \u2022 ${selected.size}/3 apps \u2022 energy ${energy.current()}/${energy.max()} (100 per run)"
        }
    }

    private fun renderSlots() {
        val c = findViewById<LinearLayout>(R.id.slotContainer)
        c.removeAllViews()
        val slots = if (isPremium) (selected.size + 1).coerceAtMost(12) else 3
        for (i in 0 until slots) {
            val row = LayoutInflater.from(this).inflate(R.layout.item_app_row, c, false)
            val icon = row.findViewById<ImageView>(R.id.appIcon)
            val name = row.findViewById<TextView>(R.id.appName)
            val pkgTv = row.findViewById<TextView>(R.id.appPkg)
            val check = row.findViewById<ImageView>(R.id.appCheck)

            if (i < selected.size) {
                val pkg = selected[i]
                name.text = appLabel(pkg)
                pkgTv.text = pkg
                icon.setImageDrawable(appIcon(pkg))
                check.setImageResource(R.drawable.ic_close)
                check.setColorFilter(0xFFFF3D57.toInt())
                row.setOnClickListener { launchApp(pkg) }
                check.setOnClickListener { removeApp(pkg) }
            } else {
                name.text = "Empty slot"
                pkgTv.text = "Tap + ADD APP to choose"
                icon.setImageResource(R.drawable.ic_add)
                icon.setColorFilter(0x66FFFFFF.toInt())
                check.setImageResource(R.drawable.ic_add)
                check.setColorFilter(0x66FF2D9B.toInt())
                row.setOnClickListener { showPicker() }
                check.setOnClickListener { showPicker() }
            }
            c.addView(row)
        }
    }

    private fun showPicker() {
        if (selected.size >= maxSlots) {
            Toast.makeText(this, "Free tier is limited to 3 apps. Upgrade for unlimited.", Toast.LENGTH_LONG).show()
            return
        }
        val apps = loadApps()
        val names = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select an app")
            .setItems(names) { _, which ->
                val pkg = apps[which].pkg
                when {
                    selected.contains(pkg) -> Toast.makeText(this, "Already added", Toast.LENGTH_SHORT).show()
                    selected.size >= maxSlots -> Toast.makeText(this, "Free tier is limited to 3 apps", Toast.LENGTH_SHORT).show()
                    else -> {
                        selected.add(pkg)
                        save()
                        refreshQuotaLabel()
                        renderSlots()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val list = mutableListOf<AppEntry>()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(intent, 0)
        for (ri in resolved) {
            val ai: ApplicationInfo = ri.activityInfo.applicationInfo
            if (ai.packageName == packageName) continue
            list.add(AppEntry(ri.loadLabel(pm).toString(), ai.packageName, ri.loadIcon(pm)))
        }
        list.sortBy { it.label.lowercase() }
        return list
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun appIcon(pkg: String): Drawable = try {
        packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) {
        getDrawable(R.drawable.ic_apps)!!
    }

    private fun removeApp(pkg: String) {
        selected.remove(pkg)
        save()
        refreshQuotaLabel()
        renderSlots()
    }

    private fun save() {
        prefs.setLauncherList(selected)
        if (prefs.overlayEnabled) OverlayService.reload(this)
    }

    private fun launchApp(pkg: String) {
        if (!energy.tryConsumeForRun()) {
            Toast.makeText(this, "Not enough energy. Watch an ad in the Account tab to earn more.", Toast.LENGTH_LONG).show()
            return
        }
        refreshQuotaLabel()
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }
            else Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchAll() {
        if (selected.isEmpty()) {
            Toast.makeText(this, "No apps selected", Toast.LENGTH_SHORT).show()
            return
        }
        if (prefs.autoLogin) {
            for (pkg in selected) launchApp(pkg)
        } else {
            launchApp(selected.first())
        }
    }
}

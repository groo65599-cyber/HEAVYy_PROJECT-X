package com.flvhpx.smine.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.flvhpx.smine.R

/**
 * Shared behaviour for the feature screens (header + back handling).
 */
abstract class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    protected fun setupHeader(title: String, sub: String = "") {
        findViewById<ImageView>(R.id.btnBack)?.setOnClickListener { finish() }
        findViewById<TextView>(R.id.headerTitle)?.text = title
        findViewById<TextView>(R.id.headerSub)?.apply {
            text = sub
            visibility = if (sub.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
        }
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}

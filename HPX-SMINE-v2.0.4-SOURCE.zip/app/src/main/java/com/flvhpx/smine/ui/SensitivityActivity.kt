package com.flvhpx.smine.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.util.Prefs

class SensitivityActivity : BaseActivity() {

    private val labels = listOf(
        "General", "Red Dot", "2x Scope", "4x Scope", "AWM Scope", "Free Look"
    )
    private val lowPreset = intArrayOf(90, 85, 80, 70, 60, 75)
    private val highPreset = intArrayOf(100, 100, 95, 90, 85, 100)

    private val values = IntArray(6)
    private lateinit var prefs: Prefs
    private var mode = "LOW"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensitivity)
        setupHeader("SENSITIVITY", "Free Fire · Low & High presets")
        prefs = Prefs(this)
        mode = prefs.sensiMode

        val toggle = findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.toggleMode)
        if (mode == "HIGH") toggle.check(R.id.btnHigh) else toggle.check(R.id.btnLow)
        toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                mode = if (checkedId == R.id.btnHigh) "HIGH" else "LOW"
                loadPreset()
                buildRows()
            }
        }

        findViewById<TextView>(R.id.txtModeInfo).text = modeInfo(mode)
        loadPreset()
        buildRows()

        findViewById<android.widget.Button>(R.id.btnResetSensi).setOnClickListener {
            loadPreset(); buildRows(); toast("Preset restored")
        }
        findViewById<android.widget.Button>(R.id.btnSaveSensi).setOnClickListener {
            prefs.sensiMode = mode
            saveValues()
            toast("Sensitivity saved")
        }
    }

    private fun modeInfo(m: String) = if (m == "HIGH")
        "HIGH SENSI · aggressive flicks, fast close-range tracking" else
        "LOW SENSI · steady long-range aim, minimal recoil drift"

    private fun loadPreset() {
        val saved = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
            .getString("sensi_vals_$mode", null)
        if (saved != null) {
            val parts = saved.split(",")
            for (i in 0 until 6) values[i] = parts.getOrNull(i)?.toIntOrNull()
                ?: if (mode == "HIGH") highPreset[i] else lowPreset[i]
        } else {
            val preset = if (mode == "HIGH") highPreset else lowPreset
            for (i in 0 until 6) values[i] = preset[i]
        }
    }

    private fun saveValues() {
        getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
            .putString("sensi_vals_$mode", values.joinToString(","))
            .apply()
    }

    private fun buildRows() {
        val c = findViewById<LinearLayout>(R.id.sensiContainer)
        c.removeAllViews()
        for (i in labels.indices) {
            val row = LayoutInflater.from(this).inflate(R.layout.item_sensi_row, c, false)
            val label = row.findViewById<TextView>(R.id.sensiLabel)
            val value = row.findViewById<TextView>(R.id.sensiValue)
            val seek = row.findViewById<SeekBar>(R.id.sensiSeek)
            label.text = labels[i]
            value.text = values[i].toString()
            seek.progress = values[i]
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    values[i] = p
                    value.text = p.toString()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            c.addView(row)
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}

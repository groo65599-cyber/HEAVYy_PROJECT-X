package com.flvhpx.smine.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi
import com.flvhpx.smine.util.MacroManager

/**
 * HPX SMINE Macro playback engine (v2.0.4).
 *
 * This accessibility service is the ONLY way an ordinary (non-root) app can
 * inject taps / swipes into another app (the running game). It also tracks the
 * current foreground package so the overlay's "Clear Cache" button knows which
 * app is on screen.
 *
 * The user must enable it once from Settings ▸ Accessibility ▸ HPX SMINE Macro.
 */
@RequiresApi(Build.VERSION_CODES.N)
class MacroAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MacroAccessibilityService? = null
            private set

        /** Package currently in the foreground (best-effort, from a11y events). */
        @Volatile
        var foregroundPackage: String? = null
            private set

        fun isConnected(): Boolean = instance != null

        fun isPlaying(): Boolean = instance?.playing == true

        /** Returns true if the macro started playing. */
        fun play(steps: List<MacroManager.Step>, loop: Boolean, speedX10: Int): Boolean {
            val svc = instance ?: return false
            return svc.startPlayback(steps, loop, speedX10)
        }

        fun stopPlayback() {
            instance?.stopPlayback()
        }
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var playing = false
    private var loopRun = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            e.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED
        ) {
            e.packageName?.let { if (it.isNotBlank()) foregroundPackage = it.toString() }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        stopPlayback()
        if (instance === this) instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    //  Playback
    // ------------------------------------------------------------------
    private fun startPlayback(steps: List<MacroManager.Step>, loop: Boolean, speedX10: Int): Boolean {
        if (steps.isEmpty()) return false
        if (playing) return false
        playing = true
        loopRun = loop
        val speed = (speedX10.coerceIn(5, 30) / 10f)
        runStep(steps, 0, speed)
        return true
    }

    private fun stopPlayback() {
        playing = false
        loopRun = false
        main.removeCallbacksAndMessages(null)
    }

    private fun runStep(steps: List<MacroManager.Step>, index: Int, speed: Float) {
        if (!playing) return
        if (index >= steps.size) {
            if (loopRun) { runStep(steps, 0, speed) }
            else { playing = false }
            return
        }
        val step = steps[index]
        val delay = (step.delayMs / speed).toLong().coerceAtLeast(0L)
        main.postDelayed({
            if (!playing) return@postDelayed
            dispatch(step, speed) {
                runStep(steps, index + 1, speed)
            }
        }, delay)
    }

    private fun dispatch(step: MacroManager.Step, speed: Float, onDone: () -> Unit) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val path = Path()
        path.moveTo(step.x1 * w, step.y1 * h)
        if (step.isSwipe) path.lineTo(step.x2 * w, step.y2 * h)

        val duration = (step.durationMs / speed).toLong().coerceIn(1L, 10_000L)
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { onDone() }
            override fun onCancelled(gestureDescription: GestureDescription?) { onDone() }
        }, main)
        if (!ok) onDone()
    }
}

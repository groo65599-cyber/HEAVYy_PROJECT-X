package com.flvhpx.smine.ui

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.util.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

/**
 * Network Optimizer screen (Premium).
 * Lets the user pick low-latency DNS servers and run a quick ping test.
 * The actual DNS override is applied by the overlay service while a game runs.
 */
class NetworkActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var editDns1: EditText
    private lateinit var editDns2: EditText
    private lateinit var txtPing: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_network)
        setupHeader(getString(R.string.network_title), getString(R.string.network_sub))
        prefs = Prefs(this)

        editDns1 = findViewById(R.id.editDns1)
        editDns2 = findViewById(R.id.editDns2)
        txtPing = findViewById(R.id.txtPingResult)

        editDns1.setText(prefs.netDnsPrimary)
        editDns2.setText(prefs.netDnsSecondary)

        val sw = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.swNet)
        sw.isChecked = prefs.netOptimizerEnabled
        sw.setOnCheckedChangeListener { _, b -> prefs.netOptimizerEnabled = b }

        findViewById<Button>(R.id.btnTestPing).setOnClickListener { testPing() }
        findViewById<Button>(R.id.btnApplyNet).setOnClickListener { apply() }

        applyPremiumLock()
    }

    private fun applyPremiumLock() {
        val premium = prefs.isPremiumTier()
        findViewById<View>(R.id.cardLock).visibility = if (premium) View.GONE else View.VISIBLE
        findViewById<View>(R.id.swNet).isEnabled = premium
        findViewById<View>(R.id.btnApplyNet).isEnabled = premium
        findViewById<View>(R.id.btnTestPing).isEnabled = premium
        editDns1.isEnabled = premium
        editDns2.isEnabled = premium
    }

    private fun testPing() {
        val host = editDns1.text.toString().trim().ifBlank { "1.1.1.1" }
        txtPing.text = "Pinging $host ..."
        CoroutineScope(Dispatchers.IO).launch {
            val result = try {
                val addr = InetAddress.getByName(host)
                val start = System.nanoTime()
                val reachable = addr.isReachable(2500)
                val ms = (System.nanoTime() - start) / 1_000_000
                if (reachable) "$host  \u2022  ${ms}ms  \u2022  ONLINE" else "$host  \u2022  UNREACHABLE"
            } catch (e: Exception) {
                "Ping failed: ${e.message ?: "unknown"}"
            }
            withContext(Dispatchers.Main) { txtPing.text = result }
        }
    }

    private fun apply() {
        val d1 = editDns1.text.toString().trim()
        val d2 = editDns2.text.toString().trim()
        if (!isValidIp(d1) || !isValidIp(d2)) {
            Toast.makeText(this, "Enter valid DNS addresses", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.netDnsPrimary = d1
        prefs.netDnsSecondary = d2
        prefs.netOptimizerEnabled = true
        Toast.makeText(this, "Network optimization applied", Toast.LENGTH_SHORT).show()
    }

    private fun isValidIp(s: String): Boolean {
        val parts = s.split(".")
        if (parts.size != 4) return false
        return parts.all { p -> p.toIntOrNull()?.let { it in 0..255 } == true }
    }
}

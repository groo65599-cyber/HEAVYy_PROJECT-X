package com.flvhpx.smine.provider

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import com.flvhpx.smine.util.AccountStore
import com.flvhpx.smine.util.Prefs

/**
 * Cross-app account provider. The companion admin app (HPX PREMM ACCESS)
 * queries this provider to read a free account and upgrade its tier.
 *
 * Authority: com.flvhpx.smine.accounts
 * Paths:
 *   accounts/current          -> read the current account (username, password, tier, expiry)
 *   accounts/upgrade          -> upgrade the current account
 *       query params: tier=PREMIUM|VVIP|DEVELOPER, days=0|1|2|7|30
 */
class AccountProvider : ContentProvider() {

    companion object {
        const val AUTHORITY = "com.flvhpx.smine.accounts"
        const val PATH_CURRENT = "current"
        const val PATH_UPGRADE = "upgrade"

        private const val CODE_CURRENT = 1
        private const val CODE_UPGRADE = 2

        val CONTENT_URI: Uri = Uri.parse("content://$AUTHORITY/accounts")

        private val matcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(AUTHORITY, "accounts/$PATH_CURRENT", CODE_CURRENT)
            addURI(AUTHORITY, "accounts/$PATH_UPGRADE", CODE_UPGRADE)
        }
    }

    override fun onCreate(): Boolean = true

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor? {
        val ctx = context ?: return null
        val store = AccountStore(ctx)
        store.ensureAccount()

        return when (matcher.match(uri)) {
            CODE_CURRENT, CODE_UPGRADE -> {
                val cursor = MatrixCursor(arrayOf("username", "password", "tier", "expiry", "premium"))
                cursor.addRow(
                    arrayOf(
                        store.username(),
                        store.password(),
                        store.tier(),
                        store.expiry(),
                        if (store.isPremium()) 1 else 0
                    )
                )
                cursor
            }
            else -> null
        }
    }

    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<out String>?
    ): Int {
        val ctx = context ?: return 0
        if (matcher.match(uri) != CODE_UPGRADE) return 0

        val tier = values?.getAsString("tier") ?: return 0
        val days = values.getAsInteger("days") ?: 0
        val username = values.getAsString("username")
        val password = values.getAsString("password")

        val store = AccountStore(ctx)
        store.ensureAccount()

        // Optional credential check: if provided, they must match.
        if (!username.isNullOrBlank() && username != store.username()) return 0
        if (!password.isNullOrBlank() && password != store.password()) return 0

        store.upgrade(tier.uppercase(), days)
        ctx.contentResolver.notifyChange(uri, null)
        return 1
    }

    override fun getType(uri: Uri): String = "vnd.android.cursor.item/vnd.hpx.account"

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
}

package com.flvhpx.smine.ui

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.service.OverlayService
import com.flvhpx.smine.util.Prefs
import com.flvhpx.smine.util.SystemMonitor

class MonitorActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private var monitor: SystemMonitor? = null
    private var previewRoot: View? = null

    private var showFps = true
    private var showCpu = true
    private var showGpu = true
    private var showRam = true
    private var showBattery = true
    private var showTime = true
    private var position = 0
    private var orientation = 0 // 0 = horizontal (ROG bar), 1 = vertical

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monitor)
        setupHeader("LIFETIME MONITOR", "Real-time FPS \u00b7 CPU \u00b7 GPU \u00b7 Battery")
        prefs = Prefs(this)

        showFps = prefs.monitorShowFps
        showCpu = prefs.monitorShowCpu
        showGpu = prefs.monitorShowGpu
        showRam = prefs.monitorShowRam
        showBattery = prefs.monitorShowBattery
        showTime = prefs.monitorShowTime
        position = prefs.monitorPosition
        orientation = prefs.monitorOrientation

        previewRoot = findViewById(R.id.monitorPreview)
        buildMetrics()
        buildPositions()
        buildOrientations()
        applyVisibility()
        applyOrientation()

        findViewById<android.widget.Button>(R.id.btnApplyMonitor).setOnClickListener {
            save(); Toast.makeText(this, "Monitor applied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        monitor = SystemMonitor { s ->
            previewRoot?.findViewById<TextView>(R.id.txtFps)?.text = "${s.fps}"
            previewRoot?.findViewById<TextView>(R.id.txtCpu)?.text = "${s.cpu.toInt()}%"
            previewRoot?.findViewById<TextView>(R.id.txtGpu)?.text =
                if (s.gpu < 0f) "N/A" else "${s.gpu.toInt()}%"
            previewRoot?.findViewById<TextView>(R.id.txtRam)?.text =
                String.format("%.1f/%dG", s.ramUsedMb / 1024f, s.ramTotalMb / 1024)
            previewRoot?.findViewById<TextView>(R.id.txtBattery)?.text = "${s.batteryPercent}%"
            previewRoot?.findViewById<TextView>(R.id.txtTime)?.text = s.time
        }.also { it.start() }
    }

    override fun onPause() {
        monitor?.stop(); monitor = null
        super.onPause()
    }

    private fun applyVisibility() {
        previewRoot?.findViewById<View>(R.id.rowFps)?.visibility = if (showFps) View.VISIBLE else View.GONE
        previewRoot?.findViewById<View>(R.id.rowCpu)?.visibility = if (showCpu) View.VISIBLE else View.GONE
        previewRoot?.findViewById<View>(R.id.rowGpu)?.visibility = if (showGpu) View.VISIBLE else View.GONE
        previewRoot?.findViewById<View>(R.id.rowRam)?.visibility = if (showRam) View.VISIBLE else View.GONE
        previewRoot?.findViewById<View>(R.id.rowBattery)?.visibility = if (showBattery) View.VISIBLE else View.GONE
        previewRoot?.findViewById<View>(R.id.rowTime)?.visibility = if (showTime) View.VISIBLE else View.GONE
    }

    private fun applyOrientation() {
        (previewRoot as? LinearLayout)?.orientation =
            if (orientation == 0) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
    }

    private fun buildMetrics() {
        val c = findViewById<LinearLayout>(R.id.metricContainer)
        c.removeAllViews()
        addToggle(c, "FPS", "Frames per second", showFps) { showFps = it; applyVisibility() }
        addToggle(c, "CPU", "Processor usage", showCpu) { showCpu = it; applyVisibility() }
        addToggle(c, "GPU", "Graphics usage (device dependent)", showGpu) { showGpu = it; applyVisibility() }
        addToggle(c, "RAM", "Memory usage", showRam) { showRam = it; applyVisibility() }
        addToggle(c, "Battery", "Battery level", showBattery) { showBattery = it; applyVisibility() }
        addToggle(c, "Clock", "Current time", showTime) { showTime = it; applyVisibility() }
    }

    private fun addToggle(parent: LinearLayout, t: String, d: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_toggle_row, parent, false)
        row.findViewById<TextView>(R.id.toggleTitle).text = t
        row.findViewById<TextView>(R.id.toggleDesc).text = d
        val sw = row.findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.toggleSwitch)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, b -> onChange(b) }
        parent.addView(row)
    }

    private fun buildPositions() {
        val grid = findViewById<GridLayout>(R.id.positionGrid)
        grid.removeAllViews()
        val names = listOf("TOP L", "TOP R", "BOT L", "BOT R")
        val density = resources.displayMetrics.density
        for (i in names.indices) {
            val tv = TextView(this)
            tv.text = names[i]
            tv.textSize = 11f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(0xFFF5F7FF.toInt())
            tv.background = getDrawable(R.drawable.bg_chip)
            tv.setPadding(0, (density * 10).toInt(), 0, (density * 10).toInt())
            val lp = GridLayout.LayoutParams()
            lp.width = 0
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT
            lp.columnSpec = GridLayout.spec(i, 1f)
            lp.setMargins((density * 4).toInt(), 0, (density * 4).toInt(), 0)
            tv.layoutParams = lp
            tv.isSelected = i == position
            tv.setOnClickListener {
                position = i
                for (k in 0 until grid.childCount) grid.getChildAt(k).isSelected = k == i
            }
            grid.addView(tv)
        }
    }

    private fun buildOrientations() {
        val c = findViewById<LinearLayout>(R.id.orientationContainer)
        c.removeAllViews()
        val names = listOf("HORIZONTAL (ROG)", "VERTICAL")
        val density = resources.displayMetrics.density
        for (i in names.indices) {
            val tv = TextView(this)
            tv.text = names[i]
            tv.textSize = 11f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(0xFFF5F7FF.toInt())
            tv.background = getDrawable(R.drawable.bg_chip)
            tv.setPadding((density * 14).toInt(), (density * 10).toInt(), (density * 14).toInt(), (density * 10).toInt())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = (density * 8).toInt()
            tv.layoutParams = lp
            tv.isSelected = i == orientation
            tv.setOnClickListener {
                orientation = i
                for (k in 0 until c.childCount) c.getChildAt(k).isSelected = k == i
                applyOrientation()
            }
            c.addView(tv)
        }
    }

    private fun save() {
        prefs.monitorShowFps = showFps
        prefs.monitorShowCpu = showCpu
        prefs.monitorShowGpu = showGpu
        prefs.monitorShowRam = showRam
        prefs.monitorShowBattery = showBattery
        prefs.monitorShowTime = showTime
        prefs.monitorPosition = position
        prefs.monitorOrientation = orientation
        prefs.monitorEnabled = true
        if (prefs.overlayEnabled) OverlayService.reload(this)
    }
}

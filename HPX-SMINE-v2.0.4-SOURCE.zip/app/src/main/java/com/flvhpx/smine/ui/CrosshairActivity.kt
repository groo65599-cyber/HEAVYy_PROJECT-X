package com.flvhpx.smine.ui

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.model.Crosshair
import com.flvhpx.smine.service.OverlayService
import com.flvhpx.smine.util.Prefs
import com.flvhpx.smine.view.CrosshairView

class CrosshairActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var preview: CrosshairView

    private var style = 0
    private var color = 0
    private var size = 42
    private var gap = 8
    private var thickness = 3
    private var dot = true
    private var glow = true
    private var alpha = 100
    private var offsetX = 0
    private var offsetY = 0

    private lateinit var styleContainer: LinearLayout
    private lateinit var colorContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crosshair)
        setupHeader("CROSSHAIR", "Styles \u00b7 Colors \u00b7 Position \u00b7 Overlay")
        prefs = Prefs(this)

        style = prefs.crosshairStyle
        color = prefs.crosshairColor
        size = prefs.crosshairSize
        gap = prefs.crosshairGap
        thickness = prefs.crosshairThickness
        dot = prefs.crosshairDot
        glow = prefs.crosshairGlow
        alpha = prefs.crosshairAlpha
        offsetX = prefs.crosshairOffsetX
        offsetY = prefs.crosshairOffsetY

        preview = findViewById(R.id.preview)
        styleContainer = findViewById(R.id.styleContainer)
        colorContainer = findViewById(R.id.colorContainer)

        buildStyles()
        buildColors()
        buildSliders()
        setupToggles()
        updatePreview()

        findViewById<android.widget.Button>(R.id.btnApplyCrosshair).setOnClickListener {
            save()
            Toast.makeText(this, "Crosshair applied", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePreview() {
        preview.applyConfig(
            style, color,
            size * resources.displayMetrics.density,
            gap * resources.displayMetrics.density,
            thickness * resources.displayMetrics.density,
            dot, glow, alpha,
            offsetX * resources.displayMetrics.density,
            offsetY * resources.displayMetrics.density
        )
    }

    private fun buildStyles() {
        styleContainer.removeAllViews()
        val density = resources.displayMetrics.density
        for ((i, name) in Crosshair.STYLE_NAMES.withIndex()) {
            val chip = TextView(this)
            chip.text = name
            chip.textSize = 12f
            chip.gravity = Gravity.CENTER
            chip.setTextColor(0xFFF5F7FF.toInt())
            chip.background = getDrawable(R.drawable.bg_chip)
            chip.setPadding(
                (density * 16).toInt(), (density * 9).toInt(),
                (density * 16).toInt(), (density * 9).toInt()
            )
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = (density * 8).toInt()
            chip.layoutParams = lp
            chip.isSelected = i == style
            chip.setOnClickListener {
                style = i
                for (k in 0 until styleContainer.childCount)
                    styleContainer.getChildAt(k).isSelected = k == i
                updatePreview()
            }
            styleContainer.addView(chip)
        }
    }

    private fun buildColors() {
        colorContainer.removeAllViews()
        val density = resources.displayMetrics.density
        for ((i, pair) in Crosshair.COLORS.withIndex()) {
            val dotView = View(this)
            val s = (density * 38).toInt()
            val lp = LinearLayout.LayoutParams(s, s)
            lp.marginEnd = (density * 10).toInt()
            dotView.layoutParams = lp
            dotView.tag = pair.second
            setDot(dotView, pair.second, i == indexOfColor(color))
            dotView.setOnClickListener {
                color = pair.second
                for (k in 0 until colorContainer.childCount) {
                    val v = colorContainer.getChildAt(k)
                    setDot(v, v.tag as Int, v === dotView)
                }
                updatePreview()
            }
            colorContainer.addView(dotView)
        }
    }

    private fun indexOfColor(c: Int): Int {
        val idx = Crosshair.COLORS.indexOfFirst { it.second == c }
        return if (idx < 0) 0 else idx
    }

    private fun setDot(v: View, c: Int, selected: Boolean) {
        val gd = GradientDrawable()
        gd.shape = GradientDrawable.OVAL
        gd.setColor(c)
        gd.setStroke(
            if (selected) (resources.displayMetrics.density * 3).toInt() else (resources.displayMetrics.density * 1).toInt(),
            0xFFFFFFFF.toInt()
        )
        v.background = gd
        v.isSelected = selected
    }

    private fun buildSliders() {
        val c = findViewById<LinearLayout>(R.id.sliderContainer)
        c.removeAllViews()
        addSlider(c, "Size", size, 10, 100) { size = it; updatePreview() }
        addSlider(c, "Gap", gap, 0, 40) { gap = it; updatePreview() }
        addSlider(c, "Thickness", thickness, 1, 12) { thickness = it; updatePreview() }
        addSlider(c, "Transparency", alpha, 10, 100) { alpha = it; updatePreview() }
        addSlider(c, "Position X", offsetX, -300, 300) { offsetX = it; updatePreview() }
        addSlider(c, "Position Y", offsetY, -300, 300) { offsetY = it; updatePreview() }
    }

    private fun addSlider(
        parent: LinearLayout, label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit
    ) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_sensi_row, parent, false)
        row.findViewById<TextView>(R.id.sensiLabel).text = label
        val valueTv = row.findViewById<TextView>(R.id.sensiValue)
        valueTv.text = value.toString()
        val seek = row.findViewById<SeekBar>(R.id.sensiSeek)
        seek.max = max - min
        seek.progress = value - min
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                valueTv.text = v.toString()
                onChange(v)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        parent.addView(row)
    }

    private fun setupToggles() {
        val swDot = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.switchDot)
        swDot.isChecked = dot
        swDot.setOnCheckedChangeListener { _, b -> dot = b; updatePreview() }

        val swGlow = findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.switchGlow)
        swGlow.isChecked = glow
        swGlow.setOnCheckedChangeListener { _, b -> glow = b; updatePreview() }
    }

    private fun save() {
        prefs.crosshairStyle = style
        prefs.crosshairColor = color
        prefs.crosshairSize = size
        prefs.crosshairGap = gap
        prefs.crosshairThickness = thickness
        prefs.crosshairDot = dot
        prefs.crosshairGlow = glow
        prefs.crosshairAlpha = alpha
        prefs.crosshairOffsetX = offsetX
        prefs.crosshairOffsetY = offsetY
        prefs.crosshairEnabled = true
        if (prefs.overlayEnabled) OverlayService.reload(this)
    }
}

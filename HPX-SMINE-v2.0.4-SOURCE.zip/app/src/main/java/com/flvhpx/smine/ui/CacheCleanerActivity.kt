package com.flvhpx.smine.ui

import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.util.CacheUtils

class CacheCleanerActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cache_cleaner)
        setupHeader("CACHE CLEANER", "Free up memory & storage")

        findViewById<Button>(R.id.btnClean).setOnClickListener { clean() }
        refresh()
    }

    private fun refresh() {
        findViewById<TextView>(R.id.txtCacheSize).text =
            CacheUtils.formatSize(CacheUtils.totalAppCache(this))

        val st = CacheUtils.storage()
        findViewById<TextView>(R.id.txtStorage).text =
            "${CacheUtils.formatSize(st.used)} / ${CacheUtils.formatSize(st.total)}"
        findViewById<ProgressBar>(R.id.barStorage).progress = st.usedPercent

        val ram = CacheUtils.ram(this)
        findViewById<TextView>(R.id.txtRam).text =
            "${CacheUtils.formatSize(ram.used)} / ${CacheUtils.formatSize(ram.total)}"
        findViewById<ProgressBar>(R.id.barRam).progress = ram.usedPercent
    }

    private fun clean() {
        val ramBefore = CacheUtils.ram(this).avail
        val cleared = CacheUtils.clearAppCache(this)
        CacheUtils.killBackgroundProcesses(this)
        System.gc()

        refresh()
        val ramAfter = CacheUtils.ram(this).avail
        val gained = (ramAfter - ramBefore).coerceAtLeast(0)

        findViewById<TextView>(R.id.txtCleanResult).text = buildString {
            append("🧹 Clean complete\n")
            append("• Cache cleared: ${CacheUtils.formatSize(cleared)}\n")
            append("• RAM freed: ${CacheUtils.formatSize(gained)}\n")
            append("• Background apps stopped")
        }
        Toast.makeText(this, "Cleaned ${CacheUtils.formatSize(cleared)}", Toast.LENGTH_SHORT).show()
    }
}

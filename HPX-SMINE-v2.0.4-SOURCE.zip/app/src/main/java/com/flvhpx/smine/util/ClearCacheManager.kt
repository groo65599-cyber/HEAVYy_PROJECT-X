package com.flvhpx.smine.util

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Overlay "Clear Cache" helper (v2.0.4).
 *
 * Android blocks one app from wiping ANOTHER app's private cache without root,
 * so we do the strongest thing that IS allowed:
 *   1. find the app currently in the foreground (game),
 *   2. kill its background processes to release RAM,
 *   3. open its App Info page so the user can tap "Clear cache" with one tap.
 * When the foreground app is HPX SMINE itself we clear our own cache directly.
 */
object ClearCacheManager {

    data class Result(val packageName: String, val appLabel: String, val cleared: Boolean)

    fun clearForegroundApp(context: Context, foregroundPackage: String?): Result {
        val pkg = foregroundPackage
            ?: runCatching {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                @Suppress("DEPRECATION")
                am.getRunningTasks(1).firstOrNull()?.topActivity?.packageName
            }.getOrNull()
            ?: context.packageName

        val label = runCatching {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        }.getOrDefault(pkg)

        // Our own app -> we CAN clear the cache for real.
        if (pkg == context.packageName) {
            CacheUtils.clearAppCache(context)
            return Result(pkg, label, true)
        }

        // Another app -> best-effort: kill its background processes.
        runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(pkg)
        }

        // Open its App Info so the user can clear cache with a single tap.
        runCatching {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$pkg")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }

        return Result(pkg, label, false)
    }
}

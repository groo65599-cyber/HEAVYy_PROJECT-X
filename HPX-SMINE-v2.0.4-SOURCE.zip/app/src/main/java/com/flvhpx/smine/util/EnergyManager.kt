package com.flvhpx.smine.util

import android.content.Context

/**
 * Energy system for the free tier.
 *
 *  - Running an app costs [Prefs.ENERGY_PER_RUN] (100) energy.
 *  - Energy is earned by watching a 15s rewarded ad: +[Prefs.ENERGY_PER_AD] (100).
 *  - Max stack is [Prefs.MAX_ENERGY] (600).
 *  - Premium / VVIP / Developer tiers have unlimited energy.
 */
class EnergyManager(context: Context) {

    private val prefs = Prefs(context)

    fun isUnlimited(): Boolean = prefs.isPremiumTier()

    fun current(): Int = prefs.energy

    fun max(): Int = Prefs.MAX_ENERGY

    /** Returns true if the run is allowed (and deducts energy for free tier). */
    fun tryConsumeForRun(): Boolean {
        if (isUnlimited()) return true
        if (prefs.energy < Prefs.ENERGY_PER_RUN) return false
        prefs.energy = prefs.energy - Prefs.ENERGY_PER_RUN
        return true
    }

    /** Grant the rewarded-ad energy (capped at max). */
    fun rewardAd(): Int {
        val before = prefs.energy
        prefs.energy = before + Prefs.ENERGY_PER_AD
        prefs.lastAdReward = System.currentTimeMillis()
        return prefs.energy - before
    }

    fun canRun(): Boolean = isUnlimited() || prefs.energy >= Prefs.ENERGY_PER_RUN
}

package com.flvhpx.smine.service

import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import com.flvhpx.smine.util.Notifications
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Handles screenshots and screen recording using MediaProjection.
 *
 * On Android 10+ (scoped storage) media is written through MediaStore so the
 * files land in Pictures/HPX SMINE and Movies/HPX SMINE without needing the
 * legacy WRITE_EXTERNAL_STORAGE permission.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "hpx.capture.START"
        const val ACTION_SCREENSHOT = "hpx.capture.SCREENSHOT"
        const val ACTION_START_RECORD = "hpx.capture.START_RECORD"
        const val ACTION_STOP_RECORD = "hpx.capture.STOP_RECORD"
        const val ACTION_STOP = "hpx.capture.STOP"

        fun screenshot(ctx: Context) = send(ctx, ACTION_SCREENSHOT)
        fun startRecord(ctx: Context) = send(ctx, ACTION_START_RECORD)
        fun stopRecord(ctx: Context) = send(ctx, ACTION_STOP_RECORD)
        fun stop(ctx: Context) = send(ctx, ACTION_STOP)

        private fun send(ctx: Context, action: String) {
            val i = Intent(ctx, ScreenCaptureService::class.java).setAction(action)
            if (action == ACTION_STOP) ctx.stopService(i)
            else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ctx.startForegroundService(i) else ctx.startService(i)
            }
        }
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recUri: Uri? = null
    private var recording = false
    private var width = 0
    private var height = 0
    private var density = 0
    private lateinit var bgHandler: Handler

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            cleanup()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
        val t = HandlerThread("hpx-capture").also { it.start() }
        bgHandler = Handler(t.looper)
        readMetrics()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureForeground()
        when (intent?.action) {
            ACTION_START -> {}
            ACTION_SCREENSHOT -> { ensureProjection(); takeScreenshot() }
            ACTION_START_RECORD -> { ensureProjection(); startRecording() }
            ACTION_STOP_RECORD -> stopRecording()
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
        }
        return START_STICKY
    }

    private fun ensureForeground() {
        val n = Notifications.build(
            this, Notifications.CH_CAPTURE,
            "HPX SMINE Capture", "Screenshot & recording ready", Notifications.ID_CAPTURE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                Notifications.ID_CAPTURE, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(Notifications.ID_CAPTURE, n)
        }
    }

    private fun readMetrics() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        width = dm.widthPixels
        height = dm.heightPixels
        density = dm.densityDpi
    }

    private fun ensureProjection(): Boolean {
        if (projection != null) return true
        val data = ScreenCaptureManager.resultData
        if (data == null) {
            toast("Enable screen capture first")
            return false
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return try {
            val p = mpm.getMediaProjection(ScreenCaptureManager.resultCode, data)
            p.registerCallback(projectionCallback, bgHandler)
            projection = p
            true
        } catch (e: Exception) {
            toast("Screen capture error: ${e.message}")
            false
        }
    }

    // ---------------- Screenshot ----------------
    private fun takeScreenshot() {
        val p = projection ?: return
        try {
            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader = reader
            virtualDisplay = p.createVirtualDisplay(
                "hpx-shot", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, bgHandler
            )
            reader.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val rowStride = plane.rowStride
                    val pixelStride = plane.pixelStride
                    val rowPadding = rowStride - pixelStride * width
                    val bmpW = width + rowPadding / pixelStride
                    val bmp = Bitmap.createBitmap(bmpW, height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(plane.buffer)
                    val cropped = Bitmap.createBitmap(bmp, 0, 0, width, height)
                    saveBitmap(cropped)
                    bmp.recycle(); cropped.recycle()
                } catch (e: Exception) {
                    toast("Screenshot failed")
                } finally {
                    image.close()
                    releaseShot()
                }
            }, bgHandler)
        } catch (e: Exception) {
            toast("Screenshot error: ${e.message}")
            releaseShot()
        }
    }

    private fun releaseShot() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
    }

    private fun saveBitmap(bmp: Bitmap) {
        val name = "HPX_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/HPX SMINE")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                    resolver.update(uri, done, null, null)
                    toast("Screenshot saved: $name")
                } else {
                    toast("Could not save screenshot")
                }
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "HPX SMINE"
                )
                if (!dir.exists()) dir.mkdirs()
                FileOutputStream(File(dir, name)).use {
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                }
                toast("Screenshot saved: $name")
            }
        } catch (e: Exception) {
            toast("Could not save screenshot")
        }
    }

    // ---------------- Recording ----------------
    private fun startRecording() {
        if (recording) { toast("Already recording"); return }
        val p = projection ?: return
        val name = "HPXREC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        try {
            val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            rec.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(width, height)
                setVideoFrameRate(60)
                setVideoEncodingBitRate(12_000_000)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, name)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/HPX SMINE")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri == null) throw IllegalStateException("MediaStore insert failed")
                    val pfd = contentResolver.openFileDescriptor(uri, "w")
                        ?: throw IllegalStateException("Cannot open output")
                    recUri = uri
                    recPfd = pfd
                    setOutputFile(pfd.fileDescriptor)
                } else {
                    val dir = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                        "HPX SMINE"
                    )
                    if (!dir.exists()) dir.mkdirs()
                    setOutputFile(File(dir, name).absolutePath)
                }
                prepare()
            }
            recorder = rec
            virtualDisplay = p.createVirtualDisplay(
                "hpx-rec", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rec.surface, null, bgHandler
            )
            rec.start()
            recording = true
            toast("Recording started")
        } catch (e: Exception) {
            toast("Record error: ${e.message}")
            stopRecording()
        }
    }

    private fun stopRecording() {
        if (!recording) return
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        // Finalise the MediaStore entry so it becomes visible in the gallery.
        try {
            recUri?.let {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(it, done, null, null)
            }
        } catch (_: Exception) {}
        try { recPfd?.close() } catch (_: Exception) {}
        recUri = null
        recPfd = null
        recording = false
        toast("Recording saved to Movies/HPX SMINE")
    }

    fun isRecording(): Boolean = recording

    private fun cleanup() {
        releaseShot()
        if (recording) stopRecording()
        try { projection?.unregisterCallback(projectionCallback) } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun toast(m: String) {
        Handler(mainLooper).post { Toast.makeText(applicationContext, m, Toast.LENGTH_SHORT).show() }
    }
}

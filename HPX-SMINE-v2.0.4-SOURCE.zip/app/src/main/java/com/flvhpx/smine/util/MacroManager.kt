package com.flvhpx.smine.util

import org.json.JSONArray
import org.json.JSONObject

/**
 * HPX SMINE Macro engine (v2.0.4).
 *
 * A macro is an ordered list of gestures (tap / long-press / swipe) recorded on
 * top of the game and replayed later through an AccessibilityService using
 * [android.accessibilityservice.AccessibilityService.dispatchGesture].
 *
 * Coordinates are stored NORMALISED (0f..1f relative to the screen) so a macro
 * recorded in portrait still maps correctly in landscape and across devices.
 */
object MacroManager {

    /** A single recorded gesture. */
    data class Step(
        val x1: Float,          // start X (0..1)
        val y1: Float,          // start Y (0..1)
        val x2: Float,          // end X (0..1)   (== x1 for a tap)
        val y2: Float,          // end Y (0..1)   (== y1 for a tap)
        val delayMs: Long,      // idle time before this gesture starts
        val durationMs: Long    // how long the finger stays down
    ) {
        val isSwipe: Boolean get() = kotlin.math.abs(x2 - x1) > 0.01f || kotlin.math.abs(y2 - y1) > 0.01f
    }

    fun serialize(steps: List<Step>): String {
        val arr = JSONArray()
        for (s in steps) {
            val o = JSONObject()
            o.put("x1", s.x1.toDouble())
            o.put("y1", s.y1.toDouble())
            o.put("x2", s.x2.toDouble())
            o.put("y2", s.y2.toDouble())
            o.put("d", s.delayMs)
            o.put("t", s.durationMs)
            arr.put(o)
        }
        return arr.toString()
    }

    fun parse(json: String): List<Step> {
        if (json.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            val out = ArrayList<Step>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Step(
                        o.optDouble("x1", 0.5).toFloat(),
                        o.optDouble("y1", 0.5).toFloat(),
                        o.optDouble("x2", o.optDouble("x1", 0.5)).toFloat(),
                        o.optDouble("y2", o.optDouble("y1", 0.5)).toFloat(),
                        o.optLong("d", 100L),
                        o.optLong("t", 60L)
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Human readable summary, e.g. "5 steps · 2 swipes". */
    fun summary(steps: List<Step>): String {
        if (steps.isEmpty()) return "no macro"
        val swipes = steps.count { it.isSwipe }
        return "${steps.size} step(s) · $swipes swipe(s)"
    }
}

package com.flvhpx.smine.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Allows other components (e.g. widgets / shortcuts) to start & stop the overlay.
 */
class OverlayActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_START -> ContextCompat.startForegroundService(
                context, Intent(context, OverlayService::class.java)
            )
            ACTION_STOP -> context.stopService(Intent(context, OverlayService::class.java))
        }
    }

    companion object {
        const val ACTION_START = "com.flvhpx.smine.START_OVERLAY"
        const val ACTION_STOP = "com.flvhpx.smine.STOP_OVERLAY"
    }
}

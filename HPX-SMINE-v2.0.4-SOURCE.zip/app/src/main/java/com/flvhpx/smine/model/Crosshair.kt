package com.flvhpx.smine.model

import android.graphics.Color

/**
 * Crosshair styles and presets.
 */
object Crosshair {

    val STYLE_NAMES = listOf(
        "Cross", "Dot", "Circle", "Cross + Dot", "Cross + Circle",
        "T-Shape", "X-Burst", "Brackets", "Chevron", "Dot + Ring"
    )

    val COLORS = listOf(
        "Neon Green" to Color.parseColor("#00FF88"),
        "Cyber Cyan" to Color.parseColor("#00E5FF"),
        "Hot Pink" to Color.parseColor("#FF2D9B"),
        "Magenta" to Color.parseColor("#E100FF"),
        "Blood Red" to Color.parseColor("#FF3D57"),
        "Golden" to Color.parseColor("#FFC400"),
        "Pure White" to Color.parseColor("#FFFFFF"),
        "Toxic Lime" to Color.parseColor("#B6FF00"),
        "Deep Blue" to Color.parseColor("#2E7BFF"),
        "Orange" to Color.parseColor("#FF7A00")
    )

    const val STYLE_CROSS = 0
    const val STYLE_DOT = 1
    const val STYLE_CIRCLE = 2
    const val STYLE_CROSS_DOT = 3
    const val STYLE_CROSS_CIRCLE = 4
    const val STYLE_T = 5
    const val STYLE_X = 6
    const val STYLE_BRACKETS = 7
    const val STYLE_CHEVRON = 8
    const val STYLE_DOT_RING = 9
}

package com.flvhpx.smine.service

import android.app.Activity
import android.content.Intent

/**
 * Holds the MediaProjection permission result so the capture service and the
 * overlay can share it.
 */
object ScreenCaptureManager {
    var resultCode: Int = Activity.RESULT_CANCELED
    var resultData: Intent? = null

    fun isReady(): Boolean = resultData != null

    fun save(code: Int, data: Intent?) {
        resultCode = code
        resultData = data
    }

    fun clear() {
        resultCode = Activity.RESULT_CANCELED
        resultData = null
    }
}

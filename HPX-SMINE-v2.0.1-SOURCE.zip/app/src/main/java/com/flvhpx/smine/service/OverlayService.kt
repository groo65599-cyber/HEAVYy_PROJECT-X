package com.flvhpx.smine.service

import android.animation.ValueAnimator
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.flvhpx.smine.R
import com.flvhpx.smine.util.EnergyManager
import com.flvhpx.smine.util.Notifications
import com.flvhpx.smine.util.Permissions
import com.flvhpx.smine.util.Prefs
import com.flvhpx.smine.util.SystemMonitor
import com.flvhpx.smine.view.CrosshairView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The heart of HPX SMINE: a foreground service that renders the crosshair,
 * the real-time ROG-style lifetime monitor, the right-edge swipe handle and the
 * Game-Genie style bottom-sheet quick panel on top of any running game.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_RELOAD = "hpx.overlay.RELOAD"
        const val ACTION_TOGGLE_PANEL = "hpx.overlay.TOGGLE_PANEL"
        const val ACTION_SHOW_LOGIN = "hpx.overlay.SHOW_LOGIN"

        fun start(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun reload(ctx: Context) {
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_RELOAD))
        }

        fun togglePanel(ctx: Context) {
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_TOGGLE_PANEL))
        }

        fun showLogin(ctx: Context) {
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_SHOW_LOGIN))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var monitor: SystemMonitor? = null

    private var crosshair: CrosshairView? = null
    private var monitorView: View? = null
    private var handle: View? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var sheet: View? = null
    private var sheetRoot: View? = null
    private var loginView: View? = null
    private var dock: View? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val density get() = resources.displayMetrics.density

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        prefs = Prefs(this)
        Notifications.ensureChannels(this)
        ensureForeground()
        acquireWakeLock()
        buildAll()
        if (prefs.loginAnimEnabled) handler.postDelayed({ showLoginAnim() }, 350)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RELOAD -> rebuild()
            ACTION_TOGGLE_PANEL -> toggleSheet()
            ACTION_SHOW_LOGIN -> showLoginAnim()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Keep-alive: relaunch the overlay if the user swipes the app away.
        try {
            val restart = Intent(applicationContext, OverlayService::class.java)
            val pi = PendingIntent.getService(
                this, 4711, restart,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, pi)
        } catch (_: Exception) {}
    }

    private fun ensureForeground() {
        val n = Notifications.build(
            this, Notifications.CH_OVERLAY,
            "HPX SMINE is running", "Overlay active \u00b7 swipe from right edge",
            Notifications.ID_OVERLAY
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                Notifications.ID_OVERLAY, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(Notifications.ID_OVERLAY, n)
        }
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HPX:overlay")
            wakeLock?.setReferenceCounted(false)
            wakeLock?.acquire(6 * 60 * 60 * 1000L) // max 6h, auto-released
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------
    //  Build / rebuild
    // ------------------------------------------------------------------
    private fun buildAll() {
        if (prefs.crosshairEnabled) addCrosshair()
        if (prefs.monitorEnabled) addMonitor()
        if (prefs.edgePanelEnabled) addEdgeHandle()
        addDock()
    }

    private fun rebuild() {
        removeCrosshair(); removeMonitor(); removeEdgeHandle(); removeDock()
        closeSheet(immediate = true)
        buildAll()
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ------------------------------------------------------------------
    //  Crosshair
    // ------------------------------------------------------------------
    private fun addCrosshair() {
        if (crosshair != null) return
        val v = CrosshairView(this)
        v.applyConfig(
            prefs.crosshairStyle, prefs.crosshairColor,
            prefs.crosshairSize * density, prefs.crosshairGap * density,
            prefs.crosshairThickness * density, prefs.crosshairDot, prefs.crosshairGlow,
            prefs.crosshairAlpha,
            prefs.crosshairOffsetX * density, prefs.crosshairOffsetY * density
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(v, lp); crosshair = v } catch (_: Exception) {}
    }

    private fun removeCrosshair() {
        crosshair?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        crosshair = null
    }

    // ------------------------------------------------------------------
    //  ROG-style lifetime monitor
    // ------------------------------------------------------------------
    private fun addMonitor() {
        if (monitorView != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_monitor, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        applyMonitorGravity(lp)
        try { wm.addView(v, lp); monitorView = v } catch (_: Exception) {}
        applyMonitorVisibility(v)
        attachMonitorTouch(v, lp)

        val m = SystemMonitor(this) { s ->
            v.findViewById<TextView>(R.id.txtFps)?.text = "${s.fps}"
            v.findViewById<TextView>(R.id.txtCpu)?.text = "${s.cpu.roundToInt()}%"
            v.findViewById<TextView>(R.id.txtGpu)?.text =
                if (s.gpu < 0f) "N/A" else "${s.gpu.roundToInt()}%"
            v.findViewById<TextView>(R.id.txtRam)?.text =
                String.format("%.1fG", s.ramUsedMb / 1024f)
            v.findViewById<TextView>(R.id.txtBattery)?.text =
                if (s.batteryPercent < 0) "--" else "${s.batteryPercent}%"
            v.findViewById<TextView>(R.id.txtTime)?.text = s.time
        }
        monitor = m
        m.start()
    }

    private fun applyMonitorVisibility(v: View) {
        val expanded = prefs.monitorExpanded
        fun vis(id: Int, on: Boolean) {
            v.findViewById<View>(id)?.visibility = if (on) View.VISIBLE else View.GONE
        }
        vis(R.id.rowFps, prefs.monitorShowFps)
        vis(R.id.rowCpu, expanded && prefs.monitorShowCpu)
        vis(R.id.rowGpu, expanded && prefs.monitorShowGpu)
        vis(R.id.rowRam, expanded && prefs.monitorShowRam)
        vis(R.id.rowBattery, expanded && prefs.monitorShowBattery)
        vis(R.id.rowTime, prefs.monitorShowTime)
    }

    private fun applyMonitorGravity(lp: WindowManager.LayoutParams) {
        val m = (density * 10).toInt()
        if (prefs.monitorX >= 0 && prefs.monitorY >= 0) {
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = prefs.monitorX
            lp.y = prefs.monitorY
            return
        }
        when (prefs.monitorPosition) {
            0 -> { lp.gravity = Gravity.TOP or Gravity.START; lp.x = m; lp.y = m }
            1 -> { lp.gravity = Gravity.TOP or Gravity.END; lp.x = m; lp.y = m }
            2 -> { lp.gravity = Gravity.BOTTOM or Gravity.START; lp.x = m; lp.y = m }
            else -> { lp.gravity = Gravity.BOTTOM or Gravity.END; lp.x = m; lp.y = m }
        }
    }

    private fun attachMonitorTouch(v: View, lp: WindowManager.LayoutParams) {
        val plus = v.findViewById<View>(R.id.btnMonitorPlus) ?: return
        var lastX = 0f; var lastY = 0f
        var downX = 0f; var downY = 0f
        var moved = false
        val slop = (density * 6).toInt()

        plus.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX; lastY = e.rawY
                    downX = e.rawX; downY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > slop || abs(e.rawY - downY) > slop) moved = true
                    lp.x += (e.rawX - lastX).toInt()
                    lp.y += (e.rawY - lastY).toInt()
                    lastX = e.rawX; lastY = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.monitorX = lp.x
                        prefs.monitorY = lp.y
                    } else {
                        prefs.monitorExpanded = !prefs.monitorExpanded
                        applyMonitorVisibility(v)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun removeMonitor() {
        monitor?.stop(); monitor = null
        monitorView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        monitorView = null
    }

    // ------------------------------------------------------------------
    //  Right-edge handle
    // ------------------------------------------------------------------
    private fun addEdgeHandle() {
        if (handle != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_edge_handle, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        lp.x = 0
        lp.y = prefs.edgeY
        try { wm.addView(v, lp); handle = v; handleParams = lp } catch (_: Exception) {}
        attachHandleTouch(v, lp)
    }

    private fun removeEdgeHandle() {
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null; handleParams = null
    }

    private fun attachHandleTouch(v: View, lp: WindowManager.LayoutParams) {
        var downX = 0f; var downY = 0f
        var startY = 0; var moved = false
        val slop = (density * 6).toInt()
        val openThreshold = (density * 40).toInt()

        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startY = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (abs(dy) > abs(dx)) {
                        lp.y = startY + dy.toInt()
                        safeUpdate(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - downX
                    if (dx < -openThreshold) {
                        openSheet()
                    } else if (!moved) {
                        toggleSheet()
                    } else {
                        prefs.edgeY = lp.y
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------------
    //  Bottom-sheet quick panel (Game Genie style)
    // ------------------------------------------------------------------
    private fun toggleSheet() { if (sheet == null) openSheet() else closeSheet() }

    private fun openSheet() {
        if (sheet != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_bottom_sheet, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(v, lp); sheet = v } catch (_: Exception) { return }

        val root = v.findViewById<View>(R.id.sheetRoot)
        sheetRoot = root
        bindSheet(v)
        attachSheetGestures(v, root)

        root.post {
            root.translationY = root.height.toFloat()
            root.animate().translationY(0f).setDuration(260)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closeSheet(immediate: Boolean = false) {
        val v = sheet ?: return
        val root = sheetRoot
        if (immediate || root == null) {
            try { wm.removeView(v) } catch (_: Exception) {}
            sheet = null; sheetRoot = null
            return
        }
        root.animate().translationY(root.height.toFloat()).setDuration(220)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                try { wm.removeView(v) } catch (_: Exception) {}
                if (sheet === v) { sheet = null; sheetRoot = null }
            }.start()
    }

    private fun attachSheetGestures(v: View, root: View) {
        v.findViewById<View>(R.id.sheetDim)?.setOnClickListener { closeSheet() }
        var downY = 0f; var dragging = false
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downY = e.rawY; dragging = false; false }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - downY
                    if (dy > 0) {
                        dragging = true
                        root.translationY = dy
                    }
                    dragging
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging && root.translationY > root.height / 4f) {
                        closeSheet()
                    } else if (dragging) {
                        root.animate().translationY(0f).setDuration(160).start()
                    }
                    dragging
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------------
    //  Sheet content
    // ------------------------------------------------------------------
    private fun bindSheet(v: View) {
        v.findViewById<View>(R.id.btnCloseSheet)?.setOnClickListener { closeSheet() }

        // Energy badge
        val em = EnergyManager(this)
        v.findViewById<TextView>(R.id.txtEnergy)?.text =
            if (em.isUnlimited()) "ENERGY \u221E" else "ENERGY ${em.current()}"

        // App quota label
        v.findViewById<TextView>(R.id.txtAppQuota)?.text =
            if (prefs.isPremiumTier()) "PREMIUM \u221E" else "FREE 3"

        setupBrightness(v)
        setupVolume(v)
        setupQuickActions(v)
        setupAppShortcuts(v)
    }

    // ----- Brightness -----
    private fun setupBrightness(v: View) {
        val seek = v.findViewById<SeekBar>(R.id.seekBrightness) ?: return
        val txt = v.findViewById<TextView>(R.id.txtBrightness)
        // Force manual mode so writes are honoured (fixes "only decreases" bug).
        try {
            Settings.System.putInt(
                contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
        } catch (_: Exception) {}

        val cur = Permissions.getSystemBrightness(this).coerceIn(0, 255)
        seek.progress = cur
        txt?.text = "${cur * 100 / 255}%"

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                txt?.text = "${p * 100 / 255}%"
                if (fromUser) Permissions.setSystemBrightness(this@OverlayService, p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        v.findViewById<View>(R.id.btnBrightMinus)?.setOnClickListener {
            stepBrightness(seek, txt, -25)
        }
        v.findViewById<View>(R.id.btnBrightPlus)?.setOnClickListener {
            stepBrightness(seek, txt, 25)
        }
    }

    private fun stepBrightness(seek: SeekBar, txt: TextView?, delta: Int) {
        val np = (seek.progress + delta).coerceIn(0, 255)
        seek.progress = np
        txt?.text = "${np * 100 / 255}%"
        Permissions.setSystemBrightness(this, np)
    }

    // ----- Volume -----
    private fun setupVolume(v: View) {
        val seek = v.findViewById<SeekBar>(R.id.seekVolume) ?: return
        val txt = v.findViewById<TextView>(R.id.txtVolume)
        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

        fun write(progress: Int) {
            val vol = (progress * maxV / 100f).roundToInt().coerceIn(0, maxV)
            try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0) } catch (_: Exception) {}
            txt?.text = "$progress%"
        }

        val curP = (audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / maxV).coerceIn(0, 100)
        seek.progress = curP
        txt?.text = "$curP%"

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) write(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        v.findViewById<View>(R.id.btnVolMinus)?.setOnClickListener {
            val np = (seek.progress - 10).coerceIn(0, 100)
            seek.progress = np; write(np)
        }
        v.findViewById<View>(R.id.btnVolPlus)?.setOnClickListener {
            val np = (seek.progress + 10).coerceIn(0, 100)
            seek.progress = np; write(np)
        }
    }

    // ----- Quick actions -----
    private fun setupQuickActions(v: View) {
        val grid = v.findViewById<GridLayout>(R.id.quickGrid) ?: return
        grid.removeAllViews()
        val gap = (density * 8).toInt()

        addQuickAction(grid, R.drawable.ic_screenshot, "Shot", 0, gap) {
            if (!ScreenCaptureManager.isReady()) toast("Enable screen capture in app first")
            else ScreenCaptureService.screenshot(this)
        }
        addQuickAction(grid, R.drawable.ic_record, "Record", 1, gap) {
            if (!ScreenCaptureManager.isReady()) toast("Enable screen capture in app first")
            else ScreenCaptureService.startRecord(this)
        }
        addQuickAction(grid, R.drawable.ic_stop, "Stop", 2, gap) {
            ScreenCaptureService.stopRecord(this)
        }
        addQuickAction(grid, R.drawable.ic_crosshair, "Cross", 3, gap) {
            prefs.crosshairEnabled = !prefs.crosshairEnabled
            if (prefs.crosshairEnabled) addCrosshair() else removeCrosshair()
            toast(if (prefs.crosshairEnabled) "Crosshair ON" else "Crosshair OFF")
        }
        addQuickAction(grid, R.drawable.ic_monitor, "Monitor", 4, gap) {
            prefs.monitorEnabled = !prefs.monitorEnabled
            if (prefs.monitorEnabled) addMonitor() else removeMonitor()
            toast(if (prefs.monitorEnabled) "Monitor ON" else "Monitor OFF")
        }
        addQuickAction(grid, R.drawable.ic_float, "Dock", 5, gap) {
            if (!prefs.isPremiumTier()) toast("Floating dock is a Premium feature")
            else {
                prefs.floatingWindowEnabled = !prefs.floatingWindowEnabled
                if (prefs.floatingWindowEnabled) addDock() else removeDock()
                toast(if (prefs.floatingWindowEnabled) "Dock ON" else "Dock OFF")
            }
        }
        addQuickAction(grid, R.drawable.ic_network, "Net", 6, gap) {
            if (!prefs.isPremiumTier()) toast("Network optimizer is Premium")
            else {
                prefs.netOptimizerEnabled = !prefs.netOptimizerEnabled
                toast(if (prefs.netOptimizerEnabled) "Net optimizer ON" else "Net optimizer OFF")
            }
        }
        addQuickAction(grid, R.drawable.ic_close, "Close", 7, gap) { closeSheet() }
    }

    private fun addQuickAction(
        grid: GridLayout, icon: Int, label: String, index: Int, gap: Int, action: () -> Unit
    ) {
        val item = LayoutInflater.from(this).inflate(R.layout.item_quick_action, grid, false)
        item.findViewById<ImageView>(R.id.qaIcon).setImageResource(icon)
        item.findViewById<TextView>(R.id.qaLabel).text = label
        item.setOnClickListener { action() }
        val lp = GridLayout.LayoutParams()
        lp.width = 0
        lp.height = GridLayout.LayoutParams.WRAP_CONTENT
        lp.columnSpec = GridLayout.spec(index % 4, 1f)
        lp.rowSpec = GridLayout.spec(index / 4)
        lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
        item.layoutParams = lp
        grid.addView(item)
    }

    // ----- App shortcuts -----
    private fun setupAppShortcuts(v: View) {
        val row = v.findViewById<LinearLayout>(R.id.appShortcuts) ?: return
        row.removeAllViews()
        val apps = prefs.launcherList()
        if (apps.isEmpty()) {
            val t = TextView(this).apply {
                text = if (prefs.isPremiumTier()) "Add apps in the launcher (unlimited)"
                else "Add apps in the launcher (free: 3)"
                setTextColor(0xFF5A6178.toInt())
                textSize = 11f
            }
            row.addView(t)
        } else {
            for (pkg in apps) row.addView(buildAppShortcut(pkg))
        }
    }

    private fun buildAppShortcut(pkg: String): View {
        val size = (density * 52).toInt()
        val iv = ImageView(this)
        val lp = LinearLayout.LayoutParams(size, size)
        lp.marginEnd = (density * 10).toInt()
        iv.layoutParams = lp
        iv.background = getDrawable(R.drawable.bg_glass_inner)
        val p = (density * 10).toInt()
        iv.setPadding(p, p, p, p)
        try { iv.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {
            iv.setImageResource(R.drawable.ic_apps)
        }
        iv.setOnClickListener { launchApp(pkg) }
        return iv
    }

    private fun launchApp(pkg: String) {
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                closeSheet()
            } else toast("App not installed")
        } catch (_: Exception) { toast("Cannot open app") }
    }

    // ------------------------------------------------------------------
    //  Floating app dock (premium)
    // ------------------------------------------------------------------
    private fun addDock() {
        if (dock != null) return
        if (!prefs.floatingWindowEnabled || !prefs.isPremiumTier()) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_float_dock, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val defX = (density * 14).toInt()
        val defY = (resources.displayMetrics.heightPixels * 0.62f).toInt()
        lp.x = if (prefs.floatDockX >= 0) prefs.floatDockX else defX
        lp.y = if (prefs.floatDockY >= 0) prefs.floatDockY else defY
        try { wm.addView(v, lp); dock = v } catch (_: Exception) { return }

        val row = v.findViewById<LinearLayout>(R.id.dockApps)
        row.removeAllViews()
        val apps = prefs.launcherList()
        if (apps.isEmpty()) {
            val t = TextView(this).apply {
                text = "Add apps in launcher"
                setTextColor(0xFF5A6178.toInt()); textSize = 10f
                setPadding((density * 6).toInt(), 0, (density * 6).toInt(), 0)
            }
            row.addView(t)
        } else {
            for (pkg in apps) {
                val size = (density * 40).toInt()
                val iv = ImageView(this)
                val ilp = LinearLayout.LayoutParams(size, size)
                ilp.marginEnd = (density * 6).toInt()
                iv.layoutParams = ilp
                iv.background = getDrawable(R.drawable.bg_glass_inner)
                val p = (density * 7).toInt()
                iv.setPadding(p, p, p, p)
                try { iv.setImageDrawable(packageManager.getApplicationIcon(pkg)) }
                catch (_: Exception) { iv.setImageResource(R.drawable.ic_apps) }
                iv.setOnClickListener { launchApp(pkg) }
                row.addView(iv)
            }
        }

        v.findViewById<View>(R.id.dockMinimize)?.setOnClickListener {
            prefs.floatingWindowEnabled = false
            removeDock()
        }

        // Drag via grab handle
        val grab = v.findViewById<View>(R.id.dockGrab) ?: return
        var lx = 0f; var ly = 0f
        grab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x += (e.rawX - lx).toInt()
                    lp.y += (e.rawY - ly).toInt()
                    lx = e.rawX; ly = e.rawY
                    safeUpdate(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.floatDockX = lp.x; prefs.floatDockY = lp.y; true
                }
                else -> false
            }
        }
    }

    private fun removeDock() {
        dock?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        dock = null
    }

    // ------------------------------------------------------------------
    //  Login animation (ROG style)
    // ------------------------------------------------------------------
    private fun showLoginAnim() {
        if (!prefs.loginAnimEnabled || loginView != null) return
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_login, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(v, lp); loginView = v } catch (_: Exception) { return }

        val progress = v.findViewById<ProgressBar>(R.id.loginProgress)
        val status = v.findViewById<TextView>(R.id.loginStatus)
        val logo = v.findViewById<ImageView>(R.id.loginLogo)
        logo?.animate()?.rotation(360f)?.setDuration(1400)?.start()

        val stages = listOf(
            "INITIALIZING GAME SPACE...",
            "LOADING OPTIMIZER...",
            "CALIBRATING OVERLAY...",
            "READY"
        )
        val anim = ValueAnimator.ofInt(0, 100).setDuration(1500)
        anim.addUpdateListener {
            val p = it.animatedValue as Int
            progress?.progress = p
            status?.text = stages[(p / 26).coerceIn(0, stages.size - 1)]
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                handler.postDelayed({ removeLoginAnim() }, 300)
            }
        })
        anim.start()
    }

    private fun removeLoginAnim() {
        loginView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        loginView = null
    }

    // ------------------------------------------------------------------
    //  Helpers
    // ------------------------------------------------------------------
    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        removeCrosshair(); removeMonitor(); removeEdgeHandle(); removeDock()
        closeSheet(immediate = true)
        removeLoginAnim()
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

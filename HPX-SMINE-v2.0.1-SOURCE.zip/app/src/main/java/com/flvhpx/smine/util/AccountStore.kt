package com.flvhpx.smine.util

import android.content.Context
import java.util.UUID

/**
 * Local account store for HPX SMINE. On first launch an account is auto-created
 * with a random username & password that the user can view and copy.
 *
 * The same data is exposed to the companion app (HPX PREMM ACCESS) through
 * [com.flvhpx.smine.provider.AccountProvider] so a free account can be upgraded.
 */
class AccountStore(private val context: Context) {

    private val prefs = Prefs(context)

    /** Ensure an account exists; returns true if a new one was created. */
    fun ensureAccount(): Boolean {
        if (prefs.accountUsername.isNotBlank()) return false
        val u = "HPX-" + random(6)
        val p = random(8)
        prefs.accountUsername = u
        prefs.accountPassword = p
        prefs.accountTier = "FREE"
        prefs.accountExpiry = 0L
        prefs.accountCreatedAt = System.currentTimeMillis()
        prefs.energy = 300
        return true
    }

    fun username(): String = prefs.accountUsername
    fun password(): String = prefs.accountPassword
    fun tier(): String = prefs.accountTier
    fun expiry(): Long = prefs.accountExpiry
    fun createdAt(): Long = prefs.accountCreatedAt

    /** Apply an upgrade coming from the admin app. */
    fun upgrade(tier: String, durationDays: Int) {
        prefs.accountTier = tier
        prefs.accountExpiry = if (durationDays <= 0) 0L
        else System.currentTimeMillis() + durationDays.toLong() * 86_400_000L
    }

    fun isPremium(): Boolean = prefs.isPremiumTier()
    fun isDeveloper(): Boolean = prefs.isDeveloper()

    fun tierLabel(): String {
        val t = prefs.accountTier
        if (t == "FREE") return "FREE"
        val exp = prefs.accountExpiry
        if (exp != 0L && exp <= System.currentTimeMillis()) return "FREE (expired)"
        return t
    }

    companion object {
        private const val CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        fun random(len: Int): String {
            val sb = StringBuilder()
            val rnd = java.util.Random(System.nanoTime() xor UUID.randomUUID().mostSignificantBits)
            for (i in 0 until len) sb.append(CHARS[rnd.nextInt(CHARS.length)])
            return sb.toString()
        }
    }
}

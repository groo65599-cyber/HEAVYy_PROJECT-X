# HPX SMINE proguard rules
-keep class com.flvhpx.smine.** { *; }
-dontwarn kotlin.**

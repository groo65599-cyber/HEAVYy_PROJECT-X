package com.flvhpx.access

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * HPX PREMM ACCESS — the companion admin app (v2.0.1).
 *
 * Flow:
 *   1. User enters the HPX SMINE username & password (or taps "auto link").
 *   2. Credentials are verified against the account exposed by the main app
 *      through its ContentProvider (authority: com.flvhpx.smine.accounts).
 *   3. Once logged in the user can:
 *        - upgrade the account to PREMIUM for 1 / 2 / 7 days or forever
 *        - unlock DEVELOPER access with the LIVDEV code "DEVV ACCESS"
 *        - create a VVIP account (developer only)
 */
class MainActivity : AppCompatActivity() {

    private companion object {
        const val AUTHORITY = "com.flvhpx.smine.accounts"
        val CURRENT_URI: Uri = Uri.parse("content://$AUTHORITY/accounts/current")
        val UPGRADE_URI: Uri = Uri.parse("content://$AUTHORITY/accounts/upgrade")
        const val PACKAGE_SMINE = "com.flvhpx.smine"
        const val LIVDEV_CODE = "DEVV ACCESS"
    }

    // Views
    private lateinit var cardLogin: View
    private lateinit var panelMain: View
    private lateinit var editLoginUser: EditText
    private lateinit var editLoginPass: EditText
    private lateinit var txtStatus: TextView
    private lateinit var txtUsername: TextView
    private lateinit var txtPassword: TextView
    private lateinit var txtTierBadge: TextView
    private lateinit var txtExpiry: TextView
    private lateinit var txtVvipSub: TextView
    private lateinit var txtNotInstalled: View
    private lateinit var btnCreateVvip: Button
    private lateinit var editCode: EditText

    // State
    private var passwordVisible = false
    private var loggedIn = false
    private var currentTier = "FREE"
    private var currentUsername = ""
    private var currentPassword = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_access_main)

        cardLogin = findViewById(R.id.cardLogin)
        panelMain = findViewById(R.id.panelMain)
        editLoginUser = findViewById(R.id.editLoginUser)
        editLoginPass = findViewById(R.id.editLoginPass)
        txtStatus = findViewById(R.id.txtStatus)
        txtUsername = findViewById(R.id.txtUsername)
        txtPassword = findViewById(R.id.txtPassword)
        txtTierBadge = findViewById(R.id.txtTierBadge)
        txtExpiry = findViewById(R.id.txtExpiry)
        txtVvipSub = findViewById(R.id.txtVvipSub)
        txtNotInstalled = findViewById(R.id.txtNotInstalled)
        btnCreateVvip = findViewById(R.id.btnCreateVvip)
        editCode = findViewById(R.id.editCode)

        findViewById<Button>(R.id.btnLogin).setOnClickListener { attemptLogin() }
        findViewById<Button>(R.id.btnAutoLink).setOnClickListener { autoLink() }
        findViewById<Button>(R.id.btnLogout).setOnClickListener { logout() }

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { refreshLinkedAccount() }
        findViewById<Button>(R.id.btnCopyUser).setOnClickListener { copy(currentUsername) }
        findViewById<Button>(R.id.btnCopyPass).setOnClickListener { copy(currentPassword) }
        findViewById<Button>(R.id.btnTogglePass).setOnClickListener { togglePassword() }

        findViewById<Button>(R.id.btnDay1).setOnClickListener { upgrade(1) }
        findViewById<Button>(R.id.btnDay2).setOnClickListener { upgrade(2) }
        findViewById<Button>(R.id.btnDay7).setOnClickListener { upgrade(7) }
        findViewById<Button>(R.id.btnForever).setOnClickListener { upgrade(0) }

        findViewById<Button>(R.id.btnActivate).setOnClickListener { activateDeveloper() }
        btnCreateVvip.setOnClickListener { createVvip() }
        findViewById<Button>(R.id.btnOpenSmine).setOnClickListener { openSmine() }

        prepare()
    }

    override fun onResume() {
        super.onResume()
        if (loggedIn) refreshLinkedAccount()
    }

    // ---------------- Startup ----------------

    private fun prepare() {
        if (!isSmineInstalled()) {
            txtNotInstalled.visibility = View.VISIBLE
            txtStatus.text = getString(R.string.login_need_smine)
        } else {
            txtNotInstalled.visibility = View.GONE
            txtStatus.text = getString(R.string.login_sub)
        }
        showLogin()
    }

    private fun showLogin() {
        loggedIn = false
        cardLogin.visibility = View.VISIBLE
        panelMain.visibility = View.GONE
    }

    private fun showPanel() {
        loggedIn = true
        cardLogin.visibility = View.GONE
        panelMain.visibility = View.VISIBLE
    }

    // ---------------- Provider access ----------------

    private fun isSmineInstalled(): Boolean = try {
        packageManager.getPackageInfo(PACKAGE_SMINE, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** Data holder for the account read from the provider. */
    private data class Account(
        val username: String,
        val password: String,
        val tier: String,
        val expiry: Long
    )

    private fun readAccount(): Account? {
        if (!isSmineInstalled()) return null
        return try {
            contentResolver.query(
                CURRENT_URI,
                arrayOf("username", "password", "tier", "expiry", "premium"),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    Account(
                        c.getString(c.getColumnIndexOrThrow("username")) ?: "",
                        c.getString(c.getColumnIndexOrThrow("password")) ?: "",
                        c.getString(c.getColumnIndexOrThrow("tier")) ?: "FREE",
                        c.getLong(c.getColumnIndexOrThrow("expiry"))
                    )
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Login ----------------

    private fun attemptLogin() {
        val user = editLoginUser.text.toString().trim()
        val pass = editLoginPass.text.toString().trim()

        if (user.isEmpty() || pass.isEmpty()) {
            txtStatus.text = getString(R.string.login_empty)
            toast(getString(R.string.login_empty))
            return
        }
        if (!isSmineInstalled()) {
            txtNotInstalled.visibility = View.VISIBLE
            txtStatus.text = getString(R.string.login_need_smine)
            toast(getString(R.string.login_need_smine))
            return
        }

        val acc = readAccount()
        if (acc == null) {
            txtStatus.text = getString(R.string.login_read_error)
            toast(getString(R.string.login_read_error))
            return
        }

        val userOk = user.equals(acc.username, ignoreCase = true)
        val passOk = pass == acc.password
        if (userOk && passOk) {
            currentUsername = acc.username
            currentPassword = acc.password
            currentTier = acc.tier
            txtStatus.text = getString(R.string.login_ok)
            showPanel()
            bindAccount(acc)
        } else {
            txtStatus.text = getString(R.string.login_fail)
            toast(getString(R.string.login_fail))
        }
    }

    private fun autoLink() {
        if (!isSmineInstalled()) {
            txtNotInstalled.visibility = View.VISIBLE
            txtStatus.text = getString(R.string.login_need_smine)
            toast(getString(R.string.login_need_smine))
            return
        }
        val acc = readAccount()
        if (acc == null) {
            txtStatus.text = getString(R.string.login_read_error)
            toast(getString(R.string.login_read_error))
            return
        }
        editLoginUser.setText(acc.username)
        editLoginPass.setText(acc.password)
        currentUsername = acc.username
        currentPassword = acc.password
        currentTier = acc.tier
        txtStatus.text = getString(R.string.login_ok)
        showPanel()
        bindAccount(acc)
    }

    private fun logout() {
        editLoginUser.setText("")
        editLoginPass.setText("")
        currentUsername = ""
        currentPassword = ""
        currentTier = "FREE"
        passwordVisible = false
        txtStatus.text = getString(R.string.login_sub)
        showLogin()
    }

    /** Refresh the linked account's details (called after an upgrade). */
    private fun refreshLinkedAccount() {
        val acc = readAccount() ?: return
        currentUsername = acc.username
        currentPassword = acc.password
        currentTier = acc.tier
        bindAccount(acc)
    }

    private fun bindAccount(acc: Account) {
        txtUsername.text = acc.username
        txtPassword.text = if (passwordVisible) acc.password else "********"
        applyTierBadge(acc.tier, acc.expiry)
        txtExpiry.text = formatExpiry(acc.expiry)
        updateVvipState()
    }

    // ---------------- Actions ----------------

    private fun upgrade(days: Int) {
        if (!loggedIn) { toast(getString(R.string.login_fail)); return }
        if (!isSmineInstalled()) { toast(getString(R.string.not_installed)); return }
        val values = ContentValues().apply {
            put("tier", "PREMIUM")
            put("days", days)
            put("username", currentUsername)
            put("password", currentPassword)
        }
        val ok = try {
            contentResolver.update(UPGRADE_URI, values, null, null) > 0
        } catch (e: Exception) { false }

        if (ok) {
            toast(getString(R.string.upgraded))
            refreshLinkedAccount()
        } else {
            toast("Upgrade failed")
        }
    }

    private fun activateDeveloper() {
        val entered = editCode.text.toString().trim()
        val normalized = entered.uppercase().replace(Regex("\\s+"), " ")
        if (normalized != LIVDEV_CODE) {
            toast(getString(R.string.dev_bad))
            return
        }
        if (!loggedIn) { toast(getString(R.string.login_fail)); return }
        if (!isSmineInstalled()) { toast(getString(R.string.not_installed)); return }

        val values = ContentValues().apply {
            put("tier", "DEVELOPER")
            put("days", 0)
            put("username", currentUsername)
            put("password", currentPassword)
        }
        val ok = try {
            contentResolver.update(UPGRADE_URI, values, null, null) > 0
        } catch (e: Exception) { false }

        if (ok) {
            editCode.setText("")
            toast(getString(R.string.dev_ok))
            refreshLinkedAccount()
        } else {
            toast("Activation failed")
        }
    }

    private fun createVvip() {
        if (currentTier != "DEVELOPER") {
            toast(getString(R.string.need_dev))
            return
        }
        if (!isSmineInstalled()) { toast(getString(R.string.not_installed)); return }

        val values = ContentValues().apply {
            put("tier", "VVIP")
            put("days", 0)
            put("username", currentUsername)
            put("password", currentPassword)
        }
        val ok = try {
            contentResolver.update(UPGRADE_URI, values, null, null) > 0
        } catch (e: Exception) { false }

        if (ok) {
            toast(getString(R.string.vvip_ok))
            refreshLinkedAccount()
        } else {
            toast("VVIP creation failed")
        }
    }

    private fun openSmine() {
        val i = packageManager.getLaunchIntentForPackage(PACKAGE_SMINE)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } else {
            toast(getString(R.string.not_installed))
        }
    }

    // ---------------- UI helpers ----------------

    private fun applyTierBadge(tier: String, expiry: Long) {
        val expired = expiry != 0L && expiry <= System.currentTimeMillis()
        val effective = if (tier == "FREE" || expired) "FREE" else tier
        txtTierBadge.text = effective
        val bg = when (effective) {
            "DEVELOPER" -> R.drawable.bg_tier_dev
            "VVIP" -> R.drawable.bg_tier_vvip
            "PREMIUM" -> R.drawable.bg_tier_premium
            else -> R.drawable.bg_tier_free
        }
        txtTierBadge.setBackgroundResource(bg)
        val color = when (effective) {
            "DEVELOPER" -> 0xFFFFB300.toInt()
            "VVIP" -> 0xFFE100FF.toInt()
            "PREMIUM" -> 0xFF00E5FF.toInt()
            else -> 0xFFF5F7FF.toInt()
        }
        txtTierBadge.setTextColor(color)
    }

    private fun updateVvipState() {
        val isDev = currentTier == "DEVELOPER"
        btnCreateVvip.isEnabled = isDev
        btnCreateVvip.alpha = if (isDev) 1f else 0.5f
        txtVvipSub.text = if (isDev) getString(R.string.vvip_sub) else getString(R.string.vvip_locked)
    }

    private fun togglePassword() {
        passwordVisible = !passwordVisible
        txtPassword.text = if (passwordVisible) currentPassword else "********"
        findViewById<Button>(R.id.btnTogglePass).text =
            if (passwordVisible) getString(R.string.hide) else getString(R.string.show)
    }

    private fun formatExpiry(expiry: Long): String {
        if (expiry == 0L) return getString(R.string.forever)
        val fmt = SimpleDateFormat("dd MMM yyyy \u00b7 HH:mm", Locale.getDefault())
        return fmt.format(Date(expiry))
    }

    private fun copy(text: String) {
        if (text.isBlank()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("HPX", text))
        toast(getString(R.string.copied))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}

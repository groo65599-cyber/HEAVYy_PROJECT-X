package com.flvhpx.smine.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Central preferences store for HPX SMINE v2.0.
 */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    // ---------- Overlay master ----------
    var overlayEnabled: Boolean
        get() = sp.getBoolean("overlay_enabled", false)
        set(v) = sp.edit().putBoolean("overlay_enabled", v).apply()

    // ---------- Crosshair ----------
    var crosshairEnabled: Boolean
        get() = sp.getBoolean("crosshair_enabled", true)
        set(v) = sp.edit().putBoolean("crosshair_enabled", v).apply()

    var crosshairStyle: Int
        get() = sp.getInt("crosshair_style", 3)
        set(v) = sp.edit().putInt("crosshair_style", v).apply()

    var crosshairColor: Int
        get() = sp.getInt("crosshair_color", 0xFF00FF88.toInt())
        set(v) = sp.edit().putInt("crosshair_color", v).apply()

    var crosshairSize: Int
        get() = sp.getInt("crosshair_size", 42)
        set(v) = sp.edit().putInt("crosshair_size", v).apply()

    var crosshairGap: Int
        get() = sp.getInt("crosshair_gap", 8)
        set(v) = sp.edit().putInt("crosshair_gap", v).apply()

    var crosshairThickness: Int
        get() = sp.getInt("crosshair_thickness", 3)
        set(v) = sp.edit().putInt("crosshair_thickness", v).apply()

    var crosshairDot: Boolean
        get() = sp.getBoolean("crosshair_dot", true)
        set(v) = sp.edit().putBoolean("crosshair_dot", v).apply()

    /** Transparency 10..100 (%) */
    var crosshairAlpha: Int
        get() = sp.getInt("crosshair_alpha", 100)
        set(v) = sp.edit().putInt("crosshair_alpha", v.coerceIn(10, 100)).apply()

    /** Position offset from center, in dp (can be negative) */
    var crosshairOffsetX: Int
        get() = sp.getInt("crosshair_off_x", 0)
        set(v) = sp.edit().putInt("crosshair_off_x", v).apply()

    var crosshairOffsetY: Int
        get() = sp.getInt("crosshair_off_y", 0)
        set(v) = sp.edit().putInt("crosshair_off_y", v).apply()

    var crosshairGlow: Boolean
        get() = sp.getBoolean("crosshair_glow", true)
        set(v) = sp.edit().putBoolean("crosshair_glow", v).apply()

    // ---------- Monitor ----------
    var monitorEnabled: Boolean
        get() = sp.getBoolean("monitor_enabled", true)
        set(v) = sp.edit().putBoolean("monitor_enabled", v).apply()

    var monitorShowFps: Boolean
        get() = sp.getBoolean("monitor_fps", true)
        set(v) = sp.edit().putBoolean("monitor_fps", v).apply()

    var monitorShowCpu: Boolean
        get() = sp.getBoolean("monitor_cpu", true)
        set(v) = sp.edit().putBoolean("monitor_cpu", v).apply()

    var monitorShowGpu: Boolean
        get() = sp.getBoolean("monitor_gpu", true)
        set(v) = sp.edit().putBoolean("monitor_gpu", v).apply()

    var monitorShowRam: Boolean
        get() = sp.getBoolean("monitor_ram", true)
        set(v) = sp.edit().putBoolean("monitor_ram", v).apply()

    var monitorShowBattery: Boolean
        get() = sp.getBoolean("monitor_battery", true)
        set(v) = sp.edit().putBoolean("monitor_battery", v).apply()

    var monitorShowTime: Boolean
        get() = sp.getBoolean("monitor_time", true)
        set(v) = sp.edit().putBoolean("monitor_time", v).apply()

    /** 0 = horizontal bar (ROG style), 1 = vertical stack */
    var monitorOrientation: Int
        get() = sp.getInt("monitor_orientation", 0)
        set(v) = sp.edit().putInt("monitor_orientation", v).apply()

    var monitorPosition: Int
        get() = sp.getInt("monitor_position", 0) // 0 TL, 1 TR, 2 BL, 3 BR
        set(v) = sp.edit().putInt("monitor_position", v).apply()

    var monitorX: Int
        get() = sp.getInt("monitor_x", -1)
        set(v) = sp.edit().putInt("monitor_x", v).apply()

    var monitorY: Int
        get() = sp.getInt("monitor_y", -1)
        set(v) = sp.edit().putInt("monitor_y", v).apply()

    /** true = full ROG bar, false = compact pill (FPS + time only) */
    var monitorExpanded: Boolean
        get() = sp.getBoolean("monitor_expanded", true)
        set(v) = sp.edit().putBoolean("monitor_expanded", v).apply()

    // ---------- Floating dock position ----------
    var floatDockX: Int
        get() = sp.getInt("dock_x", -1)
        set(v) = sp.edit().putInt("dock_x", v).apply()

    var floatDockY: Int
        get() = sp.getInt("dock_y", -1)
        set(v) = sp.edit().putInt("dock_y", v).apply()

    // ---------- Edge / bottom sheet panel ----------
    var edgePanelEnabled: Boolean
        get() = sp.getBoolean("edge_enabled", true)
        set(v) = sp.edit().putBoolean("edge_enabled", v).apply()

    var edgeY: Int
        get() = sp.getInt("edge_y", 0)
        set(v) = sp.edit().putInt("edge_y", v).apply()

    // ---------- Login animation overlay ----------
    var loginAnimEnabled: Boolean
        get() = sp.getBoolean("login_anim", true)
        set(v) = sp.edit().putBoolean("login_anim", v).apply()

    // ---------- Floating window (premium) ----------
    var floatingWindowEnabled: Boolean
        get() = sp.getBoolean("floating_window", true)
        set(v) = sp.edit().putBoolean("floating_window", v).apply()

    // ---------- Network optimizer (premium) ----------
    var netOptimizerEnabled: Boolean
        get() = sp.getBoolean("net_optimizer", false)
        set(v) = sp.edit().putBoolean("net_optimizer", v).apply()

    var netDnsPrimary: String
        get() = sp.getString("net_dns1", "1.1.1.1") ?: "1.1.1.1"
        set(v) = sp.edit().putString("net_dns1", v).apply()

    var netDnsSecondary: String
        get() = sp.getString("net_dns2", "8.8.8.8") ?: "8.8.8.8"
        set(v) = sp.edit().putString("net_dns2", v).apply()

    // ---------- Sensitivity ----------
    var sensiMode: String
        get() = sp.getString("sensi_mode", "LOW") ?: "LOW"
        set(v) = sp.edit().putString("sensi_mode", v).apply()

    // ---------- FPS Optimizer ----------
    var optAnimScale: Boolean
        get() = sp.getBoolean("opt_anim", false)
        set(v) = sp.edit().putBoolean("opt_anim", v).apply()

    var optKillBg: Boolean
        get() = sp.getBoolean("opt_killbg", false)
        set(v) = sp.edit().putBoolean("opt_killbg", v).apply()

    // ---------- Launcher ----------
    var launcherApps: String
        get() = sp.getString("launcher_apps", "") ?: ""
        set(v) = sp.edit().putString("launcher_apps", v).apply()

    fun launcherList(): MutableList<String> =
        launcherApps.split(",").filter { it.isNotBlank() }.toMutableList()

    /** Free tier capped at 3 apps; premium/vvip/developer unlimited. */
    fun setLauncherList(list: List<String>) {
        launcherApps = if (isPremiumTier()) list.joinToString(",") else list.take(3).joinToString(",")
    }

    var autoLogin: Boolean
        get() = sp.getBoolean("auto_login", false)
        set(v) = sp.edit().putBoolean("auto_login", v).apply()

    // ---------- Account ----------
    var accountUsername: String
        get() = sp.getString("acc_user", "") ?: ""
        set(v) = sp.edit().putString("acc_user", v).apply()

    var accountPassword: String
        get() = sp.getString("acc_pass", "") ?: ""
        set(v) = sp.edit().putString("acc_pass", v).apply()

    /** FREE | PREMIUM | VVIP | DEVELOPER */
    var accountTier: String
        get() = sp.getString("acc_tier", "FREE") ?: "FREE"
        set(v) = sp.edit().putString("acc_tier", v.uppercase()).apply()

    /** 0 = forever, otherwise epoch millis */
    var accountExpiry: Long
        get() = sp.getLong("acc_expiry", 0L)
        set(v) = sp.edit().putLong("acc_expiry", v).apply()

    var accountCreatedAt: Long
        get() = sp.getLong("acc_created", 0L)
        set(v) = sp.edit().putLong("acc_created", v).apply()

    /** Fallback device seed when ANDROID_ID is unavailable. */
    var deviceSeed: String
        get() = sp.getString("device_seed", "") ?: ""
        set(v) = sp.edit().putString("device_seed", v).apply()

    fun isPremiumTier(): Boolean {
        val t = accountTier
        if (t == "FREE") return false
        val exp = accountExpiry
        return exp == 0L || exp > System.currentTimeMillis()
    }

    fun isDeveloper(): Boolean = accountTier == "DEVELOPER"

    // ---------- Energy (free tier) ----------
    var energy: Int
        get() = sp.getInt("energy", 300)
        set(v) = sp.edit().putInt("energy", v.coerceIn(0, MAX_ENERGY)).apply()

    var lastAdReward: Long
        get() = sp.getLong("last_ad_reward", 0L)
        set(v) = sp.edit().putLong("last_ad_reward", v).apply()

    // ---------- Game Graphics Quality ----------
    /** 0 = LOW (lightest / "Minecraft" look), 1 = MEDIUM, 2 = HIGH */
    var graphicsQuality: Int
        get() = sp.getInt("graphics_quality", 1)
        set(v) = sp.edit().putInt("graphics_quality", v.coerceIn(0, 2)).apply()

    /** When true the overlay drops its own heavy effects (glow/blur) to save GPU. */
    var graphicsLiteOverlay: Boolean
        get() = sp.getBoolean("graphics_lite_overlay", false)
        set(v) = sp.edit().putBoolean("graphics_lite_overlay", v).apply()

    // ---------- Macro ----------
    /** Serialized macro steps (JSON). Empty = no macro recorded. */
    var macroSteps: String
        get() = sp.getString("macro_steps", "") ?: ""
        set(v) = sp.edit().putString("macro_steps", v).apply()

    /** Playback speed multiplier x10 (e.g. 10 = 1.0x, 20 = 2.0x). */
    var macroSpeed: Int
        get() = sp.getInt("macro_speed", 10)
        set(v) = sp.edit().putInt("macro_speed", v.coerceIn(5, 30)).apply()

    var macroLoop: Boolean
        get() = sp.getBoolean("macro_loop", false)
        set(v) = sp.edit().putBoolean("macro_loop", v).apply()

    var macroName: String
        get() = sp.getString("macro_name", "") ?: ""
        set(v) = sp.edit().putString("macro_name", v).apply()

    /** v2.0.5: show the floating macro button (Touch-Macro-Pro style). */
    var macroEnabled: Boolean
        get() = sp.getBoolean("macro_enabled", false)
        set(v) = sp.edit().putBoolean("macro_enabled", v).apply()

    var macroFabX: Int
        get() = sp.getInt("macro_fab_x", -1)
        set(v) = sp.edit().putInt("macro_fab_x", v).apply()

    var macroFabY: Int
        get() = sp.getInt("macro_fab_y", -1)
        set(v) = sp.edit().putInt("macro_fab_y", v).apply()

    // ---------- Floating window (mini browser) ----------
    var floatBrowserEnabled: Boolean
        get() = sp.getBoolean("float_browser_enabled", false)
        set(v) = sp.edit().putBoolean("float_browser_enabled", v).apply()

    var browserUrl: String
        get() = sp.getString("browser_url", "https://m.youtube.com") ?: "https://m.youtube.com"
        set(v) = sp.edit().putString("browser_url", v).apply()

    var browserX: Int
        get() = sp.getInt("browser_x", -1)
        set(v) = sp.edit().putInt("browser_x", v).apply()

    var browserY: Int
        get() = sp.getInt("browser_y", -1)
        set(v) = sp.edit().putInt("browser_y", v).apply()

    var browserW: Int
        get() = sp.getInt("browser_w", 0)
        set(v) = sp.edit().putInt("browser_w", v).apply()

    var browserH: Int
        get() = sp.getInt("browser_h", 0)
        set(v) = sp.edit().putInt("browser_h", v).apply()

    /** Floating browser keeps input focus (keyboard works, game may pause). */
    var browserFocus: Boolean
        get() = sp.getBoolean("browser_focus", false)
        set(v) = sp.edit().putBoolean("browser_focus", v).apply()

    // ---------- Screen dim (brightness fallback) ----------
    /** 0 = off, 1..90 = dim percentage applied by a translucent overlay. */
    var dimLevel: Int
        get() = sp.getInt("dim_level", 0)
        set(v) = sp.edit().putInt("dim_level", v.coerceIn(0, 90)).apply()

    // ---------- v2.0.5 extras ----------
    /** Live ping readout in the monitor. */
    var monitorShowPing: Boolean
        get() = sp.getBoolean("monitor_ping", true)
        set(v) = sp.edit().putBoolean("monitor_ping", v).apply()

    /** Floating game timer / stopwatch. */
    var gameTimerEnabled: Boolean
        get() = sp.getBoolean("game_timer", false)
        set(v) = sp.edit().putBoolean("game_timer", v).apply()

    /** Crosshair preset id (0 = custom). */
    var crosshairPreset: Int
        get() = sp.getInt("crosshair_preset", 0)
        set(v) = sp.edit().putInt("crosshair_preset", v).apply()

    // ---------- Recommended extras ----------
    /** Best-effort auto boost: kill background apps whenever a game is launched. */
    var autoBoost: Boolean
        get() = sp.getBoolean("auto_boost", false)
        set(v) = sp.edit().putBoolean("auto_boost", v).apply()

    /** Do-Not-Disturb quick toggle state. */
    var dndEnabled: Boolean
        get() = sp.getBoolean("dnd_enabled", false)
        set(v) = sp.edit().putBoolean("dnd_enabled", v).apply()

    /** Keep screen awake while the overlay is running. */
    var keepAwake: Boolean
        get() = sp.getBoolean("keep_awake", false)
        set(v) = sp.edit().putBoolean("keep_awake", v).apply()

    // ---------- Misc ----------
    var firstRun: Boolean
        get() = sp.getBoolean("first_run", true)
        set(v) = sp.edit().putBoolean("first_run", v).apply()

    var splashShown: Boolean
        get() = sp.getBoolean("splash_shown", false)
        set(v) = sp.edit().putBoolean("splash_shown", v).apply()

    companion object {
        const val NAME = "hpx_smine_prefs"
        const val MAX_ENERGY = 600
        const val ENERGY_PER_RUN = 100
        const val ENERGY_PER_AD = 100
    }
}

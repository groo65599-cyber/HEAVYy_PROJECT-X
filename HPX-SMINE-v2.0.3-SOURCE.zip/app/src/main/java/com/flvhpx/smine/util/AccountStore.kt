package com.flvhpx.smine.util

import android.content.Context

/**
 * Local account store for HPX SMINE.
 *
 * On first launch a FREE account is created with a FIXED default username &
 * password so that every device starts with the SAME credentials (this was the
 * bug where each device generated a different random account). The user can
 * change the credentials from the Account screen; the values are persisted
 * locally and exposed to the companion app (HPX PREMM ACCESS) through
 * [com.flvhpx.smine.provider.AccountProvider] so a free account can be upgraded.
 */
class AccountStore(private val context: Context) {

    private val prefs = Prefs(context)

    /** Ensure an account exists; returns true if a new one was created. */
    fun ensureAccount(): Boolean {
        if (prefs.accountUsername.isNotBlank()) return false
        prefs.accountUsername = DEFAULT_USERNAME
        prefs.accountPassword = DEFAULT_PASSWORD
        prefs.accountTier = "FREE"
        prefs.accountExpiry = 0L
        prefs.accountCreatedAt = System.currentTimeMillis()
        prefs.energy = 300
        return true
    }

    fun username(): String = prefs.accountUsername
    fun password(): String = prefs.accountPassword
    fun tier(): String = prefs.accountTier
    fun expiry(): Long = prefs.accountExpiry
    fun createdAt(): Long = prefs.accountCreatedAt

    /**
     * Update the locally stored login credentials. Blank values are ignored so
     * the account can never end up without a username/password.
     */
    fun setCredentials(newUsername: String, newPassword: String): Boolean {
        val u = newUsername.trim()
        val p = newPassword.trim()
        if (u.isEmpty() || p.isEmpty()) return false
        prefs.accountUsername = u
        prefs.accountPassword = p
        return true
    }

    /** Reset the credentials back to the shared defaults. */
    fun resetCredentials() {
        prefs.accountUsername = DEFAULT_USERNAME
        prefs.accountPassword = DEFAULT_PASSWORD
    }

    /** Apply an upgrade coming from the admin app. */
    fun upgrade(tier: String, durationDays: Int) {
        prefs.accountTier = tier
        prefs.accountExpiry = if (durationDays <= 0) 0L
        else System.currentTimeMillis() + durationDays.toLong() * 86_400_000L
    }

    fun isPremium(): Boolean = prefs.isPremiumTier()
    fun isDeveloper(): Boolean = prefs.isDeveloper()

    fun tierLabel(): String {
        val t = prefs.accountTier
        if (t == "FREE") return "FREE"
        val exp = prefs.accountExpiry
        if (exp != 0L && exp <= System.currentTimeMillis()) return "FREE (expired)"
        return t
    }

    companion object {
        /** Shared defaults so every device starts with the same account. */
        const val DEFAULT_USERNAME = "HPX-USER"
        const val DEFAULT_PASSWORD = "HPX-2025"
    }
}

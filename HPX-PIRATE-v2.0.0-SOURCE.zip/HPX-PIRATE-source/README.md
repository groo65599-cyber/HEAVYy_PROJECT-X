# HPX PIRATE

**Gaming Performance Center for Windows 10 / 11 (x64)**

HPX PIRATE is a lightweight, all-in-one Windows desktop utility that helps you get
**more stable frame times, lower input latency and a cleaner, faster system** — without
ever touching game memory, injecting DLLs, or doing anything that a fair-play policy
would flag.

> **Fair-play first.** HPX PIRATE contains **no** aimbot, **no** head-lock, **no**
> auto-targeting, **no** wallhack, **no** memory ESP, **no** enemy detection, **no** DLL
> injection and **no** anti-cheat bypass. Every feature works only on **your own** input
> and **your own** system. See [Fair-Play & Safety](#fair-play--safety).

> **Fix only what is broken.** HPX PIRATE **diagnoses before it changes anything**. Every
> optimizer and boost action follows **DETECT → DIAGNOSE → EXPLAIN → APPLY → VERIFY →
> ROLLBACK**. When nothing is wrong the app says **"NO ISSUE DETECTED — current
> configuration will be preserved"** and leaves your system untouched. There are **no fake
> buttons, no fake metrics and no fake FPS**: if a value cannot be measured on your machine,
> the UI shows **"NOT AVAILABLE ON THIS SYSTEM"** instead of inventing a number.

---

## Table of contents

- [Feature overview](#feature-overview)
- [Screens / modules](#screens--modules)
- [The HPX PIRATE Toolbox](#the-hpx-pirate-toolbox)
- [ULTRA FPS BOOST engine](#ultra-fps-boost-engine)
- [Fair-Play & Safety](#fair-play--safety)
- [Architecture](#architecture)
- [Requirements](#requirements)
- [Quick start (end users)](#quick-start-end-users)
- [Build from source](#build-from-source)
- [Create the installer](#create-the-installer)
- [Testing](#testing)
- [Configuration & data files](#configuration--data-files)
- [Performance & resource usage](#performance--resource-usage)
- [Troubleshooting](#troubleshooting)
- [Project layout](#project-layout)
- [Roadmap](#roadmap)
- [License](#license)

---

## Feature overview

| Module | What it does |
| --- | --- |
| **HPX PERFORMANCE ENGINE** | **Diagnoses first**, then applies reversible, documented Windows tweaks (power plan, Game Mode, Game DVR, visual effects, priority, temp/cache cleanup) with a Restore Point + per-change UNDO. If nothing is wrong it changes nothing. |
| **ULTRA FPS BOOST ENGINE** | A **measured** boost flow: detect display/hardware → baseline → analyse → identify bottleneck → build plan → show changes → apply → measure → compare → **keep or roll back**. No fake FPS. |
| **FPS Monitor** | Real-time FPS, frame time, 1% / 0.1% lows captured via **ETW** (`DxgKrnl` Present events — the PresentMon technique). No injection. |
| **HPX ANALYZER** | Turns a capture into a verdict: average / min / max FPS, frame-time consistency, stutter count, and a plain-language summary. |
| **Bottleneck Detection** | Compares CPU vs GPU load & frame time to tell you which component is limiting you — derived from measurements, never guessed. |
| **Game Profile Manager** | Save/load/export/import per-game profiles (optimizer preset + crosshair + mapping + drag settings). Automatic backup before overwrite. |
| **CONTROL MAPPER** | Remap keyboard/mouse buttons with a visual editor; global low-level hooks (`WH_KEYBOARD_LL` / `WH_MOUSE_LL`). |
| **HPX DRAG ASSIST** | Response curves (Linear / Smooth / FastStart / SlowStart / Precision / Custom), deadzone, EMA smoothing and a micro-movement stabiliser. |
| **HPX EASY DRAG** | A dedicated lab that makes mouse **dragging** feel lighter and more consistent — with **real measured** stability & smoothness scores. |
| **HPX CROSSHAIR** | A click-through, always-on-top overlay crosshair with shape/colour/size/gap/opacity/offset controls and a global toggle hotkey. |
| **Sensitivity System** | Mouse/aim sensitivity with a **Test Area** (tap / drag / swipe / circular) that reports real distance, duration, speed and consistency. |
| **Keyboard** | Live input monitor with per-key state, event stream and measured response latency. |
| **Controller (XInput)** | Real XInput support (runtime-probed `xinput1_4` / `1_3` / `9_1_0`) with a live stick/trigger/button visual and mapping. |
| **Diagnostics / Health Check** | Runs real checks across every subsystem and reports **PASS / WARN / FAIL / NOT SUPPORTED** per item. Fix only what is broken. |
| **HPX PIRATE Toolbox** | A full toolbox of 13 real tools (see below) with search, favourites, recents and honest readiness labels. |
| **Bug Report** | Builds a privacy-safe diagnostic bundle (environment + checks + logs) you can export or copy. |
| **Process Manager** | View processes, set priority, and keep a full change log with one-click rollback. |
| **Real-Time Monitor** | Live graphs for FPS, frame time, CPU, GPU and RAM, plus a before/after benchmark tool. |
| **Settings & Recovery** | Tabbed settings (General / Input / Performance / Safety & Recovery / Advanced), start-with-Windows, tray, restore points, backup/restore, safe & diagnostic modes. |

---

## Screens / modules

The left navigation is organised into five groups:

**DASHBOARD**
1. **Dashboard** – system snapshot, quick actions, live status.

**PERFORMANCE**
2. **Performance** – the HPX PERFORMANCE ENGINE (diagnosis → tweak catalog → apply → undo).
3. **Monitor** – FPS monitor, real-time graphs, analyzer and benchmark.
4. **Ultra FPS Boost** – the measured boost engine (detect → baseline → analyse → plan → apply → compare → keep/rollback).

**GAME CONTROL**
5. **Game Profiles** – Game Profile Manager (create, save, load, export, import, backup).
6. **Control Mapper** – visual keyboard/mouse remapping.
7. **Sensitivity** – sensitivity system + Test Area.
8. **Keyboard** – live input monitor + latency.
9. **Controller** – XInput visual + mapping.

**TOOLS**
10. **Toolbox** – the HPX PIRATE Toolbox hub (search / favourites / recents / status).
11. **Drag Assist** – response curves and drag tuning.
12. **Easy Drag Lab** – the Easy Drag lab with measured metrics.
13. **Crosshair** – overlay designer with live preview.

**SYSTEM**
14. **System Optimizer** – Process Manager, startup apps, change log & rollback (diagnosis-first).
15. **Diagnostics** – full health check across every subsystem.
16. **Bug Report** – build and export a diagnostic bundle.
17. **Settings** – tabbed: General / Input / Performance / Safety & Recovery / Advanced.

The UI uses a dark, cyberpunk card dashboard (neon-magenta accent, cyan secondary,
semi-transparent panels, thin borders, soft glow) and a custom chrome window with a
matching dark title bar. It is responsive across **1280×720, 1366×768, 1600×900,
1920×1080 and 2560×1440**.

---

## The HPX PIRATE Toolbox

Every tool below has a **real, working view** behind it. There are no placeholders. Each
card shows an honest readiness label (**FUNCTIONAL / REQUIRES ADMIN / NOT SUPPORTED**).

| Tool | What it does |
| --- | --- |
| **Input Tester** | Live keyboard, mouse and controller monitor with real event timing and estimated polling rate. |
| **Latency Analyzer** | Measures real stimulus-to-input response latency with min / max / P95 / std-dev statistics. |
| **Calibration** | Estimates mouse polling rate and detects deadzone / jitter from live movement. |
| **Input Recorder** | Records input events and exports them to CSV/JSON for analysis. |
| **Mapping Tester** | Press any key and see exactly which action your profile maps it to. |
| **Profile Converter** | Imports, exports and converts game profiles between formats. |
| **Sensitivity Lab** | Runs a drag test and compares response curves with real measurements. |
| **Response Curve** | Visualises and tunes the input response curve applied to your mouse. |
| **Frame Analyzer** | Inspects live frame times, 1% lows and frame spikes. |
| **Ultra FPS Boost** | The measured boost engine (also reachable from PERFORMANCE). |
| **Configuration Backup** | Snapshots and restores settings, profiles and keymapping. |
| **Diagnostics** | Runs real health checks across every subsystem. |
| **Overlay Studio** | Designs the crosshair and on-screen overlay with a live preview. |

---

## ULTRA FPS BOOST engine

The boost engine is deliberately honest. It never claims a number it did not measure.

```
DETECT  →  BASELINE  →  ANALYSE  →  IDENTIFY BOTTLENECK  →  CREATE PLAN
        →  SHOW CHANGES  →  APPLY  →  MEASURE  →  COMPARE  →  VERIFY  →  KEEP OR ROLLBACK
```

- **Targets are real.** You pick a mode (Balanced / High FPS / Ultra FPS / Competitive /
  Custom) and a target (120–240+). The engine checks it against your **actual display
  refresh rate** and reports honestly if the target is unreachable.
- **Baseline & after are measured** through the same ETW capture used by the Monitor.
- **Bottleneck detection** distinguishes CPU-, GPU-, memory-, thermal-, game-, display- and
  FPS-cap-limited scenarios from real data.
- **Keep or roll back.** After the comparison, changes are only **kept** if they measurably
  improved FPS; otherwise they are **rolled back** to preserve your configuration.
- **FPS drop recorder** logs drop events with the context captured at the moment they
  happened (CPU/GPU/RAM and the active process).

---

## Fair-Play & Safety

### Fair-play guarantees (hard-coded design rules)

- **No** aimbot / aim-assist / head-lock / trigger-bot.
- **No** auto-targeting or enemy/player detection of any kind.
- **No** wallhack, **no** memory ESP, **no** reading of game memory.
- **No** DLL injection, **no** hooking of game processes, **no** anti-cheat bypass.
- **Easy Drag / Drag Assist / Sensitivity** operate **only** on the user's own mouse input
  stream (smoothing, curves, deadzone). They never look at what is on screen or in memory.

### Safety guarantees (system changes)

- **Diagnose before changing.** No action is applied unless the diagnosis actually flags a
  condition. "No issue detected" means nothing is touched.
- A **System Restore Point** is created before applying optimizations (configurable).
- **Every** change is logged with an **UNDO / RESTORE** action.
- The app **shows what it will change before you apply it**.
- Only **HKCU** (current-user) registry keys are touched — never machine-wide risky edits
  without a backup.
- **No** system files are ever deleted; **no** Windows services are blindly disabled.
- **No** automatic overclocking.
- Priority order enforced everywhere: **STABILITY → SAFETY → LOW LATENCY → PERFORMANCE → VISUALS**.
- The app never crashes when no game is running — the FPS monitor simply reports "no
  active capture" and the rest of the app keeps working.
- **Safe Mode** limits optimizations to the lowest-risk actions only.

---

## Architecture

- **.NET 8 (net8.0-windows), WPF**, MVVM.
- **ViewModels** per module + a shared `AppHost` service container (manual DI).
- **Services** (all in `Services/`): logging, settings, profiles, hardware monitor,
  FPS monitor (ETW), bottleneck analyzer, FPS analyzer, restore points, process manager,
  system optimizer (diagnosis-first), drag engine, input mapper, crosshair overlay,
  controller (XInput), input test, sensitivity, diagnostics, FPS boost engine, safe update,
  tool registry, bug report, history buffer.
- **Interop** (`Interop/`): P/Invoke signatures + low-level input hooks on a dedicated
  STA thread.
- **Persistence**: JSON (`System.Text.Json`, camelCase, enum-as-string) under
  `%APPDATA%\HPXPirate`.
- **Charts**: a dependency-free custom `LineGraph` `FrameworkElement` (no charting NuGet).

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the full breakdown.

---

## Requirements

**End users**

- Windows 10 (1809+) or Windows 11, **64-bit**.
- **.NET 8 Desktop Runtime (x64)** — the installer offers to install it if missing.
- Administrator rights (needed for restore points and system tuning). The app manifest
  requests elevation.

**Developers / build**

- **.NET SDK 8.0** (builds fine from Linux/macOS thanks to `EnableWindowsTargeting`).
- **Inno Setup 6** (only to build the `.exe` installer).
- Windows is **not** required to *compile*; it is required to *run* the app.

---

## Quick start (end users)

1. Run **`HPX-PIRATE-Setup.exe`** and follow the wizard (accept the UAC prompt).
2. Launch **HPX PIRATE** from the Start menu or desktop.
3. Open **Performance** and click **RE-DIAGNOSE** to see whether anything actually needs
   changing. If it says **NO ISSUE DETECTED**, you are already good — nothing is touched.
4. Open **Monitor**, start a capture, and play your game to see FPS and frame times.
5. Try **Ultra FPS Boost** for a measured before/after comparison you can keep or roll back.
6. Use **Game Profiles** to save a per-game setup, and **Settings** to make it start with Windows.

Everything is reversible: use **UNDO** per change, or **UNDO ALL** in the Optimizer.

---

## Build from source

### 1. Restore & build

```bash
# from the repository root
dotnet restore HPX-PIRATE.sln
dotnet build src/HPXPirate/HPXPirate.csproj -c Release
```

> Building on Linux/macOS works because the project sets
> `<EnableWindowsTargeting>true</EnableWindowsTargeting>`. You still need the .NET 8 SDK.

### 2. Run

```bash
dotnet run --project src/HPXPirate/HPXPirate.csproj -c Release
```

(On Windows this launches the WPF window. On Linux it compiles but cannot display WPF.)

### 3. Publish (framework-dependent, x64)

```bash
dotnet publish src/HPXPirate/HPXPirate.csproj -c Release -r win-x64 \
    --self-contained false -o publish
```

Output: `publish/HPXPirate.exe` plus dependency DLLs.

For a **self-contained** build (no .NET runtime required on the target machine):

```bash
dotnet publish src/HPXPirate/HPXPirate.csproj -c Release -r win-x64 \
    --self-contained true -p:PublishSingleFile=true -o publish-selfcontained
```

See [`BUILD.md`](BUILD.md) for the complete, copy-pasteable instructions including the
installer.

---

## Create the installer

```powershell
# elevated PowerShell, from the repo root
powershell -ExecutionPolicy Bypass -File installer\build-installer.ps1
```

This publishes the app and compiles `dist\HPX-PIRATE-Setup.exe` with Inno Setup.
The raw Inno Setup script is [`installer/HPX-PIRATE.iss`](installer/HPX-PIRATE.iss).

---

## Testing

A **headless, dependency-free** logic test suite validates the platform-independent
core (settings persistence, profile CRUD/import/export/backup/restore, drag engine,
FPS analyzer, bottleneck analyzer, history buffer, **toolbox catalogue**, **FPS-boost
before/after comparison**, **performance-sample stability**, **latency statistics**,
**optimization diagnosis verdict** and the **FPS drop recorder**):

```bash
dotnet run --project tests/HPXPirate.LogicTests -c Release
# -> "103 passed, 0 failed"
```

To isolate test data from your real config:

```bash
XDG_CONFIG_HOME=/tmp/hpx_test_config dotnet run --project tests/HPXPirate.LogicTests -c Release
```

Manual smoke tests to run on Windows:

- App starts with no game running (FPS monitor shows "no capture").
- Change a setting → close → reopen → setting persisted.
- Create a profile → save → load → values restored.
- Run a diagnosis → when nothing is wrong it reports "NO ISSUE DETECTED" and applies nothing.
- Apply one optimization → UNDO restores the previous state.
- Run Ultra FPS Boost → baseline, apply, measure, then keep or roll back based on real FPS.
- Toggle the crosshair overlay; it stays click-through and always-on-top.

---

## Configuration & data files

All user data lives under **`%APPDATA%\HPXPirate`**:

```
%APPDATA%\HPXPirate\
├── settings.json            # app settings
├── changes.json             # optimization change log (for rollback)
├── toolbox.json             # toolbox favourites & recents
├── logs\                    # rolling log files
├── profiles\                # *.json game profiles
│   └── backups\             # automatic profile backups
├── backups\                 # settings / config backups
└── restorepoints\           # restore-point records
```

Logs are plain text and safe to share when reporting issues.

---

## Performance & resource usage

- **Idle**: monitoring interval automatically relaxes (see *ReduceMonitoringWhenIdle*)
  so the app stays light on CPU/RAM when you are not gaming.
- **No background polling of game memory** — FPS is captured from OS-level ETW events
  only while a capture is active.
- Hardware sensors (LibreHardwareMonitor) degrade gracefully: if a sensor is
  unavailable, the UI shows "n/a" instead of failing.
- HPX PIRATE is designed so that **it does not itself cause lag** — monitoring can be
  throttled or reduced when idle.

> We deliberately avoid marketing claims like "2× FPS" or "100% anti-drop". HPX PIRATE
> reports **measured** numbers only.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| App won't start, error about .NET | Install the **.NET 8 Desktop Runtime (x64)**. |
| No FPS shown | Start a capture in **Monitor** *while* the game is running; some anti-cheat-protected games block ETW providers. |
| Temps/load show "n/a" | Your hardware/sensors may need a newer LibreHardwareMonitor; run as admin. |
| A tool shows "NOT AVAILABLE ON THIS SYSTEM" | That capability (e.g. XInput controller, a specific sensor) is not present — the app will not fake it. |
| Optimizations not applying | Make sure you accepted the UAC prompt (the app needs admin). |
| Want to revert everything | **Optimizer → UNDO ALL**, or use the Windows System Restore point created before changes. |

Logs: `%APPDATA%\HPXPirate\logs\`.

---

## Project layout

```
HPX-PIRATE.sln
src/HPXPirate/
├── App.xaml(.cs)              # startup, crash protection
├── MainWindow.xaml(.cs)       # shell + grouped navigation + tray
├── Themes/                    # Colors.xaml, Controls.xaml (dark cyberpunk)
├── Models/                    # Settings, GameProfile, Optimization, PerformanceMetrics,
│                              # Diagnostics, InputTesting, FpsBoost, Tools, Controller,
│                              # Backup, BugReport
├── Services/                  # all engine services (see Architecture)
├── Interop/                   # P/Invoke + input hooks
├── ViewModels/                # one per module + toolbox/boost/bug-report VMs
├── Views/                     # one XAML view per module + overlay window + tool views
├── Controls/LineGraph.cs      # dependency-free chart
└── Converters/                # value converters
tests/HPXPirate.LogicTests/    # headless logic tests (103 checks)
installer/                     # Inno Setup script + build helper
docs/                          # ARCHITECTURE.md
```

---

## Roadmap

- Per-monitor crosshair offsets.
- More response-curve presets and importable curve files.
- Optional CSV export of monitor sessions.
- Full localisation (English / Indonesian) for the UI strings.

---

## License

Released under the **MIT License** — see [`LICENSE`](LICENSE).

HPX PIRATE is an independent utility and is **not affiliated with, endorsed by, or
sponsored by** any game publisher. Use it responsibly and always respect the terms of
service of the games you play.

using System.Collections;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using HPXPirate.Models;

namespace HPXPirate.Converters;

/// <summary>Maps a <see cref="CheckStatus"/> to a status brush (ok / warn / error / not-supported).</summary>
public sealed class CheckStatusToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush Ok = Frozen(0x35, 0xE0, 0x8A);
    private static readonly SolidColorBrush Warn = Frozen(0xFF, 0xB0, 0x20);
    private static readonly SolidColorBrush Bad = Frozen(0xFF, 0x4D, 0x6D);
    private static readonly SolidColorBrush Muted = Frozen(0x6B, 0x64, 0x85);

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value switch
        {
            CheckStatus.Ok => Ok,
            CheckStatus.Warning => Warn,
            CheckStatus.Error => Bad,
            CheckStatus.NotSupported => Muted,
            _ => Muted
        };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;

    internal static SolidColorBrush Frozen(byte r, byte g, byte b)
    {
        var brush = new SolidColorBrush(Color.FromRgb(r, g, b));
        brush.Freeze();
        return brush;
    }
}

/// <summary>Maps a <see cref="CheckStatus"/> to a soft tint brush for pill backgrounds.</summary>
public sealed class CheckStatusToTintConverter : IValueConverter
{
    private static readonly SolidColorBrush Ok = Frozen(0x22, 0x35, 0xE0, 0x8A);
    private static readonly SolidColorBrush Warn = Frozen(0x22, 0xFF, 0xB0, 0x20);
    private static readonly SolidColorBrush Bad = Frozen(0x22, 0xFF, 0x4D, 0x6D);
    private static readonly SolidColorBrush Muted = Frozen(0x1F, 0xFF, 0xFF, 0xFF);

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value switch
        {
            CheckStatus.Ok => Ok,
            CheckStatus.Warning => Warn,
            CheckStatus.Error => Bad,
            CheckStatus.NotSupported => Muted,
            _ => Muted
        };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;

    private static SolidColorBrush Frozen(byte a, byte r, byte g, byte b)
    {
        var brush = new SolidColorBrush(Color.FromArgb(a, r, g, b));
        brush.Freeze();
        return brush;
    }
}

/// <summary>Maps a <see cref="CheckStatus"/> to a Segoe MDL2 glyph.</summary>
public sealed class CheckStatusToGlyphConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value switch
        {
            CheckStatus.Ok => "\uE73E",            // CheckMark
            CheckStatus.Warning => "\uE7BA",       // Warning
            CheckStatus.Error => "\uEA39",         // ErrorBadge
            CheckStatus.NotSupported => "\uE711",  // Cancel
            _ => "\uE9CE"                          // Unknown
        };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>Maps a <see cref="ToolReadiness"/> to a brush.</summary>
public sealed class ToolReadinessToBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value switch
        {
            ToolReadiness.Functional => CheckStatusToBrushConverter.Frozen(0x35, 0xE0, 0x8A),
            ToolReadiness.RequiresAdmin => CheckStatusToBrushConverter.Frozen(0xFF, 0xB0, 0x20),
            ToolReadiness.NotSupported => CheckStatusToBrushConverter.Frozen(0x6B, 0x64, 0x85),
            _ => CheckStatusToBrushConverter.Frozen(0x9C, 0x93, 0xB8)
        };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>Maps a <see cref="ToolTier"/> to a brush.</summary>
public sealed class ToolTierToBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value switch
        {
            ToolTier.Core => CheckStatusToBrushConverter.Frozen(0x35, 0xE0, 0x8A),
            ToolTier.Advanced => CheckStatusToBrushConverter.Frozen(0x2B, 0xE7, 0xFF),
            ToolTier.Experimental => CheckStatusToBrushConverter.Frozen(0xFF, 0xB0, 0x20),
            _ => CheckStatusToBrushConverter.Frozen(0x9C, 0x93, 0xB8)
        };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>Maps a diagnostic verdict string ("NO ISSUE DETECTED" / "ISSUE DETECTED") to a brush.</summary>
public sealed class VerdictToBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var s = (value?.ToString() ?? "").ToUpperInvariant();
        if (s.Contains("NO ISSUE")) return CheckStatusToBrushConverter.Frozen(0x35, 0xE0, 0x8A);
        if (s.Contains("ATTENTION")) return CheckStatusToBrushConverter.Frozen(0xFF, 0xB0, 0x20);
        if (s.Contains("ISSUE")) return CheckStatusToBrushConverter.Frozen(0xFF, 0x4D, 0x6D);
        return CheckStatusToBrushConverter.Frozen(0x9C, 0x93, 0xB8);
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>Collapses the element when the bound collection / number is empty (0).</summary>
public sealed class CountToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        int n = value switch
        {
            int i => i,
            ICollection c => c.Count,
            IEnumerable e => Count(e),
            _ => 0
        };
        return n > 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;

    private static int Count(IEnumerable e)
    {
        int n = 0;
        foreach (var _ in e) n++;
        return n;
    }
}

/// <summary>Shows the element only when the bound collection / number is empty (0).</summary>
public sealed class ZeroToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        int n = value switch
        {
            int i => i,
            ICollection c => c.Count,
            IEnumerable e => Count(e),
            _ => 0
        };
        return n == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;

    private static int Count(IEnumerable e)
    {
        int n = 0;
        foreach (var _ in e) n++;
        return n;
    }
}

/// <summary>Boolean → Opacity (true = 1, false = 0.45) for disabled-looking rows.</summary>
public sealed class BoolToOpacityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is true ? 1.0 : 0.45;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>Boolean → status brush (true = green "active", false = muted).</summary>
public sealed class BoolToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush Active = CheckStatusToBrushConverter.Frozen(0x35, 0xE0, 0x8A);
    private static readonly SolidColorBrush Inactive = CheckStatusToBrushConverter.Frozen(0x6B, 0x64, 0x85);

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is true ? Active : Inactive;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>Boolean "down" flag → DOWN / UP text for the live event list.</summary>
public sealed class DownToTextConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is true ? "DOWN" : "UP";

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>
/// Two-way string equality converter. Used to bind a set of radio buttons (chips) to a single
/// selected-string property: Convert returns true when the bound value equals the parameter,
/// ConvertBack writes the parameter back when the radio is checked.
/// </summary>
public sealed class StringEqualsConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => string.Equals(value?.ToString(), parameter?.ToString(), StringComparison.Ordinal);

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => value is true ? (parameter ?? Binding.DoNothing) : Binding.DoNothing;
}

using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class BugReportView : UserControl
{
    public BugReportView()
    {
        InitializeComponent();
        DataContext = new BugReportViewModel(App.Host);
    }
}

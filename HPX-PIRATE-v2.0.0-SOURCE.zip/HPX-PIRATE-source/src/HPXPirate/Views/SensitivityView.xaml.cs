﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class SensitivityView : UserControl
{
    private readonly SensitivityViewModel _vm;
    private bool _dragging;
    private Point _lastPoint;

    public SensitivityView()
    {
        InitializeComponent();
        _vm = new SensitivityViewModel(App.Host);
        DataContext = _vm;
    }

    private void TestPad_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _dragging = true;
        _lastPoint = e.GetPosition(TestPad);
        _vm.BeginTest("Drag");
        _vm.FeedTest(_lastPoint.X, _lastPoint.Y);
        TestPad.CaptureMouse();
    }

    private void TestPad_MouseMove(object sender, MouseEventArgs e)
    {
        if (!_dragging) return;
        var p = e.GetPosition(TestPad);
        // Feed every sample; the session computes honest statistics from real coordinates.
        if (Math.Abs(p.X - _lastPoint.X) + Math.Abs(p.Y - _lastPoint.Y) > 0.5)
        {
            _vm.FeedTest(p.X, p.Y);
            _lastPoint = p;
        }
    }

    private void TestPad_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (!_dragging) return;
        _dragging = false;
        TestPad.ReleaseMouseCapture();
        _vm.CompleteTest();
    }
}

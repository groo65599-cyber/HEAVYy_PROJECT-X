using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class OverlayStudioView : UserControl
{
    public OverlayStudioView()
    {
        InitializeComponent();
        DataContext = new OverlayStudioViewModel(App.Host);
    }
}

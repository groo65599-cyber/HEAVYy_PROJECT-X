using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class InputTesterView : UserControl
{
    public InputTesterView()
    {
        InitializeComponent();
        var vm = new InputTesterViewModel(App.Host);
        DataContext = vm;
        Unloaded += (_, _) => vm.Dispose();
    }
}

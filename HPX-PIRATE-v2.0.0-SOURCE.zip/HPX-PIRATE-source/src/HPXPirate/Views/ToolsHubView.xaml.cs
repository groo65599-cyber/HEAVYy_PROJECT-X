using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using HPXPirate.Models;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

/// <summary>
/// Toolbox hub. Every card opens a real, working tool view via the shell's Navigate() entry point.
/// </summary>
public partial class ToolsHubView : UserControl
{
    private readonly ToolsHubViewModel _vm;

    public ToolsHubView()
    {
        InitializeComponent();
        _vm = new ToolsHubViewModel(App.Host);
        DataContext = _vm;
        _vm.ToolActivated += OnToolActivated;
        Unloaded += (_, _) => _vm.ToolActivated -= OnToolActivated;
    }

    private void OnToolActivated(string viewKey)
    {
        if (Window.GetWindow(this) is MainWindow shell)
            shell.Navigate(viewKey);
    }

    private void ToolCard_Click(object sender, MouseButtonEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: ToolDefinition tool })
            _vm.OpenTool(tool);
    }
}

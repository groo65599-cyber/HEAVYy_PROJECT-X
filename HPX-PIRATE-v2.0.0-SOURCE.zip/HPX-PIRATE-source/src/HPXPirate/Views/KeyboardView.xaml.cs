﻿using System.Windows;
using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class KeyboardView : UserControl
{
    private readonly KeyboardViewModel _vm;

    public KeyboardView()
    {
        InitializeComponent();
        _vm = new KeyboardViewModel(App.Host);
        DataContext = _vm;
        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e) => _vm.Start();
    private void OnUnloaded(object sender, RoutedEventArgs e) => _vm.Stop();
}

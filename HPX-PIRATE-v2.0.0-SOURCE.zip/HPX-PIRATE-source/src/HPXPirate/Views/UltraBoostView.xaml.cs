using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class UltraBoostView : UserControl
{
    public UltraBoostView()
    {
        InitializeComponent();
        var vm = new UltraBoostViewModel(App.Host);
        DataContext = vm;
        Unloaded += (_, _) => vm.Dispose();
    }
}

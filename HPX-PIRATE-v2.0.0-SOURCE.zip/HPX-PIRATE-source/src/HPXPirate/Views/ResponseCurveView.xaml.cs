using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class ResponseCurveView : UserControl
{
    public ResponseCurveView()
    {
        InitializeComponent();
        DataContext = new ResponseCurveViewModel(App.Host);
    }
}

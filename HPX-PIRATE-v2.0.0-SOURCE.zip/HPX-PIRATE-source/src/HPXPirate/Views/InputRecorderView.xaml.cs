using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class InputRecorderView : UserControl
{
    public InputRecorderView()
    {
        InitializeComponent();
        var vm = new InputRecorderViewModel(App.Host);
        DataContext = vm;
        Unloaded += (_, _) => vm.Dispose();
    }
}

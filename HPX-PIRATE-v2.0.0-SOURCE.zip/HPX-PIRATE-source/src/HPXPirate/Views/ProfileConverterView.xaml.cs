using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class ProfileConverterView : UserControl
{
    public ProfileConverterView()
    {
        InitializeComponent();
        DataContext = new ProfileConverterViewModel(App.Host);
    }
}

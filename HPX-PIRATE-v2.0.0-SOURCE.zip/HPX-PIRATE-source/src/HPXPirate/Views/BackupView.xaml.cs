using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using HPXPirate.Models;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class BackupView : UserControl
{
    private readonly BackupViewModel _vm;

    public BackupView()
    {
        InitializeComponent();
        _vm = new BackupViewModel(App.Host);
        DataContext = _vm;
    }

    private void Row_Click(object sender, MouseButtonEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: BackupEntry entry })
            _vm.SelectedBackup = entry;
    }
}

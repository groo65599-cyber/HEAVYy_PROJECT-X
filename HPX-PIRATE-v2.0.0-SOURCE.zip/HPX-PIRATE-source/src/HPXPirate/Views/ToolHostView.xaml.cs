using System.Windows;
using System.Windows.Controls;

namespace HPXPirate.Views;

/// <summary>
/// Routes a toolbox selection to the matching tool view. Every branch resolves to a real,
/// service-backed UserControl; unknown keys fall back to an honest "not available" state
/// rather than a blank or fake page.
/// </summary>
public partial class ToolHostView : UserControl
{
    public ToolHostView(string key)
    {
        InitializeComponent();
        Host.Content = key switch
        {
            "tool.inputtester" => new InputTesterView(),
            "tool.latency" => new LatencyAnalyzerView(),
            "tool.calibration" => new CalibrationView(),
            "tool.recorder" => new InputRecorderView(),
            "tool.mappingtester" => new MappingTesterView(),
            "tool.profileconverter" => new ProfileConverterView(),
            "tool.sensitivitylab" => new SensitivityView(),
            "tool.responsecurve" => new ResponseCurveView(),
            "tool.frameanalyzer" => new FrameAnalyzerView(),
            "tool.backup" => new BackupView(),
            "tool.overlaystudio" => new OverlayStudioView(),
            _ => BuildUnavailable(key),
        };
    }

    private static UserControl BuildUnavailable(string key)
    {
        var panel = new StackPanel { Margin = new Thickness(24, 20, 24, 24) };
        panel.Children.Add(new TextBlock
        {
            Text = "NOT AVAILABLE ON THIS SYSTEM",
            FontSize = 22,
            FontWeight = FontWeights.Bold,
        });
        panel.Children.Add(new TextBlock
        {
            Text = $"The tool '{key}' is not available here. No simulated data will be shown.",
            Margin = new Thickness(0, 8, 0, 0),
            TextWrapping = TextWrapping.Wrap,
        });
        return new UserControl { Content = panel };
    }
}

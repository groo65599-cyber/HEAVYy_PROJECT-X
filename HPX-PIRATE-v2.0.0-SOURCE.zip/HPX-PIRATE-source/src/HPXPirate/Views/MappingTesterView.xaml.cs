using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class MappingTesterView : UserControl
{
    public MappingTesterView()
    {
        InitializeComponent();
        var vm = new MappingTesterViewModel(App.Host);
        DataContext = vm;
        Unloaded += (_, _) => vm.Dispose();
    }
}

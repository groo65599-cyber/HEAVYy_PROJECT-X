﻿using System.Windows;
using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class ControllerView : UserControl
{
    private readonly ControllerViewModel _vm;

    public ControllerView()
    {
        InitializeComponent();
        _vm = new ControllerViewModel(App.Host);
        DataContext = _vm;
        Loaded += (_, _) => _vm.Start();
        Unloaded += (_, _) => _vm.Stop();
    }
}

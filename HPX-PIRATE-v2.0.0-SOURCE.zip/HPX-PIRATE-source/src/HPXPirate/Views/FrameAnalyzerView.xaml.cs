using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class FrameAnalyzerView : UserControl
{
    public FrameAnalyzerView()
    {
        InitializeComponent();
        var vm = new FrameAnalyzerViewModel(App.Host);
        DataContext = vm;
        Unloaded += (_, _) => vm.Dispose();
    }
}

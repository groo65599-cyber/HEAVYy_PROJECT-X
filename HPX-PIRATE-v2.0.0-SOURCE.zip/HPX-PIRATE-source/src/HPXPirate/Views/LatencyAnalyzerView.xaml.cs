using System.Windows.Controls;
using HPXPirate.ViewModels;

namespace HPXPirate.Views;

public partial class LatencyAnalyzerView : UserControl
{
    public LatencyAnalyzerView()
    {
        InitializeComponent();
        var vm = new LatencyAnalyzerViewModel(App.Host);
        DataContext = vm;
        Unloaded += (_, _) => vm.Dispose();
    }
}

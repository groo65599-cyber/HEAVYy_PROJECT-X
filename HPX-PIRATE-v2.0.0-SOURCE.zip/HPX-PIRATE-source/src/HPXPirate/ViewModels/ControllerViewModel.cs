﻿using System.Collections.ObjectModel;
using System.Windows.Threading;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

/// <summary>
/// Live XInput controller view. If no XInput runtime can be loaded the page honestly reports
/// "NOT SUPPORTED ON THIS SYSTEM" instead of showing a dead panel.
/// </summary>
public sealed class ControllerViewModel : ViewModelBase
{
    private const double StickRadius = 44;

    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;

    private bool _isSupported;
    private bool _isConnected;
    private string _runtimeName = "Unavailable";
    private string _summary = "No controller connected.";
    private double _leftDotX = StickRadius;
    private double _leftDotY = StickRadius;
    private double _rightDotX = StickRadius;
    private double _rightDotY = StickRadius;
    private double _leftTrigger;
    private double _rightTrigger;
    private double _leftMagnitude;
    private double _rightMagnitude;
    private int _connectedIndex = -1;

    public ObservableCollection<string> PressedButtons { get; } = new();
    public ObservableCollection<ControllerProbe> Slots { get; } = new();

    public ControllerViewModel(AppHost host)
    {
        _host = host;
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(80) };
        _timer.Tick += (_, _) => Refresh();
        RefreshCommand = new RelayCommand(Refresh);
    }

    public bool IsSupported { get => _isSupported; private set { if (SetProperty(ref _isSupported, value)) OnPropertyChanged(nameof(SupportStatusText)); } }
    public bool IsConnected { get => _isConnected; private set { if (SetProperty(ref _isConnected, value)) OnPropertyChanged(nameof(ConnectionText)); } }
    public string RuntimeName { get => _runtimeName; private set { if (SetProperty(ref _runtimeName, value)) OnPropertyChanged(nameof(SupportStatusText)); } }
    public string Summary { get => _summary; private set => SetProperty(ref _summary, value); }
    public int ConnectedIndex { get => _connectedIndex; private set { if (SetProperty(ref _connectedIndex, value)) OnPropertyChanged(nameof(ConnectionText)); } }

    public string SupportStatusText => IsSupported ? $"SUPPORTED — {RuntimeName}" : "NOT SUPPORTED ON THIS SYSTEM";
    public string ConnectionText => IsConnected ? $"CONNECTED (slot {ConnectedIndex + 1})" : "NOT CONNECTED";

    public double LeftDotX { get => _leftDotX; private set => SetProperty(ref _leftDotX, value); }
    public double LeftDotY { get => _leftDotY; private set => SetProperty(ref _leftDotY, value); }
    public double RightDotX { get => _rightDotX; private set => SetProperty(ref _rightDotX, value); }
    public double RightDotY { get => _rightDotY; private set => SetProperty(ref _rightDotY, value); }

    public double LeftTrigger { get => _leftTrigger; private set => SetProperty(ref _leftTrigger, value); }
    public double RightTrigger { get => _rightTrigger; private set => SetProperty(ref _rightTrigger, value); }
    public double LeftMagnitude { get => _leftMagnitude; private set => SetProperty(ref _leftMagnitude, value); }
    public double RightMagnitude { get => _rightMagnitude; private set => SetProperty(ref _rightMagnitude, value); }

    public double CanvasSize => StickRadius * 2;

    public RelayCommand RefreshCommand { get; }

    public void Start()
    {
        _host.Controller.Probe();
        Refresh();
        _timer.Start();
    }

    public void Stop() => _timer.Stop();

    private void Refresh()
    {
        IsSupported = _host.Controller.IsSupported;
        RuntimeName = _host.Controller.RuntimeName;

        var state = _host.Controller.Read();
        IsConnected = state.Connected;
        ConnectedIndex = state.UserIndex;
        Summary = state.Summary;

        // Normalised thumb positions → pixel offsets inside a 2R canvas.
        double lx = Math.Clamp(state.LeftThumbX / 32767.0, -1, 1);
        double ly = Math.Clamp(state.LeftThumbY / 32767.0, -1, 1);
        double rx = Math.Clamp(state.RightThumbX / 32767.0, -1, 1);
        double ry = Math.Clamp(state.RightThumbY / 32767.0, -1, 1);

        LeftDotX = StickRadius + lx * StickRadius;
        LeftDotY = StickRadius - ly * StickRadius;
        RightDotX = StickRadius + rx * StickRadius;
        RightDotY = StickRadius - ry * StickRadius;

        LeftTrigger = state.LeftTriggerNormalized * 100;
        RightTrigger = state.RightTriggerNormalized * 100;
        LeftMagnitude = state.LeftThumbMagnitude * 100;
        RightMagnitude = state.RightThumbMagnitude * 100;

        PressedButtons.Clear();
        foreach (var b in state.PressedButtons) PressedButtons.Add(b);

        Slots.Clear();
        foreach (var s in _host.Controller.ProbeAll()) Slots.Add(s);
    }
}

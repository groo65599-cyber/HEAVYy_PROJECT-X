using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Input;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

/// <summary>
/// Drives the Diagnostics / Health Check page. Runs real checks, presents the verdict
/// (NO ISSUE DETECTED vs ISSUE DETECTED) and only offers auto-fix for findings that are
/// genuinely fixable. Never invents work.
/// </summary>
public sealed class DiagnosticsViewModel : ViewModelBase
{
    private readonly AppHost _host;
    private DiagnosticReport? _report;

    public DiagnosticsViewModel(AppHost host)
    {
        _host = host;
        RunCommand = new RelayCommand(Run);
        FixCommand = new RelayCommand(Fix, () => SelectedCheck is { CanAutoFix: true });
        ExportCommand = new RelayCommand(ExportBundle);
        Run();
    }

    public ObservableCollection<DiagnosticCheck> Checks { get; } = new();

    private DiagnosticCheck? _selectedCheck;
    public DiagnosticCheck? SelectedCheck
    {
        get => _selectedCheck;
        set { SetProperty(ref _selectedCheck, value); ((RelayCommand)FixCommand).RaiseCanExecuteChanged(); }
    }

    private string _status = "Ready.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public string Verdict => _report?.Verdict ?? "—";
    public string VerdictDetail => _report?.VerdictDetail ?? "Run a health check to begin.";
    public int HealthScore => _report?.HealthScore ?? 0;
    public string HealthLabel => _report?.HealthLabel ?? "—";
    public int OkCount => _report?.OkCount ?? 0;
    public int WarningCount => _report?.WarningCount ?? 0;
    public int ErrorCount => _report?.ErrorCount ?? 0;
    public int NotSupportedCount => _report?.NotSupportedCount ?? 0;
    public bool HasIssues => _report?.HasIssues ?? false;

    public ICommand RunCommand { get; }
    public ICommand FixCommand { get; }
    public ICommand ExportCommand { get; }

    private void Run()
    {
        try
        {
            _report = _host.Diagnostics.RunFullCheck();
            Checks.Clear();
            foreach (var c in _report.Checks.OrderBy(c => c.Status)) Checks.Add(c);

            OnPropertyChanged(nameof(Verdict));
            OnPropertyChanged(nameof(VerdictDetail));
            OnPropertyChanged(nameof(HealthScore));
            OnPropertyChanged(nameof(HealthLabel));
            OnPropertyChanged(nameof(OkCount));
            OnPropertyChanged(nameof(WarningCount));
            OnPropertyChanged(nameof(ErrorCount));
            OnPropertyChanged(nameof(NotSupportedCount));
            OnPropertyChanged(nameof(HasIssues));
            Status = $"Health check complete — {Verdict} ({HealthScore}/100).";
        }
        catch (Exception ex)
        {
            Status = "Health check failed: " + ex.Message;
        }
    }

    private void Fix()
    {
        if (SelectedCheck is not { CanAutoFix: true } check) return;
        try
        {
            switch (check.FixActionId)
            {
                case "input.reinstall_hooks":
                    _host.Input.StartHooks();
                    Status = "Input hooks reinstalled. Re-running the check…";
                    break;
                case "config.clamp":
                    ClampConfiguration();
                    Status = "Out-of-range settings clamped to valid values. Re-running the check…";
                    break;
                default:
                    Status = "This finding has no automatic fix. Follow the recommended action.";
                    return;
            }
            Run();
        }
        catch (Exception ex)
        {
            Status = "Fix failed: " + ex.Message;
        }
    }

    private void ClampConfiguration()
    {
        var s = _host.AppSettings;
        if (s.MonitoringIntervalMs < 100) s.MonitoringIntervalMs = 1000;
        if (s.IdleMonitoringIntervalMs < 100) s.IdleMonitoringIntervalMs = 2000;
        if (s.Mouse.HorizontalSensitivity <= 0) s.Mouse.HorizontalSensitivity = 1.0;
        if (s.Mouse.VerticalSensitivity <= 0) s.Mouse.VerticalSensitivity = 1.0;
        _host.Settings.Save();
    }

    private void ExportBundle()
    {
        try
        {
            var report = _host.BugReport.Create(
                "Diagnostics export",
                "Diagnostic report exported from the Diagnostics page.",
                "Diagnostics");
            var path = Path.Combine(AppPaths.Root, $"diagnostics_{DateTime.Now:yyyyMMdd_HHmmss}.zip");
            if (_host.BugReport.ExportBundle(report, path, out var msg))
                Status = "Diagnostic bundle saved to " + path;
            else
                Status = "Export failed: " + msg;
        }
        catch (Exception ex)
        {
            Status = "Export failed: " + ex.Message;
        }
    }
}

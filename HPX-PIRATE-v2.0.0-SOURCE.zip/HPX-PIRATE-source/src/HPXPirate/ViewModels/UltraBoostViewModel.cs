using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Threading;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

/// <summary>
/// ULTRA FPS BOOST ENGINE.
///
/// Flow: DETECT → BASELINE → ANALYZE → IDENTIFY BOTTLENECK → CREATE PLAN → SHOW CHANGES →
/// APPLY → MEASURE → COMPARE → VERIFY → KEEP OR ROLLBACK.
///
/// Every number shown comes from a real measurement. If a measurement cannot be taken the UI
/// says so ("NO DATA") instead of inventing a value. If a change does not measurably help it is
/// rolled back automatically so the user's configuration is preserved.
/// </summary>
public sealed class UltraBoostViewModel : ViewModelBase, IDisposable
{
    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;

    public UltraBoostViewModel(AppHost host)
    {
        _host = host;

        DetectCommand = new RelayCommand(Detect);
        BaselineCommand = new RelayCommand(StartBaseline, () => !_host.FpsBoost.IsMeasuring);
        AnalyzeCommand = new RelayCommand(Analyze, () => Baseline is not null);
        ApplyCommand = new RelayCommand(Apply, () => Plan is not null);
        MeasureCommand = new RelayCommand(StartAfter, () => Plan is not null && !_host.FpsBoost.IsMeasuring);
        CompareCommand = new RelayCommand(Compare, () => Baseline is not null && After is not null);
        VerifyCommand = new RelayCommand(Verify, () => Comparison?.HasBoth == true);
        ResetCommand = new RelayCommand(Reset);
        CancelCommand = new RelayCommand(Cancel, () => _host.FpsBoost.IsMeasuring);

        _host.FpsBoost.MeasurementCompleted += OnMeasured;
        _host.FpsBoost.Attach();

        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
        _timer.Tick += (_, _) => RefreshPhase();
        _timer.Start();

        Detect();
    }

    // ---- Configuration ----
    public BoostMode[] Modes { get; } = (BoostMode[])Enum.GetValues(typeof(BoostMode));

    private BoostMode _selectedMode = BoostMode.HighFps;
    public BoostMode SelectedMode
    {
        get => _selectedMode;
        set { if (SetProperty(ref _selectedMode, value)) RefreshTarget(); }
    }

    private int _customTarget;
    public int CustomTarget
    {
        get => _customTarget;
        set { if (SetProperty(ref _customTarget, value)) RefreshTarget(); }
    }

    public bool IsCustomMode => SelectedMode == BoostMode.Custom;

    // ---- DETECT ----
    private DisplayInfo _display = new();
    public string DisplaySummary => _display.Summary;
    public string RefreshText => _display.Available ? $"{_display.CurrentRefreshHz} Hz (max {_display.MaxRefreshHz} Hz)" : "NOT AVAILABLE";

    private HardwareCapability _hardware = new();
    public string HardwareSummary => _hardware.CpuAvailable || _hardware.GpuAvailable
        ? $"{_hardware.CpuName} · {_hardware.GpuName} · {_hardware.RamTotalGb:0.#} GB RAM"
        : "HARDWARE DATA NOT AVAILABLE";

    // ---- Target ----
    private int _targetFps;
    public string TargetText => _targetFps > 0 ? $"{_targetFps} FPS" : "—";

    private string _targetNote = "";
    public string TargetNote { get => _targetNote; private set => SetProperty(ref _targetNote, value); }

    // ---- BASELINE / AFTER ----
    public PerformanceSample? Baseline { get; private set; }
    public PerformanceSample? After { get; private set; }

    public string BaselineText => Baseline?.HasData == true
        ? $"{Baseline.AverageFps:0} FPS · {Baseline.FrameTimeMs:0.0} ms · {Baseline.StabilityLabel}"
        : "NO DATA";
    public string AfterText => After?.HasData == true
        ? $"{After.AverageFps:0} FPS · {After.FrameTimeMs:0.0} ms · {After.StabilityLabel}"
        : "NO DATA";

    // ---- ANALYZE ----
    private string _bottleneckText = "Not analysed yet.";
    public string BottleneckText { get => _bottleneckText; private set => SetProperty(ref _bottleneckText, value); }

    public ObservableCollection<string> Findings { get; } = new();
    public ObservableCollection<string> Recommendations { get; } = new();

    // ---- PLAN ----
    private BoostPlan? _plan;
    public BoostPlan? Plan { get => _plan; private set => SetProperty(ref _plan, value); }
    public ObservableCollection<BoostPlanItem> PlanItems { get; } = new();

    public string PlanSummary => Plan is null
        ? "No plan yet — run a baseline, then analyse."
        : $"{Plan.Items.Count} change(s) proposed · readiness {Plan.ReadinessScore}% ({Plan.ReadinessLabel})";
    public string ReadinessLabel => Plan?.ReadinessLabel ?? "";

    // ---- APPLY ----
    private string _applySummary = "";
    public string ApplySummary { get => _applySummary; private set => SetProperty(ref _applySummary, value); }

    // ---- COMPARE / VERIFY ----
    private BoostComparison? _comparison;
    public BoostComparison? Comparison { get => _comparison; private set => SetProperty(ref _comparison, value); }

    public string ComparisonVerdict => Comparison?.Verdict ?? "MEASUREMENT INCOMPLETE";
    public string ComparisonRecommendation => Comparison?.Recommendation ?? "Run both a baseline and a post-boost measurement.";
    public string FpsDeltaText => Comparison?.HasBoth == true ? $"{Comparison.FpsDelta:+0.0;-0.0;0.0} FPS" : "—";

    private string _verifyResult = "";
    public string VerifyResult { get => _verifyResult; private set => SetProperty(ref _verifyResult, value); }

    // ---- Phase ----
    public bool IsMeasuring => _host.FpsBoost.IsMeasuring;
    public string PhaseLabel => _host.FpsBoost.Phase switch
    {
        MeasurementPhase.Baseline => "MEASURING BASELINE",
        MeasurementPhase.After => "MEASURING AFTER",
        _ => "IDLE",
    };
    public double ProgressPercent => _host.FpsBoost.Progress * 100;
    public string ProgressText => $"{ProgressPercent:0}%";

    private string _status = "Step 1 — detect your display and hardware, then record a baseline.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand DetectCommand { get; }
    public RelayCommand BaselineCommand { get; }
    public RelayCommand AnalyzeCommand { get; }
    public RelayCommand ApplyCommand { get; }
    public RelayCommand MeasureCommand { get; }
    public RelayCommand CompareCommand { get; }
    public RelayCommand VerifyCommand { get; }
    public RelayCommand ResetCommand { get; }
    public RelayCommand CancelCommand { get; }

    // ------------------------------------------------------------------
    private void Detect()
    {
        _display = _host.FpsBoost.DetectDisplay();
        _hardware = _host.FpsBoost.DetectHardware();
        OnPropertyChanged(nameof(DisplaySummary));
        OnPropertyChanged(nameof(RefreshText));
        OnPropertyChanged(nameof(HardwareSummary));
        RefreshTarget();
        Status = _display.Available
            ? "Display detected. Step 2 — record a baseline for 10 seconds while playing."
            : "Display data not available on this system; boost will rely on measured FPS only.";
    }

    private void RefreshTarget()
    {
        _targetFps = _host.FpsBoost.ResolveTarget(SelectedMode, _display, CustomTarget);
        _targetNote = _targetFps > 0
            ? $"Target {_targetFps} FPS for mode '{SelectedMode}'."
            : "Target could not be resolved.";
        OnPropertyChanged(nameof(TargetText));
        OnPropertyChanged(nameof(TargetNote));
        OnPropertyChanged(nameof(IsCustomMode));
    }

    private void StartBaseline()
    {
        _host.FpsBoost.StartBaseline(10);
        Status = "Recording baseline for 10 seconds — play as you normally would.";
        RefreshPhase();
    }

    private void StartAfter()
    {
        _host.FpsBoost.StartAfter(10);
        Status = "Recording post-boost measurement for 10 seconds.";
        RefreshPhase();
    }

    private void OnMeasured(PerformanceSample sample)
    {
        Application.Current?.Dispatcher.Invoke(() =>
        {
            if (sample.Label == "Baseline") Baseline = sample; else After = sample;
            OnPropertyChanged(nameof(Baseline));
            OnPropertyChanged(nameof(After));
            OnPropertyChanged(nameof(BaselineText));
            OnPropertyChanged(nameof(AfterText));
            RefreshPhase();
        });
    }

    private void Analyze()
    {
        var bottleneck = _host.FpsBoost.IdentifyBottleneck(Baseline, _display, out var detail);
        BottleneckText = bottleneck == BottleneckKind.NotEnoughData
            ? "NOT ENOUGH DATA — record a longer baseline."
            : $"{bottleneck}: {detail}";

        Plan = _host.FpsBoost.BuildPlan(SelectedMode, Baseline, CustomTarget);
        PlanItems.Clear();
        foreach (var item in Plan.Items) PlanItems.Add(item);

        Findings.Clear();
        foreach (var f in Plan.Findings) Findings.Add(f);
        Recommendations.Clear();
        foreach (var r in Plan.Recommendations) Recommendations.Add(r);

        OnPropertyChanged(nameof(Plan));
        OnPropertyChanged(nameof(PlanSummary));
        OnPropertyChanged(nameof(ReadinessLabel));
        Status = Plan.Items.Count == 0
            ? "NO ISSUE DETECTED — your configuration will be preserved."
            : $"{Plan.Items.Count} change(s) proposed. Review them, then apply.";
    }

    private void Apply()
    {
        if (Plan is null) return;
        var result = _host.FpsBoost.ApplyPlan(Plan, createRestorePoint: true);
        ApplySummary = result.Summary + (result.RestorePointId is not null ? " (restore point created)" : "");
        OnPropertyChanged(nameof(ApplySummary));
        Status = "Changes applied. Step — measure again for 10 seconds to verify the result.";
    }

    private void Compare()
    {
        Comparison = _host.FpsBoost.Compare(Baseline, After);
        OnPropertyChanged(nameof(Comparison));
        OnPropertyChanged(nameof(ComparisonVerdict));
        OnPropertyChanged(nameof(ComparisonRecommendation));
        OnPropertyChanged(nameof(FpsDeltaText));
        Status = "Comparison ready. Run verify to keep or roll back automatically.";
    }

    private void Verify()
    {
        if (Comparison is null) return;
        VerifyResult = _host.FpsBoost.VerifyAndKeepOrRollback(Comparison);
        OnPropertyChanged(nameof(VerifyResult));
        Status = VerifyResult;
    }

    private void Cancel()
    {
        _host.FpsBoost.CancelMeasurement();
        Status = "Measurement cancelled.";
        RefreshPhase();
    }

    private void Reset()
    {
        _host.FpsBoost.CancelMeasurement();
        Baseline = null;
        After = null;
        Plan = null;
        Comparison = null;
        PlanItems.Clear();
        Findings.Clear();
        Recommendations.Clear();
        ApplySummary = "";
        VerifyResult = "";
        BottleneckText = "Not analysed yet.";
        Status = "Reset. Record a fresh baseline to start again.";
        OnPropertyChanged(nameof(Baseline));
        OnPropertyChanged(nameof(After));
        OnPropertyChanged(nameof(BaselineText));
        OnPropertyChanged(nameof(AfterText));
        OnPropertyChanged(nameof(Plan));
        OnPropertyChanged(nameof(PlanSummary));
        OnPropertyChanged(nameof(ApplySummary));
        OnPropertyChanged(nameof(Comparison));
        OnPropertyChanged(nameof(ComparisonVerdict));
        OnPropertyChanged(nameof(ComparisonRecommendation));
        OnPropertyChanged(nameof(FpsDeltaText));
        OnPropertyChanged(nameof(VerifyResult));
        RefreshPhase();
    }

    private void RefreshPhase()
    {
        OnPropertyChanged(nameof(IsMeasuring));
        OnPropertyChanged(nameof(PhaseLabel));
        OnPropertyChanged(nameof(ProgressPercent));
        OnPropertyChanged(nameof(ProgressText));
        ((RelayCommand)BaselineCommand).RaiseCanExecuteChanged();
        ((RelayCommand)AnalyzeCommand).RaiseCanExecuteChanged();
        ((RelayCommand)ApplyCommand).RaiseCanExecuteChanged();
        ((RelayCommand)MeasureCommand).RaiseCanExecuteChanged();
        ((RelayCommand)CompareCommand).RaiseCanExecuteChanged();
        ((RelayCommand)VerifyCommand).RaiseCanExecuteChanged();
        ((RelayCommand)CancelCommand).RaiseCanExecuteChanged();
    }

    public void Dispose()
    {
        _timer.Stop();
        _host.FpsBoost.MeasurementCompleted -= OnMeasured;
    }
}

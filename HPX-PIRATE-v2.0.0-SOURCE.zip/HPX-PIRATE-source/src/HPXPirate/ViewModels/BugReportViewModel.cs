using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

/// <summary>
/// Bug report builder. Gathers real environment + diagnostic context so the user can attach a
/// complete bundle. Nothing is sent anywhere automatically.
/// </summary>
public sealed class BugReportViewModel : ViewModelBase
{
    private readonly AppHost _host;

    public BugReportViewModel(AppHost host)
    {
        _host = host;
        CreateCommand = new RelayCommand(Create, () => !string.IsNullOrWhiteSpace(Title));
        ExportCommand = new RelayCommand(Export, () => Report is not null);
        CopyCommand = new RelayCommand(Copy, () => Report is not null);
        ClearCommand = new RelayCommand(Clear);
    }

    public string[] Categories { get; } =
        { "General", "Performance", "Input", "Mapping", "Overlay", "Crash", "UI", "Other" };

    private string _title = "";
    public string Title { get => _title; set { if (SetProperty(ref _title, value)) ((RelayCommand)CreateCommand).RaiseCanExecuteChanged(); } }

    private string _description = "";
    public string Description { get => _description; set => SetProperty(ref _description, value); }

    private string _category = "General";
    public string Category { get => _category; set => SetProperty(ref _category, value); }

    private string _email = "";
    public string Email { get => _email; set => SetProperty(ref _email, value); }

    private BugReport? _report;
    public BugReport? Report
    {
        get => _report;
        private set
        {
            if (SetProperty(ref _report, value))
            {
                ((RelayCommand)ExportCommand).RaiseCanExecuteChanged();
                ((RelayCommand)CopyCommand).RaiseCanExecuteChanged();
                OnPropertyChanged(nameof(HasReport));
                OnPropertyChanged(nameof(ReportSummary));
                OnPropertyChanged(nameof(EnvironmentText));
                OnPropertyChanged(nameof(DiagnosticText));
            }
        }
    }

    public bool HasReport => Report is not null;
    public string ReportSummary => Report?.Summary ?? "No report generated yet.";
    public string EnvironmentText => Report is null ? "" :
        $"App {Report.AppVersion} · {Report.Platform} · .NET {Report.DotNetVersion}\n{Report.OsVersion}\n{Report.HardwareSummary}";
    public string DiagnosticText => Report is null ? "" :
        $"Verdict: {Report.DiagnosticVerdict} · Health {Report.HealthScore}/100 · {Report.Checks.Count} check(s)";

    public ObservableCollection<DiagnosticCheck> Checks { get; } = new();
    public ObservableCollection<string> LogLines { get; } = new();

    private string _status = "Describe the problem, then generate a report bundle to attach.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand CreateCommand { get; }
    public RelayCommand ExportCommand { get; }
    public RelayCommand CopyCommand { get; }
    public RelayCommand ClearCommand { get; }

    private void Create()
    {
        try
        {
            Report = _host.BugReport.Create(Title, Description, Category, Email);
            Checks.Clear();
            foreach (var c in Report.Checks) Checks.Add(c);
            LogLines.Clear();
            foreach (var l in Report.LogLines) LogLines.Add(l);
            Status = $"Report {Report.Id} generated with {Report.Checks.Count} diagnostic check(s) and {Report.LogLines.Count} log line(s).";
        }
        catch (Exception ex)
        {
            Status = "Could not generate report: " + ex.Message;
        }
    }

    private void Export()
    {
        if (Report is null) return;
        try
        {
            AppPaths.EnsureCreated();
            var path = Path.Combine(AppPaths.Root, $"bugreport_{Report.Id}.zip");
            Status = _host.BugReport.ExportBundle(Report, path, out var msg)
                ? "Bundle exported to " + path
                : "Export failed: " + msg;
        }
        catch (Exception ex)
        {
            Status = "Export failed: " + ex.Message;
        }
    }

    private void Copy()
    {
        if (Report is null) return;
        try
        {
            Clipboard.SetText(_host.BugReport.BuildText(Report));
            Status = "Report text copied to clipboard.";
        }
        catch (Exception ex)
        {
            Status = "Copy failed: " + ex.Message;
        }
    }

    private void Clear()
    {
        Title = "";
        Description = "";
        Category = "General";
        Email = "";
        Report = null;
        Checks.Clear();
        LogLines.Clear();
        Status = "Cleared. Describe the problem, then generate a report bundle to attach.";
    }
}

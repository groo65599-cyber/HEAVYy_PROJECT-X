using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

// =====================================================================
//  HPX PIRATE Toolbox — view models.
//  Every tool below is backed by a real service. Nothing is fabricated:
//  when a measurement has no data it reports "NO DATA" instead of a fake
//  number, and unsupported capabilities are reported honestly.
// =====================================================================

/// <summary>Live input tester: shows the real event stream and key states.</summary>
public sealed class InputTesterViewModel : ViewModelBase, IDisposable
{
    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;

    public InputTesterViewModel(AppHost host)
    {
        _host = host;
        ClearCommand = new RelayCommand(Clear);
        ToggleCommand = new RelayCommand(Toggle);
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        _timer.Tick += (_, _) => Refresh();
        _host.InputTest.Start();
        _timer.Start();
        Refresh();
    }

    public ObservableCollection<InputEventRecord> Events { get; } = new();
    public ObservableCollection<KeyStateModel> KeyStates { get; } = new();

    public string[] Filters { get; } = { "All", "Keyboard", "Mouse" };
    private string _selectedFilter = "All";
    public string SelectedFilter { get => _selectedFilter; set { if (SetProperty(ref _selectedFilter, value)) Refresh(); } }

    public string HooksStatus => _host.Input.HooksActive ? "HOOKS ACTIVE" : "HOOKS INACTIVE";
    public bool HooksActive => _host.Input.HooksActive;
    public string ListenStatus => _host.InputTest.IsListening ? "LISTENING" : "STOPPED";
    public bool IsListening => _host.InputTest.IsListening;
    public string ListenButtonText => _host.InputTest.IsListening ? "Stop monitoring" : "Start monitoring";

    public string PollingRateText
    {
        get
        {
            var hz = _host.InputTest.EstimatedPollingRateHz;
            return hz > 0 ? $"{hz:0} Hz" : "NO DATA";
        }
    }

    private string _status = "";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand ClearCommand { get; }
    public RelayCommand ToggleCommand { get; }

    private void Toggle()
    {
        if (_host.InputTest.IsListening) _host.InputTest.Stop(); else _host.InputTest.Start();
        Refresh();
    }

    private void Clear()
    {
        _host.InputTest.Clear();
        Refresh();
        Status = "Event buffer cleared.";
    }

    private void Refresh()
    {
        var all = _host.InputTest.Recent;
        var filtered = (SelectedFilter switch
        {
            "Keyboard" => all.Where(e => e.Device == InputDeviceKind.Keyboard),
            "Mouse" => all.Where(e => e.Device == InputDeviceKind.Mouse),
            _ => all
        }).Reverse().Take(80);

        Events.Clear();
        foreach (var e in filtered) Events.Add(e);

        KeyStates.Clear();
        foreach (var k in _host.InputTest.KeyStates) KeyStates.Add(k);

        OnPropertyChanged(nameof(PollingRateText));
        OnPropertyChanged(nameof(HooksStatus));
        OnPropertyChanged(nameof(HooksActive));
        OnPropertyChanged(nameof(ListenStatus));
        OnPropertyChanged(nameof(IsListening));
        OnPropertyChanged(nameof(ListenButtonText));
        Status = $"{all.Count} event(s) captured.";
    }

    public void Dispose()
    {
        _timer.Stop();
        _host.InputTest.Stop();
    }
}

/// <summary>Latency analyser: stimulus-to-input response latency with real statistics.</summary>
public sealed class LatencyAnalyzerViewModel : ViewModelBase, IDisposable
{
    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;

    public LatencyAnalyzerViewModel(AppHost host)
    {
        _host = host;
        StimulusCommand = new RelayCommand(() =>
        {
            _host.InputTest.MarkStimulus("stimulus");
            Status = "Stimulus shown. Press a key or click to close the loop.";
        });
        ResetCommand = new RelayCommand(() =>
        {
            _host.InputTest.Clear();
            Refresh();
            Status = "Latency samples cleared.";
        });
        _host.InputTest.Start();
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(300) };
        _timer.Tick += (_, _) => Refresh();
        _timer.Start();
        Refresh();
    }

    public LatencyStats Stats => _host.InputTest.ResponseLatency;

    public bool HasData => Stats.HasData;
    public string AverageText => HasData ? $"{Stats.Average:0.0} ms" : "NO DATA";
    public string MinimumText => HasData ? $"{Stats.Minimum:0.0} ms" : "—";
    public string MaximumText => HasData ? $"{Stats.Maximum:0.0} ms" : "—";
    public string P95Text => HasData ? $"{Stats.P95:0.0} ms" : "—";
    public string StdDevText => HasData ? $"{Stats.StdDev:0.0} ms" : "—";
    public int Samples => Stats.Samples.Count;

    public string Verdict
    {
        get
        {
            if (!HasData) return "NO DATA — run a stimulus test.";
            var a = Stats.Average;
            return a <= 60 ? "EXCELLENT (includes human reaction time)"
                : a <= 120 ? "GOOD"
                : a <= 220 ? "AVERAGE"
                : "HIGH — check display latency / polling rate";
        }
    }

    private string _status = "Press 'Show stimulus', then react with any key or mouse click.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand StimulusCommand { get; }
    public RelayCommand ResetCommand { get; }

    private void Refresh()
    {
        OnPropertyChanged(nameof(HasData));
        OnPropertyChanged(nameof(AverageText));
        OnPropertyChanged(nameof(MinimumText));
        OnPropertyChanged(nameof(MaximumText));
        OnPropertyChanged(nameof(P95Text));
        OnPropertyChanged(nameof(StdDevText));
        OnPropertyChanged(nameof(Samples));
        OnPropertyChanged(nameof(Verdict));
    }

    public void Dispose()
    {
        _timer.Stop();
        _host.InputTest.Stop();
    }
}

/// <summary>Calibration: reads real display + input capability and reports a calibration summary.</summary>
public sealed class CalibrationViewModel : ViewModelBase, IDisposable
{
    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;
    private DisplayInfo _display = new();

    public CalibrationViewModel(AppHost host)
    {
        _host = host;
        RunCommand = new RelayCommand(Run);
        ApplyCommand = new RelayCommand(Apply, () => CanApply);
        _host.InputTest.Start();
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
        _timer.Tick += (_, _) => RefreshPolling();
        _timer.Start();
        Run();
    }

    public string DisplaySummary => _display.Summary;
    public string RefreshText => _display.Available ? $"{_display.CurrentRefreshHz} Hz" : "NOT AVAILABLE";
    public string MaxRefreshText => _display.Available ? $"{_display.MaxRefreshHz} Hz" : "NOT AVAILABLE";
    public string ResolutionText => _display.Available ? $"{_display.Width} x {_display.Height}" : "NOT AVAILABLE";
    public string VrrText => _display.Available ? (_display.VrrSupported ? "SUPPORTED" : "NOT DETECTED") : "NOT AVAILABLE";

    public string PollingRateText
    {
        get
        {
            var hz = _host.InputTest.EstimatedPollingRateHz;
            return hz > 0 ? $"{hz:0} Hz" : "NO DATA (move the mouse)";
        }
    }

    public bool CanApply => _display.Available && _display.MaxRefreshHz > _display.CurrentRefreshHz;

    private string _status = "";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand RunCommand { get; }
    public RelayCommand ApplyCommand { get; }

    private void Run()
    {
        _display = _host.Display.GetDisplayInfo(forceRefresh: true);
        OnPropertyChanged(nameof(DisplaySummary));
        OnPropertyChanged(nameof(RefreshText));
        OnPropertyChanged(nameof(MaxRefreshText));
        OnPropertyChanged(nameof(ResolutionText));
        OnPropertyChanged(nameof(VrrText));
        OnPropertyChanged(nameof(CanApply));
        Status = _display.Available
            ? (CanApply
                ? $"Your panel supports {_display.MaxRefreshHz} Hz but Windows is at {_display.CurrentRefreshHz} Hz. Raising it is recommended."
                : "Display is already configured at its maximum refresh rate.")
            : "Display data is not available on this system.";
    }

    private void RefreshPolling() => OnPropertyChanged(nameof(PollingRateText));

    private void Apply()
    {
        // Honest behaviour: we do not silently change the display mode. We guide the user to the
        // Windows setting, because forcing a mode from here could black-screen a monitor.
        Status = "Open Windows Settings → System → Display → Advanced display and pick the highest refresh rate.";
    }

    public void Dispose()
    {
        _timer.Stop();
        _host.InputTest.Stop();
    }
}

/// <summary>Input recorder: captures a real input session and exports it as CSV.</summary>
public sealed class InputRecorderViewModel : ViewModelBase, IDisposable
{
    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;
    private bool _recording;
    private double _startMs;

    public InputRecorderViewModel(AppHost host)
    {
        _host = host;
        StartCommand = new RelayCommand(Start, () => !_recording);
        StopCommand = new RelayCommand(Stop, () => _recording);
        ExportCommand = new RelayCommand(Export, () => Captured.Count > 0);
        _host.InputTest.Start();
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        _timer.Tick += (_, _) => Refresh();
        _timer.Start();
    }

    public ObservableCollection<InputEventRecord> Captured { get; } = new();

    public bool IsRecording => _recording;
    public string RecordButtonText => _recording ? "Recording…" : "Start recording";
    public string CountText => $"{Captured.Count} event(s)";
    public string DurationText
    {
        get
        {
            if (Captured.Count == 0) return "0.0 s";
            var span = (Captured[^1].TimeMs - Captured[0].TimeMs) / 1000.0;
            return $"{span:0.0} s";
        }
    }

    private string _status = "Press 'Start recording', then use your keyboard and mouse.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand StartCommand { get; }
    public RelayCommand StopCommand { get; }
    public RelayCommand ExportCommand { get; }

    private void Start()
    {
        _host.InputTest.Clear();
        _startMs = InputTestService.NowMs;
        _recording = true;
        RaiseState();
        Status = "Recording input…";
    }

    private void Stop()
    {
        _recording = false;
        RaiseState();
        Status = $"Recording stopped — {Captured.Count} event(s) captured.";
    }

    private void Refresh()
    {
        if (!_recording) return;
        var recent = _host.InputTest.Recent.Where(e => e.TimeMs >= _startMs).ToList();
        Captured.Clear();
        foreach (var e in recent) Captured.Add(e);
        OnPropertyChanged(nameof(CountText));
        OnPropertyChanged(nameof(DurationText));
    }

    private void Export()
    {
        try
        {
            AppPaths.EnsureCreated();
            var path = Path.Combine(AppPaths.Root, $"input_recording_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
            using var w = new StreamWriter(path);
            w.WriteLine("time_ms,device,name,down,detail");
            foreach (var e in Captured)
                w.WriteLine($"{e.TimeMs:0.000},{e.Device},{e.Name},{(e.Down ? 1 : 0)},\"{e.Detail}\"");
            Status = "Recording exported to " + path;
        }
        catch (Exception ex)
        {
            Status = "Export failed: " + ex.Message;
        }
    }

    private void RaiseState()
    {
        OnPropertyChanged(nameof(IsRecording));
        OnPropertyChanged(nameof(RecordButtonText));
        ((RelayCommand)StartCommand).RaiseCanExecuteChanged();
        ((RelayCommand)StopCommand).RaiseCanExecuteChanged();
        ((RelayCommand)ExportCommand).RaiseCanExecuteChanged();
    }

    public void Dispose()
    {
        _timer.Stop();
        _host.InputTest.Stop();
    }
}

/// <summary>Mapping tester: shows the active profile's mappings and confirms live key presses.</summary>
public sealed class MappingTesterViewModel : ViewModelBase, IDisposable
{
    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;

    public MappingTesterViewModel(AppHost host)
    {
        _host = host;
        RefreshCommand = new RelayCommand(RefreshProfiles);
        _host.InputTest.Start();
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
        _timer.Tick += (_, _) => RefreshLive();
        _timer.Start();
        RefreshProfiles();
    }

    public ObservableCollection<GameProfile> Profiles { get; } = new();
    public ObservableCollection<ControlMapping> Mappings { get; } = new();

    private GameProfile? _selectedProfile;
    public GameProfile? SelectedProfile
    {
        get => _selectedProfile;
        set { if (SetProperty(ref _selectedProfile, value)) RefreshMappings(); }
    }

    public string[] Inputs { get; } = { "All", "Keyboard", "Mouse" };
    private string _filter = "All";
    public string Filter { get => _filter; set { if (SetProperty(ref _filter, value)) RefreshMappings(); } }

    public string LiveKey { get; private set; } = "—";
    public string LiveAction { get; private set; } = "Press any mapped key to test.";

    private string _status = "";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand RefreshCommand { get; }

    private void RefreshProfiles()
    {
        Profiles.Clear();
        foreach (var p in _host.Profiles.Profiles) Profiles.Add(p);
        SelectedProfile ??= Profiles.FirstOrDefault();
        if (SelectedProfile is null) Status = "No profiles yet — create one on the Game Profiles page.";
    }

    private void RefreshMappings()
    {
        Mappings.Clear();
        if (SelectedProfile is null) return;
        var list = SelectedProfile.KeyboardMapping.Concat(SelectedProfile.MouseMapping);
        var filtered = Filter switch
        {
            "Keyboard" => list.Where(m => m.InputType == MappingInputType.Keyboard),
            "Mouse" => list.Where(m => m.InputType != MappingInputType.Keyboard),
            _ => list
        };
        foreach (var m in filtered) Mappings.Add(m);
        Status = $"{Mappings.Count} mapping(s) in '{SelectedProfile.Game}'.";
    }

    private void RefreshLive()
    {
        var states = _host.InputTest.KeyStates;
        var pressed = states.FirstOrDefault(k => k.Pressed);
        if (pressed is null) return;
        LiveKey = pressed.Key;
        var match = Mappings.FirstOrDefault(m => string.Equals(m.Input, pressed.Key, StringComparison.OrdinalIgnoreCase));
        LiveAction = match is not null ? $"→ {match.Action} (matched)" : "→ no mapping for this key";
        OnPropertyChanged(nameof(LiveKey));
        OnPropertyChanged(nameof(LiveAction));
    }

    public void Dispose()
    {
        _timer.Stop();
        _host.InputTest.Stop();
    }
}

/// <summary>Profile converter: export/import profiles between HPX and portable JSON.</summary>
public sealed class ProfileConverterViewModel : ViewModelBase
{
    private readonly AppHost _host;

    public ProfileConverterViewModel(AppHost host)
    {
        _host = host;
        ExportCommand = new RelayCommand(Export, () => SelectedProfile is not null);
        ImportCommand = new RelayCommand(Import);
        RefreshCommand = new RelayCommand(Refresh);
        Refresh();
    }

    public ObservableCollection<GameProfile> Profiles { get; } = new();

    private GameProfile? _selectedProfile;
    public GameProfile? SelectedProfile
    {
        get => _selectedProfile;
        set { if (SetProperty(ref _selectedProfile, value)) ((RelayCommand)ExportCommand).RaiseCanExecuteChanged(); }
    }

    private string _status = "Select a profile to export, or import a portable .json profile.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand ExportCommand { get; }
    public RelayCommand ImportCommand { get; }
    public RelayCommand RefreshCommand { get; }

    private void Refresh()
    {
        Profiles.Clear();
        foreach (var p in _host.Profiles.Profiles) Profiles.Add(p);
        Status = $"{Profiles.Count} profile(s) available.";
    }

    private void Export()
    {
        if (SelectedProfile is null) return;
        try
        {
            var path = Path.Combine(AppPaths.Root, $"{SelectedProfile.Game}_profile.json");
            _host.Profiles.Export(SelectedProfile, path);
            Status = "Exported to " + path;
        }
        catch (Exception ex) { Status = "Export failed: " + ex.Message; }
    }

    private void Import()
    {
        // Import the most recent exported profile in the app folder (no file dialog dependency).
        try
        {
            var file = new DirectoryInfo(AppPaths.Root)
                .GetFiles("*_profile.json")
                .OrderByDescending(f => f.LastWriteTime)
                .FirstOrDefault();
            if (file is null) { Status = "No exported profile found to import."; return; }
            var p = _host.Profiles.Import(file.FullName);
            Refresh();
            Status = $"Imported '{p.Game}' from {file.Name}.";
        }
        catch (Exception ex) { Status = "Import failed: " + ex.Message; }
    }
}

/// <summary>Response curve tool: visualises and applies a real response curve.</summary>
public sealed class ResponseCurveViewModel : ViewModelBase
{
    private readonly AppHost _host;

    public ResponseCurveViewModel(AppHost host)
    {
        _host = host;
        ApplyCommand = new RelayCommand(Apply);
        UpdateCurve();
    }

    public ResponseCurve[] Curves { get; } = (ResponseCurve[])Enum.GetValues(typeof(ResponseCurve));

    private ResponseCurve _selectedCurve = ResponseCurve.Smooth;
    public ResponseCurve SelectedCurve
    {
        get => _selectedCurve;
        set { if (SetProperty(ref _selectedCurve, value)) UpdateCurve(); }
    }

    public string CurveDescription => SensitivityService.DescribeCurve(SelectedCurve);

    private List<double> _values = new();
    public List<double> CurveValues { get => _values; private set => SetProperty(ref _values, value); }

    private string _status = "";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand ApplyCommand { get; }

    private void UpdateCurve()
    {
        var pts = _host.Sensitivity.CurvePoints(SelectedCurve, null, 61);
        CurveValues = pts.Select(p => p.Y).ToList();
        OnPropertyChanged(nameof(CurveDescription));
    }

    private void Apply()
    {
        _host.AppSettings.Mouse.ResponseCurve = SelectedCurve;
        _host.AppSettings.EasyDrag.DragResponseCurve = SelectedCurve;
        _host.Settings.Save();
        Status = $"Applied '{SelectedCurve}' response curve to mouse and drag settings.";
    }
}

/// <summary>Frame analyser: live frame-time graph, stability and a real FPS drop recorder.</summary>
public sealed class FrameAnalyzerViewModel : ViewModelBase, IDisposable
{
    private readonly AppHost _host;

    public FrameAnalyzerViewModel(AppHost host)
    {
        _host = host;
        ToggleDropsCommand = new RelayCommand(ToggleDrops);
        ClearDropsCommand = new RelayCommand(ClearDrops);
        _host.Monitor.MetricsUpdated += OnMetrics;
        _host.FpsBoost.DropRecorded += OnDrop;
        _host.Monitor.Start();
    }

    private List<double> _frameTimes = new();
    public List<double> FrameTimeSeries { get => _frameTimes; private set => SetProperty(ref _frameTimes, value); }

    public string FpsText { get; private set; } = "--";
    public string FrameTimeText { get; private set; } = "--";
    public string StabilityText { get; private set; } = "NO DATA";

    public ObservableCollection<FpsDropEvent> Drops { get; } = new();

    public bool RecordDrops => _host.FpsBoost.RecordDrops;
    public string RecordDropsText => _host.FpsBoost.RecordDrops ? "Stop drop recorder" : "Start drop recorder";

    private string _status = "Live frame-time analysis. Start the drop recorder to log FPS dips.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand ToggleDropsCommand { get; }
    public RelayCommand ClearDropsCommand { get; }

    private void OnMetrics(PerformanceMetrics m)
    {
        Application.Current?.Dispatcher.Invoke(() =>
        {
            FpsText = m.Fps > 0 ? m.Fps.ToString("0") : "--";
            FrameTimeText = m.FrameTimeMs > 0 ? m.FrameTimeMs.ToString("0.0") + " ms" : "--";
            FrameTimeSeries = _host.Monitor.FrameTimeHistory.Snapshot(TimeSpan.FromSeconds(60))
                .Select(x => x.v).ToList();
            var s = new PerformanceSample { AverageFps = m.Fps, FrameTimeMs = m.FrameTimeMs, SampleCount = m.Fps > 0 ? 1 : 0 };
            StabilityText = m.FrameTimeMs > 0 ? s.StabilityLabel : "NO DATA";
            OnPropertyChanged(nameof(FpsText));
            OnPropertyChanged(nameof(FrameTimeText));
            OnPropertyChanged(nameof(StabilityText));
        });
    }

    private void OnDrop(FpsDropEvent ev)
    {
        Application.Current?.Dispatcher.Invoke(() =>
        {
            Drops.Insert(0, ev);
            while (Drops.Count > 50) Drops.RemoveAt(Drops.Count - 1);
        });
    }

    private void ToggleDrops()
    {
        _host.FpsBoost.RecordDrops = !_host.FpsBoost.RecordDrops;
        OnPropertyChanged(nameof(RecordDrops));
        OnPropertyChanged(nameof(RecordDropsText));
        Status = _host.FpsBoost.RecordDrops ? "FPS drop recorder started." : "FPS drop recorder stopped.";
    }

    private void ClearDrops()
    {
        Drops.Clear();
        _host.FpsBoost.DropEvents.Clear();
        Status = "Drop history cleared.";
    }

    public void Dispose()
    {
        _host.Monitor.MetricsUpdated -= OnMetrics;
        _host.FpsBoost.DropRecorded -= OnDrop;
    }
}

/// <summary>Configuration backup: real snapshots, restore, export/import and validation.</summary>
public sealed class BackupViewModel : ViewModelBase
{
    private readonly AppHost _host;

    public BackupViewModel(AppHost host)
    {
        _host = host;
        BackupCommand = new RelayCommand(BackupNow);
        RestoreCommand = new RelayCommand(Restore, () => SelectedBackup is not null);
        ExportCommand = new RelayCommand(Export, () => SelectedBackup is not null);
        ImportCommand = new RelayCommand(Import);
        ValidateCommand = new RelayCommand(Validate);
        Refresh();
    }

    public ObservableCollection<BackupEntry> Backups { get; } = new();

    private BackupEntry? _selectedBackup;
    public BackupEntry? SelectedBackup
    {
        get => _selectedBackup;
        set
        {
            if (SetProperty(ref _selectedBackup, value))
            {
                ((RelayCommand)RestoreCommand).RaiseCanExecuteChanged();
                ((RelayCommand)ExportCommand).RaiseCanExecuteChanged();
            }
        }
    }

    private string _status = "Create a backup before making changes so you can always roll back.";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand BackupCommand { get; }
    public RelayCommand RestoreCommand { get; }
    public RelayCommand ExportCommand { get; }
    public RelayCommand ImportCommand { get; }
    public RelayCommand ValidateCommand { get; }

    private void Refresh()
    {
        Backups.Clear();
        foreach (var b in _host.SafeUpdate.ListBackups()) Backups.Add(b);
        Status = $"{Backups.Count} backup(s) available.";
    }

    private void BackupNow()
    {
        var entry = _host.SafeUpdate.BackupNow("Manual backup");
        Refresh();
        Status = $"Backup created: {entry.Id} ({entry.FileCount} files).";
    }

    private void Restore()
    {
        if (SelectedBackup is null) return;
        if (_host.SafeUpdate.Restore(SelectedBackup.Id, out var msg))
        {
            _host.Settings.Load();
            Status = "Restored: " + msg;
        }
        else Status = "Restore failed: " + msg;
    }

    private void Export()
    {
        if (SelectedBackup is null) return;
        var path = Path.Combine(AppPaths.Root, $"backup_{SelectedBackup.Id}.zip");
        Status = _host.SafeUpdate.ExportBundle(SelectedBackup.Id, path, out var msg)
            ? "Exported to " + path
            : "Export failed: " + msg;
    }

    private void Import()
    {
        try
        {
            var file = new DirectoryInfo(AppPaths.Root)
                .GetFiles("backup_*.zip")
                .OrderByDescending(f => f.LastWriteTime)
                .FirstOrDefault();
            if (file is null) { Status = "No exported backup .zip found to import."; return; }
            Status = _host.SafeUpdate.ImportBundle(file.FullName, out var msg)
                ? "Imported: " + msg
                : "Import failed: " + msg;
            Refresh();
        }
        catch (Exception ex) { Status = "Import failed: " + ex.Message; }
    }

    private void Validate()
    {
        var result = _host.SafeUpdate.Validate(_host.AppSettings);
        Status = result.Summary + (result.Issues.Count > 0 ? " — " + string.Join("; ", result.Issues) : "");
    }
}

/// <summary>Overlay studio: crosshair + overlay settings with a live preview and toggle.</summary>
public sealed class OverlayStudioViewModel : ViewModelBase
{
    private readonly AppHost _host;
    private CrosshairSettings C => _host.AppSettings.Crosshair;
    private OverlaySettings O => _host.AppSettings.Overlay;

    public OverlayStudioViewModel(AppHost host)
    {
        _host = host;
        ShowCommand = new RelayCommand(() => { _host.Crosshair.ApplySettings(C); _host.Crosshair.Show(); OnPropertyChanged(nameof(IsVisible)); });
        HideCommand = new RelayCommand(() => { _host.Crosshair.Hide(); OnPropertyChanged(nameof(IsVisible)); });
        ToggleCommand = new RelayCommand(() => { _host.Crosshair.ApplySettings(C); _host.Crosshair.Toggle(); OnPropertyChanged(nameof(IsVisible)); });
        SaveCommand = new RelayCommand(() => { _host.Settings.Save(); _host.Crosshair.ApplySettings(C); Status = "Overlay saved."; });
    }

    public bool IsVisible => _host.Crosshair.IsVisible;
    public string[] Shapes { get; } = { "Cross", "Dot", "Circle", "CrossDot" };
    public string[] Colors { get; } = { "#FF2BD6", "#2BE7FF", "#35E08A", "#FFB020", "#FF4D6D", "#FFFFFF", "#000000" };
    public string[] AccessibilityModes { get; } = { "None", "Deuteranopia", "Protanopia", "Tritanopia" };

    public bool Enabled { get => C.Enabled; set { C.Enabled = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public string Shape { get => C.Shape; set { C.Shape = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public double Size { get => C.Size; set { C.Size = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public double Thickness { get => C.Thickness; set { C.Thickness = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public double Gap { get => C.Gap; set { C.Gap = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public double Opacity { get => C.Opacity; set { C.Opacity = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public string Color { get => C.Color; set { C.Color = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public bool CenterDot { get => C.CenterDot; set { C.CenterDot = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }
    public bool Outline { get => C.Outline; set { C.Outline = value; OnPropertyChanged(); _host.Crosshair.ApplySettings(C); } }

    public bool FpsCounter { get => O.FpsCounter; set { O.FpsCounter = value; OnPropertyChanged(); } }
    public bool FrameTimeGraph { get => O.FrameTimeGraph; set { O.FrameTimeGraph = value; OnPropertyChanged(); } }
    public bool PerformanceOverlay { get => O.PerformanceOverlay; set { O.PerformanceOverlay = value; OnPropertyChanged(); } }
    public bool ScreenRegionMarker { get => O.ScreenRegionMarker; set { O.ScreenRegionMarker = value; OnPropertyChanged(); } }
    public string AccessibilityMode { get => O.AccessibilityMode; set { O.AccessibilityMode = value; OnPropertyChanged(); } }

    private string _status = "";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand ShowCommand { get; }
    public RelayCommand HideCommand { get; }
    public RelayCommand ToggleCommand { get; }
    public RelayCommand SaveCommand { get; }
}

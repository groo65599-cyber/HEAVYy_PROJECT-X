﻿using System.Collections.ObjectModel;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

/// <summary>
/// Sensitivity workspace: response-curve preview (evaluated by the same engine the drag
/// processors use), Aim Feel / Easy Drag presets and a real drag test area that measures
/// distance, speed, acceleration, consistency and latency from actual cursor samples.
/// </summary>
public sealed class SensitivityViewModel : ViewModelBase
{
    private readonly AppHost _host;
    private SensitivityTestSession? _session;

    private ResponseCurve _selectedCurve = ResponseCurve.Smooth;
    private string _curveDescription = "";
    private double _sensitivity = 1.0;
    private string _outputPreview = "";
    private string _testStatus = "Press and drag inside the test area to measure.";
    private string _testSummary = "NO DATA";
    private double _testDistance;
    private double _testSpeed;
    private double _testAcceleration;
    private double _testConsistency;
    private double _testLatency;
    private int _testSamples;

    public ObservableCollection<double> CurveValues { get; } = new();
    public IReadOnlyList<ResponseCurve> Curves { get; } = Enum.GetValues<ResponseCurve>();
    public IReadOnlyList<AimFeel> AimFeels { get; } = Enum.GetValues<AimFeel>();
    public IReadOnlyList<EasyDragPreset> EasyDragPresets { get; } = Enum.GetValues<EasyDragPreset>();

    public SensitivityViewModel(AppHost host)
    {
        _host = host;
        ApplyAimFeelCommand = new RelayCommand(p => { if (p is AimFeel f) ApplyAimFeel(f); });
        ApplyPresetCommand = new RelayCommand(p => { if (p is EasyDragPreset e) ApplyPreset(e); });
        UpdateCurve();
    }

    public ResponseCurve SelectedCurve
    {
        get => _selectedCurve;
        set { if (SetProperty(ref _selectedCurve, value)) UpdateCurve(); }
    }

    public string CurveDescription { get => _curveDescription; private set => SetProperty(ref _curveDescription, value); }

    public double Sensitivity
    {
        get => _sensitivity;
        set { if (SetProperty(ref _sensitivity, Math.Clamp(value, 0.1, 3.0))) UpdateOutputPreview(); }
    }

    public string OutputPreview { get => _outputPreview; private set => SetProperty(ref _outputPreview, value); }

    public string TestStatus { get => _testStatus; private set => SetProperty(ref _testStatus, value); }
    public string TestSummary { get => _testSummary; private set => SetProperty(ref _testSummary, value); }
    public double TestDistance { get => _testDistance; private set => SetProperty(ref _testDistance, value); }
    public double TestSpeed { get => _testSpeed; private set => SetProperty(ref _testSpeed, value); }
    public double TestAcceleration { get => _testAcceleration; private set => SetProperty(ref _testAcceleration, value); }
    public double TestConsistency { get => _testConsistency; private set => SetProperty(ref _testConsistency, value); }
    public double TestLatency { get => _testLatency; private set => SetProperty(ref _testLatency, value); }
    public int TestSamples { get => _testSamples; private set => SetProperty(ref _testSamples, value); }

    public RelayCommand ApplyAimFeelCommand { get; }
    public RelayCommand ApplyPresetCommand { get; }

    private void UpdateCurve()
    {
        CurveDescription = SensitivityService.DescribeCurve(SelectedCurve);
        var pts = _host.Sensitivity.CurvePoints(SelectedCurve, null, 61);
        CurveValues.Clear();
        foreach (var (_, y) in pts) CurveValues.Add(y);
        UpdateOutputPreview();
    }

    private void UpdateOutputPreview()
    {
        // Show how a 50% and 100% input map through the curve, scaled by sensitivity.
        double mid = _host.Sensitivity.ApplyCurve(0.5, SelectedCurve) * _sensitivity;
        double full = _host.Sensitivity.ApplyCurve(1.0, SelectedCurve) * _sensitivity;
        OutputPreview = $"50% input → {mid * 100:0}% output · 100% input → {full * 100:0}% output";
    }

    private void ApplyAimFeel(AimFeel feel)
    {
        _host.Sensitivity.ApplyAimFeel(_host.AppSettings, feel);
        _host.Settings.Save();
        TestStatus = $"Aim Feel applied: {feel}.";
    }

    private void ApplyPreset(EasyDragPreset preset)
    {
        _host.Sensitivity.ApplyEasyDragPreset(_host.AppSettings, preset);
        _host.Settings.Save();
        TestStatus = $"Easy Drag preset applied: {preset}.";
    }

    // ---- Test area ----
    public void BeginTest(string mode = "Drag")
    {
        _session = _host.Sensitivity.BeginTest(mode);
        TestStatus = "Recording… release to finish.";
    }

    public void FeedTest(double x, double y) => _session?.Feed(x, y, InputTestService.NowMs);

    public void CompleteTest()
    {
        if (_session is null) return;
        var r = _session.Complete();
        TestDistance = r.DistancePx;
        TestSpeed = r.SpeedPxPerSec;
        TestAcceleration = r.Acceleration;
        TestConsistency = r.Consistency;
        TestLatency = r.LatencyMs;
        TestSamples = r.SampleCount;
        TestSummary = r.HasData ? r.Summary : "NO DATA";
        TestStatus = r.HasData ? "Measurement complete." : "Not enough movement captured.";
        _session = null;
    }
}

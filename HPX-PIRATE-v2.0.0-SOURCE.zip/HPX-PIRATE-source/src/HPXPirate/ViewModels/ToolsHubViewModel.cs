﻿using System.Collections.ObjectModel;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

/// <summary>
/// The HPX PIRATE Toolbox hub: search, category filter, favourites and recent ordering.
/// Every card opens a real, working tool view. Readiness is reported honestly.
/// </summary>
public sealed class ToolsHubViewModel : ViewModelBase
{
    private readonly AppHost _host;
    private string _searchText = "";
    private string _selectedCategory = "All";
    private string _status = "";

    public ObservableCollection<ToolDefinition> Tools { get; } = new();
    public ObservableCollection<ToolDefinition> Favorites { get; } = new();
    public ObservableCollection<ToolDefinition> Recent { get; } = new();
    public ObservableCollection<string> Categories { get; } = new();

    /// <summary>Raised when a tool card is activated; the shell performs the navigation.</summary>
    public event Action<string>? ToolActivated;

    public ToolsHubViewModel(AppHost host)
    {
        _host = host;
        OpenToolCommand = new RelayCommand(p => OpenTool(p as ToolDefinition));
        ToggleFavoriteCommand = new RelayCommand(p => ToggleFavorite(p as ToolDefinition));
        ClearSearchCommand = new RelayCommand(() => { SearchText = ""; });
        Categories.Add("All");
        foreach (var c in _host.Tools.Categories) Categories.Add(c);
        Refresh();
    }

    public string SearchText
    {
        get => _searchText;
        set { if (SetProperty(ref _searchText, value)) Refresh(); }
    }

    public string SelectedCategory
    {
        get => _selectedCategory;
        set { if (SetProperty(ref _selectedCategory, value)) Refresh(); }
    }

    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    public RelayCommand OpenToolCommand { get; }
    public RelayCommand ToggleFavoriteCommand { get; }
    public RelayCommand ClearSearchCommand { get; }

    private void Refresh()
    {
        IEnumerable<ToolDefinition> results = _host.Tools.Search(SearchText);
        if (!string.IsNullOrEmpty(SelectedCategory) && SelectedCategory != "All")
            results = results.Where(t => t.Category == SelectedCategory);

        Tools.Clear();
        foreach (var t in results) Tools.Add(t);

        Favorites.Clear();
        foreach (var t in _host.Tools.Favorites) Favorites.Add(t);

        Recent.Clear();
        foreach (var t in _host.Tools.Recent) Recent.Add(t);

        Status = $"{Tools.Count} tool(s) · {Favorites.Count} favourite(s)";
    }

    public void OpenTool(ToolDefinition? tool)
    {
        if (tool is null || string.IsNullOrWhiteSpace(tool.ViewKey)) return;
        _host.Tools.MarkRecent(tool.Id);
        ToolActivated?.Invoke(tool.ViewKey);
    }

    private void ToggleFavorite(ToolDefinition? tool)
    {
        if (tool is null) return;
        _host.Tools.ToggleFavorite(tool.Id);
        Refresh();
    }
}

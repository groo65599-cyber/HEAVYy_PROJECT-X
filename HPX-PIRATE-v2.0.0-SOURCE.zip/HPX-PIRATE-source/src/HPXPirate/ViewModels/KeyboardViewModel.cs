﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows.Threading;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

/// <summary>
/// Live keyboard / mouse monitor backed by the real low-level input hooks and the
/// <see cref="InputTestService"/>. Every figure shown is measured; when no events have arrived
/// the UI reports "NO DATA" instead of inventing numbers.
/// </summary>
public sealed class KeyboardViewModel : ViewModelBase
{
    private readonly AppHost _host;
    private readonly DispatcherTimer _timer;

    private bool _isListening;
    private string _pollingRateText = "NO DATA";
    private string _latencyStatus = "NO DATA";
    private string _lastEventText = "Waiting for input…";

    public ObservableCollection<InputEventRecord> RecentEvents { get; } = new();
    public ObservableCollection<KeyStateModel> KeyStates { get; } = new();

    public KeyboardViewModel(AppHost host)
    {
        _host = host;
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        _timer.Tick += (_, _) => Refresh();

        ToggleListenCommand = new RelayCommand(ToggleListen);
        ClearCommand = new RelayCommand(Clear);
        MarkStimulusCommand = new RelayCommand(MarkStimulus);
        ExportCommand = new RelayCommand(Export);
    }

    public bool IsListening
    {
        get => _isListening;
        private set { if (SetProperty(ref _isListening, value)) { OnPropertyChanged(nameof(ListenButtonText)); OnPropertyChanged(nameof(ListenStatusText)); } }
    }

    public string ListenButtonText => IsListening ? "Stop monitoring" : "Start monitoring";
    public string ListenStatusText => IsListening ? "LISTENING" : "STOPPED";

    public string PollingRateText { get => _pollingRateText; private set => SetProperty(ref _pollingRateText, value); }
    public string LatencyStatus { get => _latencyStatus; private set => SetProperty(ref _latencyStatus, value); }
    public string LastEventText { get => _lastEventText; private set => SetProperty(ref _lastEventText, value); }

    public string HooksStatus => _host.Input.HooksActive ? "Input hooks active" : "Input hooks inactive";
    public string HooksTint => _host.Input.HooksActive ? "Brush.Tint.Ok" : "Brush.Tint.Bad";

    // Latency stats (read from the service each tick)
    public double LatencyAverage => _host.InputTest.ResponseLatency.Average;
    public double LatencyMinimum => _host.InputTest.ResponseLatency.Minimum;
    public double LatencyMaximum => _host.InputTest.ResponseLatency.Maximum;
    public double LatencyP95 => _host.InputTest.ResponseLatency.P95;
    public double LatencyStdDev => _host.InputTest.ResponseLatency.StdDev;
    public int LatencySamples => _host.InputTest.ResponseLatency.Samples.Count;
    public bool LatencyHasData => _host.InputTest.ResponseLatency.HasData;

    public RelayCommand ToggleListenCommand { get; }
    public RelayCommand ClearCommand { get; }
    public RelayCommand MarkStimulusCommand { get; }
    public RelayCommand ExportCommand { get; }

    public void Start()
    {
        _host.InputTest.Start();
        IsListening = _host.InputTest.IsListening;
        _timer.Start();
        Refresh();
    }

    public void Stop()
    {
        _timer.Stop();
        _host.InputTest.Stop();
        IsListening = false;
    }

    private void ToggleListen()
    {
        if (_host.InputTest.IsListening) Stop();
        else Start();
    }

    private void MarkStimulus()
    {
        _host.InputTest.MarkStimulus("visual");
        LastEventText = "Stimulus shown — press any key or mouse button to measure.";
    }

    private void Clear()
    {
        _host.InputTest.Clear();
        RecentEvents.Clear();
        KeyStates.Clear();
        LastEventText = "Cleared.";
        Refresh();
    }

    private void Export()
    {
        try
        {
            var sb = new StringBuilder();
            sb.AppendLine("HPX PIRATE — Input session export");
            sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"Polling rate: {PollingRateText}");
            sb.AppendLine($"Response latency samples: {LatencySamples}");
            sb.AppendLine();
            sb.AppendLine("time_ms,device,name,down,detail");
            foreach (var e in _host.InputTest.Recent)
                sb.AppendLine($"{e.TimeMs:0.000},{e.Device},{e.Name},{(e.Down ? 1 : 0)},{e.Detail}");
            var path = Path.Combine(AppPaths.Root, $"input-session-{DateTime.Now:yyyyMMdd-HHmmss}.csv");
            AppPaths.EnsureCreated();
            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
            LastEventText = "Exported to " + path;
        }
        catch (Exception ex)
        {
            LastEventText = "Export failed: " + ex.Message;
        }
    }

    private void Refresh()
    {
        // Recent events (newest first, capped)
        var recent = _host.InputTest.Recent;
        RecentEvents.Clear();
        foreach (var e in recent.TakeLast(60).Reverse())
            RecentEvents.Add(e);

        KeyStates.Clear();
        foreach (var k in _host.InputTest.KeyStates)
            KeyStates.Add(k);

        double hz = _host.InputTest.EstimatedPollingRateHz;
        PollingRateText = hz > 0 ? $"{hz:0} Hz" : "NO DATA";

        if (LatencyHasData)
            LatencyStatus = $"{LatencyAverage:0.0} ms avg · {LatencyP95:0.0} ms P95";
        else
            LatencyStatus = "NO DATA";

        if (recent.Count > 0)
        {
            var last = recent[^1];
            LastEventText = $"{last.Device} · {last.Name} · {(last.Down ? "down" : "up")} @ {last.TimeMs:0} ms";
        }

        OnPropertyChanged(nameof(LatencyAverage));
        OnPropertyChanged(nameof(LatencyMinimum));
        OnPropertyChanged(nameof(LatencyMaximum));
        OnPropertyChanged(nameof(LatencyP95));
        OnPropertyChanged(nameof(LatencyStdDev));
        OnPropertyChanged(nameof(LatencySamples));
        OnPropertyChanged(nameof(LatencyHasData));
        OnPropertyChanged(nameof(HooksStatus));
        OnPropertyChanged(nameof(HooksTint));
    }
}

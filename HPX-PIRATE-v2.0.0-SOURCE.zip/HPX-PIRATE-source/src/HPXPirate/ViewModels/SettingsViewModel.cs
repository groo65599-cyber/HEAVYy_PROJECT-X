using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Input;
using HPXPirate.Models;
using HPXPirate.Services;

namespace HPXPirate.ViewModels;

public sealed class SettingsViewModel : ViewModelBase
{
    private readonly AppHost _host;
    private AppSettings S => _host.AppSettings;

    public SettingsViewModel(AppHost host)
    {
        _host = host;
        SaveCommand = new RelayCommand(Save);
        ResetCommand = new RelayCommand(ResetAll);
        RestorePointCommand = new RelayCommand(() =>
        {
            _host.Restore.TryCreateRestorePoint("HPX PIRATE manual restore point", out var msg);
            Status = msg;
        });
        OpenDataFolderCommand = new RelayCommand(() => OpenPath(AppPaths.Root));
        OpenLogsCommand = new RelayCommand(() => OpenPath(AppPaths.Logs));
        CopyDataPathCommand = new RelayCommand(() =>
        {
            try { Clipboard.SetText(AppPaths.Root); Status = "Data folder path copied to clipboard."; }
            catch (Exception ex) { Status = "Copy failed: " + ex.Message; }
        });
    }

    private string _status = "";
    public string Status { get => _status; private set => SetProperty(ref _status, value); }

    // ---------------- General ----------------
    public bool StartWithWindows
    {
        get => S.StartWithWindows;
        set { S.StartWithWindows = value; _host.Startup.SetEnabled(value); OnPropertyChanged(); }
    }
    public bool MinimizeToTray { get => S.MinimizeToTray; set { S.MinimizeToTray = value; OnPropertyChanged(); } }
    public string Language { get => S.Language; set { S.Language = value; OnPropertyChanged(); } }
    public string Theme { get => S.Theme; set { S.Theme = value; OnPropertyChanged(); } }
    public bool AutoLoadProfiles { get => S.AutoLoadProfiles; set { S.AutoLoadProfiles = value; OnPropertyChanged(); } }

    // ---------------- Input ----------------
    public double MouseHorizontalSensitivity
    {
        get => S.Mouse.HorizontalSensitivity;
        set { S.Mouse.HorizontalSensitivity = Math.Round(value, 2); OnPropertyChanged(); }
    }
    public double MouseVerticalSensitivity
    {
        get => S.Mouse.VerticalSensitivity;
        set { S.Mouse.VerticalSensitivity = Math.Round(value, 2); OnPropertyChanged(); }
    }
    public double MouseAdsSensitivity
    {
        get => S.Mouse.AdsSensitivity;
        set { S.Mouse.AdsSensitivity = Math.Round(value, 2); OnPropertyChanged(); }
    }
    public bool MouseAcceleration { get => S.Mouse.MouseAcceleration; set { S.Mouse.MouseAcceleration = value; OnPropertyChanged(); } }
    public double MouseSmoothing
    {
        get => S.Mouse.MouseSmoothing;
        set { S.Mouse.MouseSmoothing = Math.Round(value, 2); OnPropertyChanged(); }
    }
    public ResponseCurve MouseResponseCurve
    {
        get => S.Mouse.ResponseCurve;
        set { S.Mouse.ResponseCurve = value; CurveSummary = SensitivityService.DescribeCurve(value); OnPropertyChanged(); }
    }
    public int MousePollingRate { get => S.Mouse.PollingRateHz; set { S.Mouse.PollingRateHz = value; OnPropertyChanged(); } }

    private string _curveSummary = SensitivityService.DescribeCurve(ResponseCurve.Linear);
    public string CurveSummary { get => _curveSummary; private set => SetProperty(ref _curveSummary, value); }

    // ---------------- Performance ----------------
    public OptimizationMode DefaultBoostMode { get => S.DefaultBoostMode; set { S.DefaultBoostMode = value; OnPropertyChanged(); } }
    public bool AutoOptimize { get => S.AutoOptimize; set { S.AutoOptimize = value; OnPropertyChanged(); } }
    public int MonitoringIntervalMs
    {
        get => S.MonitoringIntervalMs;
        set { S.MonitoringIntervalMs = value; _host.Monitor.ApplyIntervalSettings(); OnPropertyChanged(); }
    }
    public int IdleMonitoringIntervalMs { get => S.IdleMonitoringIntervalMs; set { S.IdleMonitoringIntervalMs = value; OnPropertyChanged(); } }
    public bool ReduceMonitoringWhenIdle { get => S.ReduceMonitoringWhenIdle; set { S.ReduceMonitoringWhenIdle = value; OnPropertyChanged(); } }

    // ---------------- Safety ----------------
    public bool CreateRestorePoints { get => S.CreateRestorePoints; set { S.CreateRestorePoints = value; OnPropertyChanged(); } }
    public bool BackupBeforeChanges { get => S.BackupBeforeChanges; set { S.BackupBeforeChanges = value; OnPropertyChanged(); } }
    public bool SafeMode { get => S.SafeMode; set { S.SafeMode = value; OnPropertyChanged(); } }

    // ---------------- Advanced ----------------
    public bool DiagnosticMode { get => S.DiagnosticMode; set { S.DiagnosticMode = value; OnPropertyChanged(); } }
    public string DataFolder => AppPaths.Root;
    public string LogFilePath => Path.Combine(AppPaths.Logs, "hpx_pirate.log");
    public string SettingsFilePath => AppPaths.SettingsFile;

    public string[] Languages { get; } = { "en", "id" };
    public string[] Themes { get; } = { "Dark", "Midnight", "Neon" };
    public OptimizationMode[] Modes { get; } = { OptimizationMode.Balanced, OptimizationMode.Performance, OptimizationMode.Extreme, OptimizationMode.Custom };
    public ResponseCurve[] ResponseCurves { get; } = Enum.GetValues<ResponseCurve>();
    public int[] PollingRates { get; } = { 125, 250, 500, 1000, 2000, 4000, 8000 };

    public ICommand SaveCommand { get; }
    public ICommand ResetCommand { get; }
    public ICommand RestorePointCommand { get; }
    public ICommand OpenDataFolderCommand { get; }
    public ICommand OpenLogsCommand { get; }
    public ICommand CopyDataPathCommand { get; }

    private void Save()
    {
        _host.Settings.Save();
        Status = "Settings saved.";
    }

    private void ResetAll()
    {
        var result = MessageBox.Show(
            "Reset ALL HPX PIRATE settings to defaults?\nThis does not touch Windows settings or your profiles.",
            "Reset Settings", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (result != MessageBoxResult.Yes) return;
        _host.Settings.ResetToDefaults();
        OnPropertyChanged(string.Empty);
        Status = "Settings reset to defaults.";
    }

    private void OpenPath(string path)
    {
        try
        {
            Directory.CreateDirectory(path);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true });
            Status = "Opened " + path;
        }
        catch (Exception ex)
        {
            Status = "Could not open folder: " + ex.Message;
        }
    }
}

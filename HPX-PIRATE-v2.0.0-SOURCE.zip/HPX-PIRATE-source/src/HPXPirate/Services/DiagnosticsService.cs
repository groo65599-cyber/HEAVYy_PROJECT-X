using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// Runs real, evidence-backed health checks across every subsystem. The whole point is to
/// DIAGNOSE before touching anything: a healthy subsystem is reported as WORKING, and an
/// unsupported capability is reported as NOT SUPPORTED — never as a fake pass or fake failure.
/// </summary>
public sealed class DiagnosticsService
{
    private readonly ILogger _log;
    private readonly AppHost _host;

    public DiagnosticsService(ILogger log, AppHost host)
    {
        _log = log;
        _host = host;
    }

    public DiagnosticReport RunFullCheck()
    {
        var report = new DiagnosticReport();
        report.Checks.Add(CheckPermissions());
        report.Checks.Add(CheckInputEngine());
        report.Checks.Add(CheckMappingEngine());
        report.Checks.Add(CheckProfiles());
        report.Checks.Add(CheckConfiguration());
        report.Checks.Add(CheckOverlay());
        report.Checks.Add(CheckPerformanceMonitors());
        report.Checks.Add(CheckController());
        report.Checks.Add(CheckTouch());
        report.Checks.Add(CheckCompatibility());
        report.Checks.Add(CheckDisplay());
        _log.Info($"Diagnostics complete: {report.Verdict} (health {report.HealthScore}).");
        return report;
    }

    // ------------------------------------------------------------------
    //  Individual checks
    // ------------------------------------------------------------------
    private DiagnosticCheck CheckPermissions()
    {
        var c = new DiagnosticCheck
        {
            Name = "Permissions",
            Category = DiagnosticCategory.Permissions
        };
        try
        {
            bool admin;
            using (var id = WindowsIdentity.GetCurrent())
                admin = new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);

            if (admin)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = "Running with administrator rights.";
                c.Evidence = "IsInRole(Administrator)=true";
            }
            else
            {
                c.Status = CheckStatus.Warning;
                c.Summary = "Running without administrator rights.";
                c.Cause = "Some system optimizations and restore points require elevation.";
                c.RecommendedAction = "Restart HPX PIRATE as administrator if you plan to apply system tweaks.";
                c.Evidence = "IsInRole(Administrator)=false";
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.NotSupported;
            c.Summary = "Permission check unavailable.";
            c.Evidence = ex.Message;
        }
        return c;
    }

    private DiagnosticCheck CheckInputEngine()
    {
        var c = new DiagnosticCheck
        {
            Name = "Input Engine",
            Category = DiagnosticCategory.Input
        };
        try
        {
            bool hooks = _host.Input.HooksActive;
            if (hooks)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = "Keyboard and mouse hooks are installed.";
                c.Evidence = "HooksActive=true";
            }
            else
            {
                c.Status = CheckStatus.Warning;
                c.Summary = "Input hooks are not currently installed.";
                c.Cause = "Hooks install when the main window opens; a failure usually means elevation is required.";
                c.RecommendedAction = "Reopen HPX PIRATE as administrator, then re-run diagnostics.";
                c.CanAutoFix = true;
                c.FixActionId = "input.reinstall_hooks";
                c.Evidence = "HooksActive=false";
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.Error;
            c.Summary = "Input engine reported an error.";
            c.Cause = ex.Message;
            c.RecommendedAction = "Restart the application.";
            c.Evidence = ex.ToString();
        }
        return c;
    }

    private DiagnosticCheck CheckMappingEngine()
    {
        var c = new DiagnosticCheck
        {
            Name = "Mapping Engine",
            Category = DiagnosticCategory.Mapping
        };
        try
        {
            int profiles = _host.Profiles.Profiles.Count;
            int mappings = _host.Profiles.Profiles.Sum(p => p.KeyboardMapping.Count + p.MouseMapping.Count);
            c.Status = CheckStatus.Ok;
            c.Summary = $"Mapping engine ready \u2014 {profiles} profile(s), {mappings} mapping(s).";
            c.Evidence = $"profiles={profiles}; mappings={mappings}";
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.Error;
            c.Summary = "Mapping engine unavailable.";
            c.Cause = ex.Message;
            c.RecommendedAction = "Open Game Profiles and verify your profiles load.";
            c.Evidence = ex.ToString();
        }
        return c;
    }

    private DiagnosticCheck CheckProfiles()
    {
        var c = new DiagnosticCheck
        {
            Name = "Profile System",
            Category = DiagnosticCategory.Profile
        };
        try
        {
            var dir = AppPaths.Profiles;
            if (!Directory.Exists(dir))
            {
                c.Status = CheckStatus.Warning;
                c.Summary = "Profiles folder does not exist yet.";
                c.Cause = "No profiles have been created.";
                c.RecommendedAction = "Create a game profile to get started.";
                c.Evidence = dir;
                return c;
            }

            int corrupt = 0;
            foreach (var f in Directory.EnumerateFiles(dir, "*.json"))
            {
                try
                {
                    var json = File.ReadAllText(f);
                    if (JsonHelper.Deserialize<GameProfile>(json) is null) corrupt++;
                }
                catch { corrupt++; }
            }

            if (corrupt == 0)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = "All profiles are valid and readable.";
                c.Evidence = $"folder={dir}; corrupt=0";
            }
            else
            {
                c.Status = CheckStatus.Warning;
                c.Summary = $"{corrupt} profile file(s) could not be parsed.";
                c.Cause = "A profile may be from an older format or partially written.";
                c.RecommendedAction = "Use Tools \u2192 Profile Converter, or restore from a backup.";
                c.Evidence = $"corrupt={corrupt}";
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.Error;
            c.Summary = "Profile check failed.";
            c.Cause = ex.Message;
            c.RecommendedAction = "Check folder permissions for %APPDATA%\\HPXPirate.";
            c.Evidence = ex.ToString();
        }
        return c;
    }

    private DiagnosticCheck CheckConfiguration()
    {
        var c = new DiagnosticCheck
        {
            Name = "Configuration",
            Category = DiagnosticCategory.Configuration
        };
        try
        {
            var s = _host.AppSettings;
            bool sane = s.MonitoringIntervalMs >= 100
                        && s.IdleMonitoringIntervalMs >= 100
                        && s.Mouse.HorizontalSensitivity > 0
                        && s.Mouse.VerticalSensitivity > 0;
            if (sane)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = "Settings loaded and within valid ranges.";
                c.Evidence = $"monitor={s.MonitoringIntervalMs}ms; idle={s.IdleMonitoringIntervalMs}ms";
            }
            else
            {
                c.Status = CheckStatus.Warning;
                c.Summary = "One or more settings are outside the expected range.";
                c.Cause = "A value may have been edited manually or left over from an older version.";
                c.RecommendedAction = "Open Settings and choose Reset to Defaults (your profiles are untouched).";
                c.CanAutoFix = true;
                c.FixActionId = "config.clamp";
                c.Evidence = "out-of-range setting detected";
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.Error;
            c.Summary = "Configuration could not be read.";
            c.Cause = ex.Message;
            c.RecommendedAction = "Restore settings from backup in Tools \u2192 Configuration Backup.";
            c.Evidence = ex.ToString();
        }
        return c;
    }

    private DiagnosticCheck CheckOverlay()
    {
        var c = new DiagnosticCheck
        {
            Name = "Overlay",
            Category = DiagnosticCategory.Overlay
        };
        try
        {
            bool enabled = _host.AppSettings.Overlay.FpsCounter || _host.AppSettings.Crosshair.Enabled;
            c.Status = CheckStatus.Ok;
            c.Summary = enabled ? "Overlay services ready." : "Overlay is available (currently disabled).";
            c.Evidence = $"fpsCounter={_host.AppSettings.Overlay.FpsCounter}; crosshair={_host.AppSettings.Crosshair.Enabled}";
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.Error;
            c.Summary = "Overlay service error.";
            c.Cause = ex.Message;
            c.RecommendedAction = "Toggle the crosshair to re-initialise the overlay.";
            c.Evidence = ex.ToString();
        }
        return c;
    }

    private DiagnosticCheck CheckPerformanceMonitors()
    {
        var c = new DiagnosticCheck
        {
            Name = "Performance Monitors",
            Category = DiagnosticCategory.Performance
        };
        try
        {
            bool hw = _host.Hardware.IsAvailable;
            bool fps = _host.Fps.IsAvailable;
            if (hw || fps)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = $"Hardware sensors: {(hw ? "available" : "unavailable")}; FPS capture: {(fps ? "available" : "unavailable")}.";
                c.Evidence = $"hardware={hw}; fps={fps}";
            }
            else
            {
                c.Status = CheckStatus.NotSupported;
                c.Summary = "No performance sensor APIs are available on this system.";
                c.Cause = "Temperature/GPU sensors and ETW frame capture could not be initialised.";
                c.RecommendedAction = "CPU/RAM metrics still work. GPU/temperature metrics need vendor drivers.";
                c.Evidence = "hardware=false; fps=false";
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.NotSupported;
            c.Summary = "Performance monitor check unavailable.";
            c.Evidence = ex.Message;
        }
        return c;
    }

    private DiagnosticCheck CheckController()
    {
        var c = new DiagnosticCheck
        {
            Name = "Controller",
            Category = DiagnosticCategory.Compatibility
        };
        try
        {
            bool connected = _host.Controller.IsConnected;
            if (!_host.Controller.IsSupported)
            {
                c.Status = CheckStatus.NotSupported;
                c.Summary = "XInput is not available on this system.";
                c.Cause = "Controller support requires the XInput runtime (Windows).";
                c.Evidence = "XInput unavailable";
            }
            else if (connected)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = "A controller is connected.";
                c.Evidence = "XInputGetState=connected";
            }
            else
            {
                c.Status = CheckStatus.NotSupported;
                c.Summary = "No controller connected.";
                c.Cause = "XInput is available but no device is reporting.";
                c.RecommendedAction = "Connect a controller and re-run diagnostics.";
                c.Evidence = "XInputGetState=disconnected";
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.NotSupported;
            c.Summary = "Controller check unavailable.";
            c.Evidence = ex.Message;
        }
        return c;
    }

    private DiagnosticCheck CheckTouch()
    {
        // HPX PIRATE is a Windows desktop utility. Native touch injection into mobile games is
        // not something a desktop app can honestly promise, so we say so plainly.
        return new DiagnosticCheck
        {
            Name = "Touch",
            Category = DiagnosticCategory.Compatibility,
            Status = CheckStatus.NotSupported,
            Summary = "Touch injection is not available on Windows desktop.",
            Cause = "This build targets Windows desktop; it does not inject touch into mobile games.",
            RecommendedAction = "Touch sensitivity settings are stored per-profile for reference and for supported targets.",
            Evidence = "platform=windows-desktop"
        };
    }

    private DiagnosticCheck CheckCompatibility()
    {
        var c = new DiagnosticCheck
        {
            Name = "Compatibility",
            Category = DiagnosticCategory.Compatibility
        };
        try
        {
            var os = Environment.OSVersion;
            bool win = os.Platform == PlatformID.Win32NT;
            bool modern = os.Version.Major >= 10;
            if (win && modern)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = $"Windows {os.Version.Major}.{os.Version.Minor} build {os.Version.Build} supported.";
                c.Evidence = os.VersionString;
            }
            else if (win)
            {
                c.Status = CheckStatus.Warning;
                c.Summary = "Older Windows version detected.";
                c.Cause = "HPX PIRATE targets Windows 10/11.";
                c.RecommendedAction = "Update Windows for full compatibility.";
                c.Evidence = os.VersionString;
            }
            else
            {
                c.Status = CheckStatus.NotSupported;
                c.Summary = "Non-Windows platform detected.";
                c.Cause = "System optimization features require Windows.";
                c.Evidence = os.VersionString;
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.NotSupported;
            c.Summary = "Compatibility check unavailable.";
            c.Evidence = ex.Message;
        }
        return c;
    }

    private DiagnosticCheck CheckDisplay()
    {
        var c = new DiagnosticCheck
        {
            Name = "Display",
            Category = DiagnosticCategory.Performance
        };
        try
        {
            var d = _host.Display.GetDisplayInfo();
            if (d.Available)
            {
                c.Status = CheckStatus.Ok;
                c.Summary = d.Summary;
                if (d.MaxRefreshHz > d.CurrentRefreshHz)
                {
                    c.Status = CheckStatus.Warning;
                    c.Cause = $"Your monitor supports up to {d.MaxRefreshHz} Hz but is running at {d.CurrentRefreshHz} Hz.";
                    c.RecommendedAction = "Raise the refresh rate in Windows Display settings to match your monitor.";
                }
                c.Evidence = d.Summary;
            }
            else
            {
                c.Status = CheckStatus.NotSupported;
                c.Summary = "DISPLAY DATA NOT AVAILABLE.";
                c.Cause = "Refresh-rate information could not be read on this system.";
                c.Evidence = "display=unavailable";
            }
        }
        catch (Exception ex)
        {
            c.Status = CheckStatus.NotSupported;
            c.Summary = "Display check unavailable.";
            c.Evidence = ex.Message;
        }
        return c;
    }
}

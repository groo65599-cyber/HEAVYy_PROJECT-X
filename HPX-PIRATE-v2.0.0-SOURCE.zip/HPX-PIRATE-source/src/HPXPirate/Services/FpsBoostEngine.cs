using System.Diagnostics;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// HPX ULTRA FPS BOOST ENGINE.
///
/// The whole engine is built around one rule: NO FAKE FPS. It never invents a number and never
/// claims a gain it did not measure. The flow is:
///   DETECT \u2192 BASELINE \u2192 ANALYZE \u2192 IDENTIFY BOTTLENECK \u2192 CREATE PLAN \u2192 SHOW CHANGES
///   \u2192 APPLY \u2192 MEASURE \u2192 COMPARE \u2192 VERIFY \u2192 KEEP OR ROLLBACK.
///
/// If a baseline or post measurement has no data, the comparison says so instead of guessing.
/// </summary>
public sealed class FpsBoostEngine : IDisposable
{
    private readonly ILogger _log;
    private readonly MonitorService _monitor;
    private readonly HardwareMonitorService _hardware;
    private readonly DisplayService _display;
    private readonly SystemOptimizerService _optimizer;
    private readonly InputTestService _inputTest;
    private readonly SettingsService _settings;

    private readonly object _gate = new();
    private readonly List<(double Fps, double Ft, double Cpu, double Gpu, double Ram)> _window = new();

    private MeasurementPhase _phase = MeasurementPhase.Idle;
    private double _windowSeconds = 10;
    private DateTime _windowStart;
    private bool _subscribed;

    // FPS drop recorder
    private readonly Queue<double> _recentFps = new();
    private const int RecentFpsCap = 30;
    private double _lastRecordedDropFps;

    public MeasurementPhase Phase { get { lock (_gate) return _phase; } }
    public bool IsMeasuring => Phase != MeasurementPhase.Idle;
    public double Progress
    {
        get
        {
            lock (_gate)
            {
                if (_phase == MeasurementPhase.Idle) return 0;
                double elapsed = (DateTime.Now - _windowStart).TotalSeconds;
                return Math.Clamp(elapsed / _windowSeconds, 0, 1);
            }
        }
    }

    public PerformanceSample? Baseline { get; private set; }
    public PerformanceSample? After { get; private set; }

    public List<FpsDropEvent> DropEvents { get; } = new();
    public bool RecordDrops { get; set; }

    public event Action<PerformanceSample>? MeasurementCompleted;
    public event Action<FpsDropEvent>? DropRecorded;

    public FpsBoostEngine(ILogger log, MonitorService monitor, HardwareMonitorService hardware,
        DisplayService display, SystemOptimizerService optimizer, InputTestService inputTest,
        SettingsService settings)
    {
        _log = log;
        _monitor = monitor;
        _hardware = hardware;
        _display = display;
        _optimizer = optimizer;
        _inputTest = inputTest;
        _settings = settings;
    }

    public void Attach()
    {
        if (_subscribed) return;
        _monitor.MetricsUpdated += OnMetrics;
        _subscribed = true;
    }

    // ------------------------------------------------------------------
    //  DETECT
    // ------------------------------------------------------------------
    public DisplayInfo DetectDisplay() => _display.GetDisplayInfo(forceRefresh: true);

    public HardwareCapability DetectHardware()
    {
        var cap = new HardwareCapability();
        try
        {
            var s = _hardware.Sample();
            cap.CpuCores = s.CpuCores;
            cap.CpuThreads = Environment.ProcessorCount;
            cap.RamTotalGb = s.RamTotalMb / 1024.0;
            cap.RamAvailable = s.RamTotalMb > 0;
            cap.GpuName = s.GpuName;
            cap.GpuAvailable = !string.IsNullOrWhiteSpace(s.GpuName);
            cap.VramTotalGb = s.GpuMemTotalMb / 1024.0;
            cap.CpuName = "CPU"; // WMI name is not critical here; cores/threads are the useful part
            cap.CpuAvailable = s.CpuCores > 0;
        }
        catch (Exception ex)
        {
            _log.Debug("DetectHardware failed: " + ex.Message);
        }
        return cap;
    }

    /// <summary>Resolve the target FPS for a mode, clamped to the real panel capability.</summary>
    public int ResolveTarget(BoostMode mode, DisplayInfo display, int customTarget)
    {
        int refresh = display.Available && display.CurrentRefreshHz > 0 ? display.CurrentRefreshHz : 60;
        return mode switch
        {
            BoostMode.Balanced => Math.Min(refresh, 120),
            BoostMode.HighFps => refresh,
            BoostMode.UltraFps => refresh,
            BoostMode.Competitive => refresh,
            BoostMode.Custom => customTarget > 0 ? customTarget : refresh,
            _ => refresh
        };
    }

    // ------------------------------------------------------------------
    //  BASELINE / AFTER measurement windows
    // ------------------------------------------------------------------
    public void StartBaseline(double seconds = 10)
    {
        StartWindow(MeasurementPhase.Baseline, seconds);
        _log.Info($"FPS baseline measurement started ({seconds:0}s).");
    }

    public void StartAfter(double seconds = 10)
    {
        StartWindow(MeasurementPhase.After, seconds);
        _log.Info($"FPS post-boost measurement started ({seconds:0}s).");
    }

    public void CancelMeasurement()
    {
        lock (_gate)
        {
            _phase = MeasurementPhase.Idle;
            _window.Clear();
        }
    }

    private void StartWindow(MeasurementPhase phase, double seconds)
    {
        Attach();
        lock (_gate)
        {
            _phase = phase;
            _windowSeconds = Math.Clamp(seconds, 3, 120);
            _windowStart = DateTime.Now;
            _window.Clear();
        }
    }

    private void OnMetrics(PerformanceMetrics m)
    {
        // Feed the drop recorder first (independent of measurement windows).
        if (RecordDrops) FeedDropRecorder(m);

        lock (_gate)
        {
            if (_phase == MeasurementPhase.Idle) return;
            if (m.FrameTimeMs > 0 || m.Fps > 0)
                _window.Add((m.Fps, m.FrameTimeMs, m.CpuUsage, m.GpuUsage, m.RamUsagePercent));

            if ((DateTime.Now - _windowStart).TotalSeconds >= _windowSeconds)
            {
                var sample = BuildSample(_phase == MeasurementPhase.Baseline ? "Baseline" : "After");
                var phase = _phase;
                _phase = MeasurementPhase.Idle;
                if (phase == MeasurementPhase.Baseline) Baseline = sample; else After = sample;
                _log.Info($"Measurement complete ({phase}): {sample.AverageFps:0.0} avg FPS, {sample.SampleCount} samples.");
                MeasurementCompleted?.Invoke(sample);
            }
        }
    }

    private PerformanceSample BuildSample(string label)
    {
        var sample = new PerformanceSample { Label = label };
        var fps = _window.Select(w => w.Fps).Where(v => v > 0).ToList();
        var ft = _window.Select(w => w.Ft).Where(v => v > 0).ToList();

        sample.SampleCount = fps.Count;
        if (fps.Count == 0) return sample;

        sample.AverageFps = fps.Average();
        sample.FrameTimeMs = ft.Count > 0 ? ft.Average() : (sample.AverageFps > 0 ? 1000.0 / sample.AverageFps : 0);

        if (ft.Count > 0)
        {
            double mean = ft.Average();
            double variance = ft.Sum(x => (x - mean) * (x - mean)) / ft.Count;
            sample.FrameTimeVariance = Math.Sqrt(variance);

            var slowest = ft.OrderByDescending(x => x).ToArray();
            sample.OnePercentLow = AvgFpsOfSlowest(slowest, 0.01);
            sample.PointOnePercentLow = AvgFpsOfSlowest(slowest, 0.001);
        }

        sample.CpuPercent = _window.Select(w => w.Cpu).DefaultIfEmpty(0).Average();
        sample.GpuPercent = _window.Select(w => w.Gpu).DefaultIfEmpty(0).Average();
        sample.RamPercent = _window.Select(w => w.Ram).DefaultIfEmpty(0).Average();
        sample.InputLatencyMs = _inputTest.ResponseLatency.HasData ? _inputTest.ResponseLatency.Average : 0;
        return sample;
    }

    private static double AvgFpsOfSlowest(double[] slowestFirst, double fraction)
    {
        if (slowestFirst.Length == 0) return 0;
        int take = Math.Max(1, (int)Math.Ceiling(slowestFirst.Length * fraction));
        var avgMs = slowestFirst.Take(take).Average();
        return avgMs > 0 ? 1000.0 / avgMs : 0;
    }

    // ------------------------------------------------------------------
    //  ANALYZE + PLAN
    // ------------------------------------------------------------------
    public BoostPlan BuildPlan(BoostMode mode, PerformanceSample? baseline, int customTarget = 0)
    {
        var display = DetectDisplay();
        var plan = new BoostPlan
        {
            Mode = mode,
            TargetAuto = mode != BoostMode.Custom,
            TargetFps = ResolveTarget(mode, display, customTarget),
            Display = display
        };

        var sample = baseline;
        plan.Bottleneck = IdentifyBottleneck(sample, display, out var detail);
        plan.BottleneckDetail = detail;

        // Findings (honest, evidence-based).
        if (display.Available)
        {
            plan.Findings.Add($"Display: {display.Summary}.");
            if (display.MaxRefreshHz > display.CurrentRefreshHz && display.CurrentRefreshHz > 0)
                plan.Findings.Add($"Your panel supports {display.MaxRefreshHz} Hz but Windows is running at {display.CurrentRefreshHz} Hz.");
        }
        else
        {
            plan.Findings.Add("Display data is not available on this system.");
        }

        if (sample is { HasData: true })
        {
            plan.Findings.Add($"Baseline: {sample.AverageFps:0.0} avg FPS, 1% low {sample.OnePercentLow:0.0}, frame time {sample.FrameTimeMs:0.00} ms.");
            plan.Findings.Add($"Stability: {sample.StabilityLabel} ({sample.Stability:0}/100).");
        }
        else
        {
            plan.Findings.Add("No baseline measurement yet \u2014 run a baseline to get real numbers.");
        }

        // Bottleneck-specific recommendations.
        switch (plan.Bottleneck)
        {
            case BottleneckKind.DisplayLimited:
                plan.Recommendations.Add("Raise the Windows refresh rate to the panel maximum, then re-test.");
                break;
            case BottleneckKind.FpsCapLimited:
                plan.Recommendations.Add("An in-game or driver FPS cap appears to be active. Raise or remove it for more headroom.");
                break;
            case BottleneckKind.CpuLimited:
                plan.Recommendations.Add("Reduce background CPU load and raise the game's process priority.");
                break;
            case BottleneckKind.GpuLimited:
                plan.Recommendations.Add("The GPU is the limit \u2014 lower in-game graphics settings or resolution for more FPS.");
                break;
            case BottleneckKind.MemoryLimited:
                plan.Recommendations.Add("Close memory-heavy apps; RAM is under pressure.");
                break;
            case BottleneckKind.ThermalLimited:
                plan.Recommendations.Add("Temperatures are high \u2014 check cooling and airflow to avoid throttling.");
                break;
        }

        // Build the plan items from the optimizer's catalogue (single source of truth).
        var actions = _optimizer.BuildPlan(MapToOptimizationMode(mode));
        foreach (var a in actions)
        {
            plan.Items.Add(new BoostPlanItem
            {
                Title = a.Title,
                Explanation = a.Description,
                Category = a.Category.ToString(),
                Risk = a.Risk,
                Selected = a.Selected,
                Reversible = a.IsReversible
            });
        }

        plan.CanReachTarget = CanReachTarget(plan.TargetFps, sample, display, plan.Bottleneck, out var note);
        plan.TargetNote = note;
        plan.ReadinessScore = ComputeReadiness(sample, display);
        plan.ReadinessLabel = plan.ReadinessScore >= 80 ? "READY"
            : plan.ReadinessScore >= 50 ? "PARTIAL DATA"
            : "NEEDS MEASUREMENT";
        return plan;
    }

    private static OptimizationMode MapToOptimizationMode(BoostMode mode) => mode switch
    {
        BoostMode.Balanced => OptimizationMode.Balanced,
        BoostMode.HighFps => OptimizationMode.Performance,
        BoostMode.UltraFps => OptimizationMode.Extreme,
        BoostMode.Competitive => OptimizationMode.Performance,
        BoostMode.Custom => OptimizationMode.Custom,
        _ => OptimizationMode.Balanced
    };

    public BottleneckKind IdentifyBottleneck(PerformanceSample? s, DisplayInfo display, out string detail)
    {
        detail = "";
        if (s is not { HasData: true })
        {
            detail = "Not enough data. Run a baseline measurement first.";
            return BottleneckKind.NotEnoughData;
        }

        // Display / cap limited: FPS sits right at the refresh rate.
        if (display.Available && display.CurrentRefreshHz > 0)
        {
            double refresh = display.CurrentRefreshHz;
            if (Math.Abs(s.AverageFps - refresh) <= refresh * 0.03)
            {
                detail = $"Average FPS ({s.AverageFps:0}) matches the {refresh} Hz refresh rate \u2014 the display is the limit.";
                return BottleneckKind.DisplayLimited;
            }
        }

        // Common engine/driver FPS caps.
        foreach (var cap in new double[] { 30, 60, 75, 90, 120, 144, 165, 240 })
        {
            if (Math.Abs(s.AverageFps - cap) <= cap * 0.02 && s.AverageFps > 25)
            {
                detail = $"Average FPS ({s.AverageFps:0}) is pinned to a {cap:0} FPS cap.";
                return BottleneckKind.FpsCapLimited;
            }
        }

        if (s.RamPercent >= 90)
        {
            detail = $"RAM is {s.RamPercent:0}% full \u2014 memory pressure is limiting performance.";
            return BottleneckKind.MemoryLimited;
        }

        if (s.CpuPercent >= 90 && s.GpuPercent > 0 && s.GpuPercent < 80)
        {
            detail = $"CPU {s.CpuPercent:0}% vs GPU {s.GpuPercent:0}% \u2014 CPU-bound.";
            return BottleneckKind.CpuLimited;
        }

        if (s.GpuPercent >= 95)
        {
            detail = $"GPU at {s.GpuPercent:0}% \u2014 GPU-bound (expected at high settings).";
            return BottleneckKind.GpuLimited;
        }

        if (s.Stability < 75)
        {
            detail = $"Frame-time variance is high (stability {s.Stability:0}/100) \u2014 likely background load or throttling.";
            return BottleneckKind.GameLimited;
        }

        detail = $"No clear bottleneck: FPS {s.AverageFps:0}, CPU {s.CpuPercent:0}%, GPU {s.GpuPercent:0}%, stability {s.Stability:0}/100.";
        return BottleneckKind.Unknown;
    }

    private static bool CanReachTarget(int target, PerformanceSample? s, DisplayInfo display, BottleneckKind kind, out string note)
    {
        note = "";
        if (display.Available && display.CurrentRefreshHz > 0 && target > display.CurrentRefreshHz)
        {
            note = $"Target {target} FPS exceeds the current {display.CurrentRefreshHz} Hz refresh rate. Raise the refresh rate first.";
            return false;
        }
        if (s is { HasData: true } && kind == BottleneckKind.GpuLimited && target > s.AverageFps * 1.15)
        {
            note = $"The GPU is already the limit at {s.AverageFps:0} FPS; reaching {target} FPS likely needs lower graphics settings.";
            return false;
        }
        note = s is { HasData: true }
            ? $"Target {target} FPS is plausible from a {s.AverageFps:0} FPS baseline."
            : $"Target {target} FPS set. Run a baseline to validate.";
        return true;
    }

    private static int ComputeReadiness(PerformanceSample? s, DisplayInfo display)
    {
        int score = 0;
        if (s is { HasData: true }) score += 60;
        if (display.Available) score += 25;
        if (s is { HasData: true } && s.SampleCount >= 30) score += 15;
        return Math.Clamp(score, 0, 100);
    }

    // ------------------------------------------------------------------
    //  APPLY / COMPARE / VERIFY
    // ------------------------------------------------------------------
    public BoostResult ApplyPlan(BoostPlan plan, bool createRestorePoint)
    {
        var actions = _optimizer.BuildPlan(MapToOptimizationMode(plan.Mode));
        // Respect the user's per-item selection from the plan UI.
        foreach (var a in actions)
        {
            var match = plan.Items.FirstOrDefault(i => i.Title == a.Title);
            if (match != null) a.Selected = match.Selected;
        }
        var result = _optimizer.ApplyPlan(actions, MapToOptimizationMode(plan.Mode), createRestorePoint);

        // Mirror results back into the plan items for display.
        foreach (var item in plan.Items)
        {
            var a = actions.FirstOrDefault(x => x.Title == item.Title);
            if (a != null)
            {
                item.Applied = a.Applied;
                item.Succeeded = a.Succeeded;
                item.ResultMessage = a.ResultMessage;
            }
        }
        return result;
    }

    public BoostComparison Compare(PerformanceSample? baseline, PerformanceSample? after)
        => new() { Baseline = baseline, After = after };

    /// <summary>Verify the result. If it regressed, roll back so the user keeps their configuration.</summary>
    public string VerifyAndKeepOrRollback(BoostComparison comparison)
    {
        if (!comparison.HasBoth)
            return "MEASUREMENT INCOMPLETE \u2014 run both a baseline and a post-boost measurement before deciding.";

        if (comparison.Regressed)
        {
            int n = _optimizer.RollbackAll();
            _log.Warn($"FPS regressed by {comparison.FpsDelta:0.0}; rolled back {n} change(s).");
            return $"REGRESSED \u2014 rolled back {n} change(s) to preserve your configuration.";
        }
        if (comparison.Improved)
        {
            _log.Info($"FPS improved by {comparison.FpsDelta:0.0}; keeping changes.");
            return $"IMPROVED \u2014 kept the applied optimizations (+{comparison.FpsDelta:0.0} FPS).";
        }
        // No significant change: be honest and roll back so we do not leave changes with no benefit.
        int m = _optimizer.RollbackAll();
        return $"NO SIGNIFICANT CHANGE \u2014 rolled back {m} change(s). Your configuration is preserved.";
    }

    // ------------------------------------------------------------------
    //  FPS drop recorder
    // ------------------------------------------------------------------
    private void FeedDropRecorder(PerformanceMetrics m)
    {
        if (m.Fps <= 0) return;
        lock (_gate)
        {
            _recentFps.Enqueue(m.Fps);
            while (_recentFps.Count > RecentFpsCap) _recentFps.Dequeue();

            if (_recentFps.Count < 10) return;
            double avg = _recentFps.Average();
            // A drop = current FPS more than 30% below the recent average, and not already logged.
            if (avg > 0 && m.Fps < avg * 0.7 && Math.Abs(m.Fps - _lastRecordedDropFps) > 1)
            {
                _lastRecordedDropFps = m.Fps;
                var ev = new FpsDropEvent
                {
                    FpsBefore = avg,
                    FpsAfter = m.Fps,
                    FrameTimeMs = m.FrameTimeMs,
                    CpuPercent = m.CpuUsage,
                    GpuPercent = m.GpuUsage,
                    RamPercent = m.RamUsagePercent,
                    PotentialCause = GuessDropCause(m)
                };
                DropEvents.Add(ev);
                while (DropEvents.Count > 100) DropEvents.RemoveAt(0);
                DropRecorded?.Invoke(ev);
            }
        }
    }

    private static string GuessDropCause(PerformanceMetrics m)
    {
        if (m.RamUsagePercent >= 88) return "memory pressure";
        if (m.CpuUsage >= 90) return "CPU spike";
        if (m.GpuUsage >= 97) return "GPU saturation";
        if (m.CpuTemperature >= 90 || m.GpuTemperature >= 90) return "possible thermal throttle";
        return "background activity";
    }

    public void Dispose()
    {
        if (_subscribed)
        {
            _monitor.MetricsUpdated -= OnMetrics;
            _subscribed = false;
        }
    }
}

public enum MeasurementPhase { Idle, Baseline, After }

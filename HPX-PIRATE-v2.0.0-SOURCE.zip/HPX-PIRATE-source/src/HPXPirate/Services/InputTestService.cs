using System.Diagnostics;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// Live input monitor + latency measurement. It listens to the real low-level input events
/// already captured by <see cref="InputMapperService"/> and records them with a monotonic clock.
///
/// Two honest measurements are produced:
///  - Polling/jitter: the interval between consecutive mouse-move events (device report rate).
///  - Response latency: the time between a stimulus being shown and the next input arriving
///    (this is a genuine end-to-end figure that includes the human, so it is labelled as such).
///
/// Nothing is fabricated: if no events arrive, every statistic reports HasData=false.
/// </summary>
public sealed class InputTestService : IDisposable
{
    private static readonly Stopwatch Clock = Stopwatch.StartNew();

    private readonly ILogger _log;
    private readonly InputMapperService _input;
    private readonly object _gate = new();
    private readonly List<InputEventRecord> _recent = new();
    private const int RecentCap = 500;

    private readonly Dictionary<string, KeyStateModel> _keyStates = new();
    private readonly List<double> _moveIntervals = new(); // ms between mouse moves
    private const int MoveCap = 2000;

    private double _lastMoveMs = -1;
    private double _stimulusMs = -1;
    private string _stimulusLabel = "";

    public LatencyStats ResponseLatency { get; } = new() { Label = "Response latency (stimulus \u2192 input)" };
    public LatencyStats PollingInterval { get; } = new() { Label = "Mouse report interval" };

    public event Action<InputEventRecord>? EventRecorded;

    public bool IsListening { get; private set; }

    public InputTestService(ILogger log, InputMapperService input)
    {
        _log = log;
        _input = input;
    }

    public static double NowMs => Clock.Elapsed.TotalMilliseconds;

    public void Start()
    {
        if (IsListening) return;
        _input.KeyDown += OnKeyDown;
        _input.KeyUp += OnKeyUp;
        _input.MouseButtonDown += OnMouseButtonDown;
        _input.MouseMoved += OnMouseMoved;
        IsListening = true;
        _log.Info("Input test monitor started.");
    }

    public void Stop()
    {
        if (!IsListening) return;
        _input.KeyDown -= OnKeyDown;
        _input.KeyUp -= OnKeyUp;
        _input.MouseButtonDown -= OnMouseButtonDown;
        _input.MouseMoved -= OnMouseMoved;
        IsListening = false;
        _log.Info("Input test monitor stopped.");
    }

    public IReadOnlyList<InputEventRecord> Recent
    {
        get { lock (_gate) return _recent.ToList(); }
    }

    public IReadOnlyList<KeyStateModel> KeyStates
    {
        get { lock (_gate) return _keyStates.Values.OrderByDescending(k => k.LastChangeMs).Take(24).ToList(); }
    }

    public void Clear()
    {
        lock (_gate)
        {
            _recent.Clear();
            _keyStates.Clear();
            _moveIntervals.Clear();
            ResponseLatency.Samples.Clear();
            PollingInterval.Samples.Clear();
            _lastMoveMs = -1;
            _stimulusMs = -1;
        }
    }

    /// <summary>Called by the UI the instant it renders a stimulus; the next input closes the loop.</summary>
    public void MarkStimulus(string label)
    {
        lock (_gate)
        {
            _stimulusMs = NowMs;
            _stimulusLabel = label;
        }
    }

    /// <summary>Average mouse report rate in Hz derived from real move intervals (0 when no data).</summary>
    public double EstimatedPollingRateHz
    {
        get
        {
            lock (_gate)
            {
                if (_moveIntervals.Count < 20) return 0;
                double avg = _moveIntervals.Average();
                return avg > 0 ? 1000.0 / avg : 0;
            }
        }
    }

    private void Push(InputEventRecord rec)
    {
        lock (_gate)
        {
            _recent.Add(rec);
            while (_recent.Count > RecentCap) _recent.RemoveAt(0);
        }
        EventRecorded?.Invoke(rec);
    }

    private void CloseStimulus(double eventMs)
    {
        lock (_gate)
        {
            if (_stimulusMs < 0) return;
            double delta = eventMs - _stimulusMs;
            if (delta > 0 && delta < 5000)
                ResponseLatency.Samples.Add(delta);
            _stimulusMs = -1;
        }
    }

    private void OnKeyDown(string key)
    {
        double ms = NowMs;
        CloseStimulus(ms);
        lock (_gate) _keyStates[key] = new KeyStateModel { Key = key, Pressed = true, LastChangeMs = ms };
        Push(new InputEventRecord { TimeMs = ms, Device = InputDeviceKind.Keyboard, Name = key, Down = true });
    }

    private void OnKeyUp(string key)
    {
        double ms = NowMs;
        lock (_gate) _keyStates[key] = new KeyStateModel { Key = key, Pressed = false, LastChangeMs = ms };
        Push(new InputEventRecord { TimeMs = ms, Device = InputDeviceKind.Keyboard, Name = key, Down = false });
    }

    private void OnMouseButtonDown(string button)
    {
        double ms = NowMs;
        CloseStimulus(ms);
        Push(new InputEventRecord { TimeMs = ms, Device = InputDeviceKind.Mouse, Name = button, Down = true });
    }

    private void OnMouseMoved(int x, int y)
    {
        double ms = NowMs;
        lock (_gate)
        {
            if (_lastMoveMs >= 0)
            {
                double dt = ms - _lastMoveMs;
                if (dt > 0 && dt < 100)
                {
                    _moveIntervals.Add(dt);
                    PollingInterval.Samples.Add(dt);
                    while (_moveIntervals.Count > MoveCap) _moveIntervals.RemoveAt(0);
                    while (PollingInterval.Samples.Count > MoveCap) PollingInterval.Samples.RemoveAt(0);
                }
            }
            _lastMoveMs = ms;
        }
        // Mouse moves are very high frequency; only surface them to the event list sparsely.
        Push(new InputEventRecord
        {
            TimeMs = ms,
            Device = InputDeviceKind.Mouse,
            Name = "Move",
            Down = true,
            Detail = $"{x},{y}"
        });
    }

    public void Dispose() => Stop();
}

using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// Lightweight composition root. Creates and owns every service the app uses.
/// </summary>
public sealed class AppHost : IDisposable
{
    // --- Core ---
    public LoggingService Logger { get; private set; } = null!;
    public SettingsService Settings { get; private set; } = null!;
    public ProfileManager Profiles { get; private set; } = null!;

    // --- Monitoring / performance ---
    public HardwareMonitorService Hardware { get; private set; } = null!;
    public FpsMonitorService Fps { get; private set; } = null!;
    public BottleneckAnalyzer Analyzer { get; private set; } = null!;
    public ProcessManagerService Processes { get; private set; } = null!;
    public MonitorService Monitor { get; private set; } = null!;
    public DisplayService Display { get; private set; } = null!;

    // --- System control ---
    public RestorePointService Restore { get; private set; } = null!;
    public SystemOptimizerService Optimizer { get; private set; } = null!;
    public StartupManagerService Startup { get; private set; } = null!;

    // --- Input / game control ---
    public InputMapperService Input { get; private set; } = null!;
    public CrosshairOverlayService Crosshair { get; private set; } = null!;
    public EasyDragEngine EasyDrag { get; private set; } = null!;
    public DragAssistEngine DragAssist { get; private set; } = null!;
    public ControllerService Controller { get; private set; } = null!;
    public InputTestService InputTest { get; private set; } = null!;
    public SensitivityService Sensitivity { get; private set; } = null!;

    // --- Diagnostics / tools / safety ---
    public DiagnosticsService Diagnostics { get; private set; } = null!;
    public FpsBoostEngine FpsBoost { get; private set; } = null!;
    public SafeUpdateService SafeUpdate { get; private set; } = null!;
    public ToolRegistry Tools { get; private set; } = null!;
    public BugReportService BugReport { get; private set; } = null!;

    public AppSettings AppSettings => Settings.Current;

    private bool _initialized;

    public void Initialize()
    {
        if (_initialized) return;

        AppPaths.EnsureCreated();
        Logger = new LoggingService(AppPaths.Logs);

        Settings = new SettingsService(Logger);
        Profiles = new ProfileManager(Logger);
        Profiles.LoadAll();

        Hardware = new HardwareMonitorService(Logger);
        Hardware.Initialize();

        Fps = new FpsMonitorService(Logger);
        Analyzer = new BottleneckAnalyzer();
        Processes = new ProcessManagerService(Logger);
        Restore = new RestorePointService(Logger);
        Optimizer = new SystemOptimizerService(Logger, Restore, Processes);
        Optimizer.LoadChanges();
        Startup = new StartupManagerService(Logger);
        Input = new InputMapperService(Logger);
        Crosshair = new CrosshairOverlayService(Logger);
        EasyDrag = new EasyDragEngine();
        DragAssist = new DragAssistEngine();

        Monitor = new MonitorService(Logger, Hardware, Fps, Analyzer, Processes, Settings);

        // Display + controller capability probing (honest NOT SUPPORTED fallbacks).
        Display = new DisplayService(Logger);
        Controller = new ControllerService(Logger);
        Controller.Probe();

        // Input testing + sensitivity engine.
        InputTest = new InputTestService(Logger, Input);
        Sensitivity = new SensitivityService(Logger);

        // Diagnostics needs the whole host so it can inspect every subsystem.
        Diagnostics = new DiagnosticsService(Logger, this);

        // FPS boost engine consumes real monitor + hardware + display + optimizer data.
        FpsBoost = new FpsBoostEngine(Logger, Monitor, Hardware, Display, Optimizer, InputTest, Settings);
        FpsBoost.Attach();

        // Safety + tools + bug reporting.
        SafeUpdate = new SafeUpdateService(Logger);
        Tools = new ToolRegistry(Logger);
        BugReport = new BugReportService(Logger, this, Diagnostics);

        _initialized = true;
        Logger.Info("AppHost initialised.");
    }

    public void Shutdown()
    {
        Logger?.Info("HPX PIRATE shutting down.");
        try { FpsBoost?.Dispose(); } catch { }
        try { InputTest?.Dispose(); } catch { }
        try { Monitor?.Dispose(); } catch { }
        try { Crosshair?.Dispose(); } catch { }
        try { Input?.Dispose(); } catch { }
        Settings?.Save();
    }

    public void Dispose() => Shutdown();
}

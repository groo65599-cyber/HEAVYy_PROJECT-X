using System.IO;
using System.IO.Compression;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// SAFE UPDATE &amp; ROLLBACK.
///
/// Before HPX PIRATE changes anything it can snapshot the user's world: settings, profiles,
/// keymapping, sensitivity and preferences. Every snapshot is a plain folder (and can also be
/// exported as a single .zip), so a user can always get back to a known-good state.
/// </summary>
public sealed class SafeUpdateService
{
    private readonly ILogger _log;

    public SafeUpdateService(ILogger log) => _log = log;

    /// <summary>Create a timestamped backup of settings + profiles + change log.</summary>
    public BackupEntry BackupNow(string label, bool auto = false)
    {
        AppPaths.EnsureCreated();
        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        var id = auto ? $"auto-{stamp}" : stamp;
        var dir = Path.Combine(AppPaths.Backups, id);
        Directory.CreateDirectory(dir);

        int files = 0;
        files += CopyIfExists(AppPaths.SettingsFile, Path.Combine(dir, "settings.json"));
        files += CopyIfExists(AppPaths.ChangesFile, Path.Combine(dir, "changes.json"));

        var profilesDir = Path.Combine(dir, "profiles");
        if (Directory.Exists(AppPaths.Profiles))
        {
            Directory.CreateDirectory(profilesDir);
            foreach (var f in Directory.EnumerateFiles(AppPaths.Profiles, "*.json"))
            {
                try { File.Copy(f, Path.Combine(profilesDir, Path.GetFileName(f)), true); files++; } catch { }
            }
        }

        var entry = new BackupEntry
        {
            Id = id,
            Label = label,
            Timestamp = DateTime.Now,
            Path = dir,
            FileCount = files,
            Auto = auto,
            SizeBytes = DirectorySize(dir)
        };
        _log.Info($"Backup created: {id} ({files} files).");
        return entry;
    }

    public List<BackupEntry> ListBackups()
    {
        var list = new List<BackupEntry>();
        try
        {
            if (!Directory.Exists(AppPaths.Backups)) return list;
            foreach (var dir in Directory.EnumerateDirectories(AppPaths.Backups))
            {
                var name = Path.GetFileName(dir);
                var info = new DirectoryInfo(dir);
                list.Add(new BackupEntry
                {
                    Id = name,
                    Label = name.StartsWith("auto-") ? "Automatic backup" : "Manual backup",
                    Timestamp = info.CreationTime,
                    Path = dir,
                    FileCount = Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories).Count(),
                    SizeBytes = DirectorySize(dir),
                    Auto = name.StartsWith("auto-")
                });
            }
        }
        catch (Exception ex) { _log.Debug("ListBackups failed: " + ex.Message); }
        return list.OrderByDescending(b => b.Timestamp).ToList();
    }

    /// <summary>Restore settings + profiles from a backup folder. Returns a human summary.</summary>
    public bool Restore(string backupId, out string message)
    {
        try
        {
            var dir = Path.Combine(AppPaths.Backups, backupId);
            if (!Directory.Exists(dir)) { message = "Backup not found."; return false; }

            int restored = 0;
            var settings = Path.Combine(dir, "settings.json");
            if (File.Exists(settings)) { File.Copy(settings, AppPaths.SettingsFile, true); restored++; }

            var profilesDir = Path.Combine(dir, "profiles");
            if (Directory.Exists(profilesDir))
            {
                Directory.CreateDirectory(AppPaths.Profiles);
                foreach (var f in Directory.EnumerateFiles(profilesDir, "*.json"))
                {
                    try { File.Copy(f, Path.Combine(AppPaths.Profiles, Path.GetFileName(f)), true); restored++; } catch { }
                }
            }

            message = $"Restored {restored} file(s) from backup {backupId}. Restart HPX PIRATE to apply.";
            _log.Info(message);
            return true;
        }
        catch (Exception ex)
        {
            message = "Restore failed: " + ex.Message;
            _log.Error("Restore failed.", ex);
            return false;
        }
    }

    /// <summary>Export a backup folder as a single .zip the user can move between machines.</summary>
    public bool ExportBundle(string backupId, string zipPath, out string message)
    {
        try
        {
            var dir = Path.Combine(AppPaths.Backups, backupId);
            if (!Directory.Exists(dir)) { message = "Backup not found."; return false; }
            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(dir, zipPath, CompressionLevel.Optimal, false);
            message = $"Exported to {zipPath}.";
            return true;
        }
        catch (Exception ex) { message = "Export failed: " + ex.Message; return false; }
    }

    /// <summary>Import a .zip bundle and restore it immediately.</summary>
    public bool ImportBundle(string zipPath, out string message)
    {
        try
        {
            if (!File.Exists(zipPath)) { message = "File not found."; return false; }
            var id = "import-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
            var dir = Path.Combine(AppPaths.Backups, id);
            Directory.CreateDirectory(dir);
            ZipFile.ExtractToDirectory(zipPath, dir, overwriteFiles: true);
            return Restore(id, out message);
        }
        catch (Exception ex) { message = "Import failed: " + ex.Message; return false; }
    }

    /// <summary>Validate a settings object against expected ranges (used before applying changes).</summary>
    public ValidationResult Validate(AppSettings s)
    {
        var r = new ValidationResult();
        if (s.MonitoringIntervalMs < 100 || s.MonitoringIntervalMs > 60000)
            r.Issues.Add($"Monitoring interval {s.MonitoringIntervalMs} ms is outside 100\u201360000 ms.");
        if (s.IdleMonitoringIntervalMs < 100 || s.IdleMonitoringIntervalMs > 60000)
            r.Issues.Add($"Idle monitoring interval {s.IdleMonitoringIntervalMs} ms is outside 100\u201360000 ms.");
        if (s.Mouse.HorizontalSensitivity <= 0 || s.Mouse.HorizontalSensitivity > 10)
            r.Issues.Add("Horizontal sensitivity must be between 0 and 10.");
        if (s.Mouse.VerticalSensitivity <= 0 || s.Mouse.VerticalSensitivity > 10)
            r.Issues.Add("Vertical sensitivity must be between 0 and 10.");
        if (s.Mouse.PollingRateHz < 125 || s.Mouse.PollingRateHz > 8000)
            r.Warnings.Add($"Polling rate {s.Mouse.PollingRateHz} Hz is unusual.");
        if (s.EasyDrag.MaxDragSpeed <= 0)
            r.Issues.Add("Max drag speed must be greater than 0.");
        if (s.Crosshair.Size < 1 || s.Crosshair.Size > 200)
            r.Warnings.Add("Crosshair size is outside the typical range.");
        return r;
    }

    /// <summary>Keep only the most recent N automatic backups to avoid unbounded growth.</summary>
    public void PruneAutoBackups(int keep = 10)
    {
        try
        {
            var autos = ListBackups().Where(b => b.Auto).OrderByDescending(b => b.Timestamp).Skip(keep);
            foreach (var b in autos)
            {
                try { Directory.Delete(b.Path, true); } catch { }
            }
        }
        catch (Exception ex) { _log.Debug("PruneAutoBackups failed: " + ex.Message); }
    }

    private static int CopyIfExists(string src, string dst)
    {
        try
        {
            if (!File.Exists(src)) return 0;
            File.Copy(src, dst, true);
            return 1;
        }
        catch { return 0; }
    }

    private static long DirectorySize(string dir)
    {
        try
        {
            return Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories)
                .Select(f => { try { return new FileInfo(f).Length; } catch { return 0L; } })
                .Sum();
        }
        catch { return 0; }
    }
}

using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// Sensitivity maths shared by the Sensitivity page, the Sensitivity Lab tool and the
/// response-curve preview. It reuses the same <see cref="Curves"/> engine the drag processors use,
/// so what you preview is exactly what gets applied.
/// </summary>
public sealed class SensitivityService
{
    private readonly ILogger _log;

    public SensitivityService(ILogger log) => _log = log;

    /// <summary>Evaluate a response curve at a normalised input 0..1.</summary>
    public double ApplyCurve(double normalized, ResponseCurve curve, double[]? custom = null)
        => Curves.Evaluate(curve, normalized, custom);

    /// <summary>Sample a curve for graphing (real evaluation, no interpolation shortcuts).</summary>
    public List<(double X, double Y)> CurvePoints(ResponseCurve curve, double[]? custom = null, int resolution = 41)
    {
        resolution = Math.Clamp(resolution, 5, 201);
        var pts = new List<(double, double)>(resolution);
        for (int i = 0; i < resolution; i++)
        {
            double x = i / (double)(resolution - 1);
            pts.Add((x, Curves.Evaluate(curve, x, custom)));
        }
        return pts;
    }

    /// <summary>Apply an Aim Feel preset to the live settings (writes into the settings object).</summary>
    public void ApplyAimFeel(AppSettings settings, AimFeel feel)
    {
        EasyDragEngine.ApplyAimFeel(settings.EasyDrag, feel);
        _log.Info($"Aim feel applied: {feel}.");
    }

    /// <summary>Apply an Easy Drag preset to the live settings.</summary>
    public void ApplyEasyDragPreset(AppSettings settings, EasyDragPreset preset)
    {
        EasyDragEngine.ApplyPreset(settings.EasyDrag, preset);
        _log.Info($"Easy Drag preset applied: {preset}.");
    }

    public SensitivityTestSession BeginTest(string mode) => new(mode);

    /// <summary>Human-readable description of what each curve does (shown next to the picker).</summary>
    public static string DescribeCurve(ResponseCurve curve) => curve switch
    {
        ResponseCurve.Linear => "1:1 \u2014 input maps directly to output. The most predictable feel.",
        ResponseCurve.Smooth => "Smoothstep \u2014 gentle acceleration then deceleration. Balanced and natural.",
        ResponseCurve.FastStart => "Ease-out \u2014 quick initial response that settles. Good for flick-heavy play.",
        ResponseCurve.SlowStart => "Ease-in \u2014 slow initial response that ramps up. Good for precision.",
        ResponseCurve.Precision => "Power curve \u2014 fine control at low speeds, full speed at high speeds.",
        ResponseCurve.Custom => "Your own curve defined by control points.",
        _ => ""
    };
}

/// <summary>
/// Records one real drag/tap gesture and derives honest statistics from the sampled points.
/// The UI feeds raw cursor coordinates; this class does the rest.
/// </summary>
public sealed class SensitivityTestSession
{
    private readonly string _mode;
    private readonly List<(double X, double Y, double T)> _pts = new();
    private double _firstMoveTime = -1;

    public SensitivityTestSession(string mode) => _mode = mode;

    public int SampleCount => _pts.Count;
    public bool HasData => _pts.Count >= 2;

    public void Feed(double x, double y, double timeMs)
    {
        if (_pts.Count > 0)
        {
            var last = _pts[^1];
            double step = Math.Sqrt((x - last.X) * (x - last.X) + (y - last.Y) * (y - last.Y));
            if (step > 1.0 && _firstMoveTime < 0) _firstMoveTime = timeMs;
        }
        _pts.Add((x, y, timeMs));
        if (_pts.Count > 5000) _pts.RemoveAt(0);
    }

    public SensitivityTestResult Complete()
    {
        var result = new SensitivityTestResult { Mode = _mode, SampleCount = _pts.Count };
        if (!HasData) return result;

        double distance = 0;
        var speeds = new List<double>();
        for (int i = 1; i < _pts.Count; i++)
        {
            var a = _pts[i - 1];
            var b = _pts[i];
            double d = Math.Sqrt((b.X - a.X) * (b.X - a.X) + (b.Y - a.Y) * (b.Y - a.Y));
            distance += d;
            double dt = (b.T - a.T) / 1000.0;
            if (dt > 0) speeds.Add(d / dt);
        }

        double durationMs = _pts[^1].T - _pts[0].T;
        result.DistancePx = distance;
        result.DurationMs = durationMs;
        result.SpeedPxPerSec = durationMs > 0 ? distance / (durationMs / 1000.0) : 0;
        result.LatencyMs = _firstMoveTime >= 0 ? _firstMoveTime - _pts[0].T : 0;

        // Acceleration: mean absolute change of speed between consecutive segments.
        if (speeds.Count >= 2)
        {
            double accelSum = 0;
            for (int i = 1; i < speeds.Count; i++) accelSum += Math.Abs(speeds[i] - speeds[i - 1]);
            result.Acceleration = accelSum / (speeds.Count - 1);
        }

        // Consistency: 100 minus the coefficient of variation of segment speeds.
        if (speeds.Count >= 3)
        {
            double avg = speeds.Average();
            if (avg > 0)
            {
                double variance = speeds.Sum(s => (s - avg) * (s - avg)) / (speeds.Count - 1);
                double cv = Math.Sqrt(variance) / avg;
                result.Consistency = Math.Clamp(100 - cv * 100, 0, 100);
            }
        }

        return result;
    }
}

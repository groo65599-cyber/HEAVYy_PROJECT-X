using HPXPirate.Interop;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// Reads real XInput controller state. It probes the three XInput runtimes in order and, if
/// none can be loaded, reports IsSupported=false so the UI can honestly show
/// "NOT SUPPORTED ON THIS SYSTEM" instead of a dead panel.
/// </summary>
public sealed class ControllerService
{
    private readonly ILogger _log;
    private enum Runtime { None, V14, V13, V910 }
    private Runtime _runtime = Runtime.None;
    private bool _probed;

    public bool IsSupported { get; private set; }
    public bool IsConnected { get; private set; }
    public int ConnectedIndex { get; private set; } = -1;
    public string RuntimeName { get; private set; } = "Unavailable";

    public ControllerService(ILogger log) => _log = log;

    /// <summary>Probe once which XInput runtime (if any) is present.</summary>
    public bool Probe()
    {
        if (_probed) return IsSupported;
        _probed = true;

        // Try each runtime by making a harmless call. DllNotFoundException => not present.
        foreach (var rt in new[] { Runtime.V14, Runtime.V13, Runtime.V910 })
        {
            try
            {
                var state = new XInputInterop.XINPUT_STATE();
                _ = GetStateRaw(rt, 0, ref state);
                _runtime = rt;
                IsSupported = true;
                RuntimeName = rt switch
                {
                    Runtime.V14 => "XInput 1.4",
                    Runtime.V13 => "XInput 1.3",
                    _ => "XInput 9.1.0"
                };
                _log.Info($"Controller support: {RuntimeName}.");
                return true;
            }
            catch (DllNotFoundException)
            {
                // try next runtime
            }
            catch (Exception ex)
            {
                _log.Debug($"XInput probe ({rt}) failed: {ex.Message}");
            }
        }

        IsSupported = false;
        RuntimeName = "Unavailable";
        _log.Warn("XInput runtime not available \u2014 controller features will report NOT SUPPORTED.");
        return false;
    }

    private uint GetStateRaw(Runtime rt, uint index, ref XInputInterop.XINPUT_STATE state)
        => rt switch
        {
            Runtime.V14 => XInputInterop.XInputGetState14(index, ref state),
            Runtime.V13 => XInputInterop.XInputGetState13(index, ref state),
            _ => XInputInterop.XInputGetState910(index, ref state)
        };

    /// <summary>Read the first connected controller's live state (or a disconnected snapshot).</summary>
    public ControllerState Read()
    {
        var result = new ControllerState();
        if (!Probe())
        {
            return result; // Connected=false
        }

        for (uint i = 0; i < 4; i++)
        {
            try
            {
                var raw = new XInputInterop.XINPUT_STATE();
                uint code = GetStateRaw(_runtime, i, ref raw);
                if (code == XInputInterop.ERROR_SUCCESS)
                {
                    result.Connected = true;
                    result.UserIndex = (int)i;
                    result.Buttons = raw.Gamepad.wButtons;
                    result.LeftTrigger = raw.Gamepad.bLeftTrigger;
                    result.RightTrigger = raw.Gamepad.bRightTrigger;
                    result.LeftThumbX = raw.Gamepad.sThumbLX;
                    result.LeftThumbY = raw.Gamepad.sThumbLY;
                    result.RightThumbX = raw.Gamepad.sThumbRX;
                    result.RightThumbY = raw.Gamepad.sThumbRY;
                    result.PressedButtons = DescribeButtons(raw.Gamepad.wButtons);
                    IsConnected = true;
                    ConnectedIndex = (int)i;
                    return result;
                }
            }
            catch (Exception ex)
            {
                _log.Debug("XInputGetState failed: " + ex.Message);
                break;
            }
        }

        IsConnected = false;
        ConnectedIndex = -1;
        return result;
    }

    /// <summary>Probe all four slots for a quick connection summary.</summary>
    public List<ControllerProbe> ProbeAll()
    {
        var list = new List<ControllerProbe>();
        if (!Probe()) return list;

        for (uint i = 0; i < 4; i++)
        {
            var probe = new ControllerProbe { UserIndex = (int)i };
            try
            {
                var raw = new XInputInterop.XINPUT_STATE();
                uint code = GetStateRaw(_runtime, i, ref raw);
                probe.Connected = code == XInputInterop.ERROR_SUCCESS;
                probe.PacketNumber = raw.dwPacketNumber;
            }
            catch { }
            list.Add(probe);
        }
        return list;
    }

    public static List<string> DescribeButtons(ushort buttons)
    {
        var names = new List<string>();
        void Add(ushort bit, string name) { if ((buttons & bit) != 0) names.Add(name); }
        Add(XInputInterop.XINPUT_GAMEPAD_A, "A");
        Add(XInputInterop.XINPUT_GAMEPAD_B, "B");
        Add(XInputInterop.XINPUT_GAMEPAD_X, "X");
        Add(XInputInterop.XINPUT_GAMEPAD_Y, "Y");
        Add(XInputInterop.XINPUT_GAMEPAD_DPAD_UP, "D-Up");
        Add(XInputInterop.XINPUT_GAMEPAD_DPAD_DOWN, "D-Down");
        Add(XInputInterop.XINPUT_GAMEPAD_DPAD_LEFT, "D-Left");
        Add(XInputInterop.XINPUT_GAMEPAD_DPAD_RIGHT, "D-Right");
        Add(XInputInterop.XINPUT_GAMEPAD_LEFT_SHOULDER, "LB");
        Add(XInputInterop.XINPUT_GAMEPAD_RIGHT_SHOULDER, "RB");
        Add(XInputInterop.XINPUT_GAMEPAD_LEFT_THUMB, "LS");
        Add(XInputInterop.XINPUT_GAMEPAD_RIGHT_THUMB, "RS");
        Add(XInputInterop.XINPUT_GAMEPAD_START, "Start");
        Add(XInputInterop.XINPUT_GAMEPAD_BACK, "Back");
        return names;
    }
}

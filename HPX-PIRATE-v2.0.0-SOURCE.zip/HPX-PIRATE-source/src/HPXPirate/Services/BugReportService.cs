using System.IO;
using System.IO.Compression;
using System.Text;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// Builds a real diagnostic bundle for bug reports: system info, the latest health-check results,
/// recent logs and the (non-sensitive) settings. Nothing is uploaded anywhere \u2014 the user gets a
/// .zip they can inspect and choose to share.
/// </summary>
public sealed class BugReportService
{
    private readonly ILogger _log;
    private readonly AppHost _host;
    private readonly DiagnosticsService _diagnostics;

    public BugReportService(ILogger log, AppHost host, DiagnosticsService diagnostics)
    {
        _log = log;
        _host = host;
        _diagnostics = diagnostics;
    }

    public BugReport Create(string title, string description, string category, string email = "")
    {
        var report = new BugReport
        {
            Title = string.IsNullOrWhiteSpace(title) ? "Untitled report" : title,
            Description = description,
            Category = category,
            ContactEmail = email,
            OsVersion = Environment.OSVersion.VersionString,
            Platform = Environment.OSVersion.Platform.ToString(),
            DotNetVersion = Environment.Version.ToString(),
            AppVersion = "1.0.0"
        };

        try
        {
            var hw = _host.FpsBoost.DetectHardware();
            report.HardwareSummary =
                $"CPU cores: {hw.CpuCores} / threads: {hw.CpuThreads}  \u00b7  " +
                $"RAM: {hw.RamTotalGb:0.0} GB  \u00b7  GPU: {(string.IsNullOrWhiteSpace(hw.GpuName) ? "unknown" : hw.GpuName)}  \u00b7  " +
                $"VRAM: {hw.VramTotalGb:0.0} GB";
        }
        catch (Exception ex) { report.HardwareSummary = "unavailable (" + ex.Message + ")"; }

        try
        {
            var diag = _diagnostics.RunFullCheck();
            report.DiagnosticVerdict = diag.Verdict;
            report.HealthScore = diag.HealthScore;
            report.Checks = diag.Checks;
        }
        catch (Exception ex) { report.DiagnosticVerdict = "unavailable (" + ex.Message + ")"; }

        try { report.SettingsJson = JsonHelper.Serialize(_host.AppSettings); } catch { }

        report.LogLines = _host.Logger.Recent
            .TakeLast(200)
            .Select(e => $"{e.Timestamp:HH:mm:ss} [{e.Level}] {e.Message}")
            .ToList();

        _log.Info($"Bug report bundle prepared: {report.Id}.");
        return report;
    }

    /// <summary>Write the report as a .zip (report.txt + report.json + logs.txt + settings.json).</summary>
    public bool ExportBundle(BugReport report, string zipPath, out string message)
    {
        try
        {
            var temp = Path.Combine(Path.GetTempPath(), "hpx-report-" + report.Id);
            if (Directory.Exists(temp)) Directory.Delete(temp, true);
            Directory.CreateDirectory(temp);

            File.WriteAllText(Path.Combine(temp, "report.txt"), BuildText(report), Encoding.UTF8);
            File.WriteAllText(Path.Combine(temp, "report.json"), JsonHelper.Serialize(report), Encoding.UTF8);
            File.WriteAllText(Path.Combine(temp, "logs.txt"), string.Join(Environment.NewLine, report.LogLines), Encoding.UTF8);
            File.WriteAllText(Path.Combine(temp, "settings.json"), report.SettingsJson, Encoding.UTF8);

            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(temp, zipPath, CompressionLevel.Optimal, false);
            try { Directory.Delete(temp, true); } catch { }

            message = $"Bundle written to {zipPath}.";
            return true;
        }
        catch (Exception ex)
        {
            message = "Export failed: " + ex.Message;
            _log.Error("Bug report export failed.", ex);
            return false;
        }
    }

    public string BuildText(BugReport r)
    {
        var sb = new StringBuilder();
        sb.AppendLine("HPX PIRATE \u2014 Diagnostic Bug Report");
        sb.AppendLine("====================================");
        sb.AppendLine($"Report ID : {r.Id}");
        sb.AppendLine($"Timestamp : {r.Timestamp:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine($"Category  : {r.Category}");
        sb.AppendLine($"Title     : {r.Title}");
        sb.AppendLine($"Contact   : {(string.IsNullOrWhiteSpace(r.ContactEmail) ? "(not provided)" : r.ContactEmail)}");
        sb.AppendLine();
        sb.AppendLine("Description");
        sb.AppendLine("-----------");
        sb.AppendLine(string.IsNullOrWhiteSpace(r.Description) ? "(none)" : r.Description);
        sb.AppendLine();
        sb.AppendLine("Environment");
        sb.AppendLine("-----------");
        sb.AppendLine($"App version : {r.AppVersion}");
        sb.AppendLine($"OS          : {r.OsVersion}");
        sb.AppendLine($"Platform    : {r.Platform}");
        sb.AppendLine($".NET        : {r.DotNetVersion}");
        sb.AppendLine($"Hardware    : {r.HardwareSummary}");
        sb.AppendLine();
        sb.AppendLine("Health Check");
        sb.AppendLine("------------");
        sb.AppendLine($"Verdict : {r.DiagnosticVerdict} (health {r.HealthScore}/100)");
        foreach (var c in r.Checks)
            sb.AppendLine($"  [{c.StatusLabel,-13}] {c.Name}: {c.Summary}");
        sb.AppendLine();
        sb.AppendLine("Recent Log");
        sb.AppendLine("----------");
        foreach (var l in r.LogLines) sb.AppendLine(l);
        return sb.ToString();
    }
}

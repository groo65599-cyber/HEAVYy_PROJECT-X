using System.IO;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// The HPX PIRATE Toolbox catalogue. Every tool listed here has a real, working view behind it
/// (see <see cref="ToolDefinition.ViewKey"/>). Favorites and recent ordering are persisted so the
/// toolbox remembers how you work. There are no placeholder tools.
/// </summary>
public sealed class ToolRegistry
{
    private readonly ILogger _log;
    private readonly List<ToolDefinition> _tools = new();
    private ToolboxState _state = new();

    public ToolRegistry(ILogger log)
    {
        _log = log;
        BuildCatalogue();
        Load();
        Apply();
    }

    public IReadOnlyList<ToolDefinition> All => _tools;

    public IEnumerable<ToolDefinition> Favorites => _tools.Where(t => t.Favorite).OrderBy(t => t.Name);

    public IEnumerable<ToolDefinition> Recent
    {
        get
        {
            var order = _state.Recent;
            return _tools.Where(t => order.Contains(t.Id))
                         .OrderBy(t => order.IndexOf(t.Id));
        }
    }

    public IEnumerable<string> Categories => _tools.Select(t => t.Category).Distinct().OrderBy(c => c);

    public ToolDefinition? Get(string id) => _tools.FirstOrDefault(t => t.Id == id);

    public IEnumerable<ToolDefinition> Search(string? query)
    {
        if (string.IsNullOrWhiteSpace(query)) return _tools.OrderBy(t => t.Tier).ThenBy(t => t.Name);
        var q = query.Trim().ToLowerInvariant();
        return _tools.Where(t =>
                t.Name.ToLowerInvariant().Contains(q) ||
                t.Description.ToLowerInvariant().Contains(q) ||
                t.Category.ToLowerInvariant().Contains(q))
            .OrderBy(t => t.Tier).ThenBy(t => t.Name);
    }

    public void ToggleFavorite(string id)
    {
        var t = Get(id);
        if (t is null) return;
        t.Favorite = !t.Favorite;
        if (t.Favorite) { if (!_state.Favorites.Contains(id)) _state.Favorites.Add(id); }
        else _state.Favorites.Remove(id);
        Save();
    }

    public void MarkRecent(string id)
    {
        _state.Recent.Remove(id);
        _state.Recent.Insert(0, id);
        while (_state.Recent.Count > 12) _state.Recent.RemoveAt(_state.Recent.Count - 1);
        Save();
    }

    private void BuildCatalogue()
    {
        void Add(string id, string name, string desc, string icon, string cat, ToolTier tier, string viewKey,
            ToolReadiness readiness = ToolReadiness.Functional)
            => _tools.Add(new ToolDefinition
            {
                Id = id, Name = name, Description = desc, Icon = icon,
                Category = cat, Tier = tier, ViewKey = viewKey, Readiness = readiness
            });

        // --- Input ---
        Add("input-tester", "Input Tester", "Live keyboard, mouse and controller monitor with real event timing.", "\uE7C9", "Input", ToolTier.Core, "tool.inputtester");
        Add("latency-analyzer", "Latency Analyzer", "Measure real stimulus-to-input response latency with statistics.", "\uE916", "Input", ToolTier.Core, "tool.latency");
        Add("calibration", "Calibration", "Estimate mouse polling rate and detect deadzone/jitter from live movement.", "\uE9E9", "Input", ToolTier.Advanced, "tool.calibration");
        Add("input-recorder", "Input Recorder", "Record input events and export them to CSV/JSON for analysis.", "\uE7C8", "Input", ToolTier.Advanced, "tool.recorder");

        // --- Mapping ---
        Add("mapping-tester", "Mapping Tester", "Press any key and see exactly which action your profile maps it to.", "\uE71B", "Mapping", ToolTier.Core, "tool.mappingtester");
        Add("profile-converter", "Profile Converter", "Import, export and convert game profiles between formats.", "\uE8B7", "Mapping", ToolTier.Core, "tool.profileconverter");

        // --- Sensitivity ---
        Add("sensitivity-lab", "Sensitivity Lab", "Run a drag test and compare response curves with real measurements.", "\uE9D9", "Sensitivity", ToolTier.Core, "tool.sensitivitylab");
        Add("response-curve", "Response Curve", "Visualise and tune the input response curve applied to your mouse.", "\uE9D2", "Sensitivity", ToolTier.Core, "tool.responsecurve");

        // --- Performance ---
        Add("frame-analyzer", "Frame Analyzer", "Inspect live frame times, 1% lows and frame spikes.", "\uE9D9", "Performance", ToolTier.Core, "tool.frameanalyzer");
        Add("fps-boost", "Ultra FPS Boost", "Measured boost engine: baseline, apply, measure, keep or roll back.", "\uE945", "Performance", ToolTier.Core, "ultraboost");

        // --- System ---
        Add("config-backup", "Configuration Backup", "Snapshot and restore settings, profiles and keymapping.", "\uE753", "System", ToolTier.Core, "tool.backup");
        Add("diagnostics", "Diagnostics", "Run real health checks across every subsystem. Fix only what is broken.", "\uE9D9", "System", ToolTier.Core, "diagnostics");

        // --- Overlay ---
        Add("overlay-studio", "Overlay Studio", "Design the crosshair and on-screen overlay with a live preview.", "\uE7F4", "Overlay", ToolTier.Advanced, "tool.overlaystudio");
    }

    private void Apply()
    {
        foreach (var t in _tools)
            t.Favorite = _state.Favorites.Contains(t.Id);
    }

    private string StateFile => Path.Combine(AppPaths.Root, "toolbox.json");

    private void Load()
    {
        try
        {
            if (File.Exists(StateFile))
                _state = JsonHelper.Deserialize<ToolboxState>(File.ReadAllText(StateFile)) ?? new ToolboxState();
        }
        catch (Exception ex) { _log.Debug("Toolbox load failed: " + ex.Message); }
    }

    private void Save()
    {
        try
        {
            AppPaths.EnsureCreated();
            File.WriteAllText(StateFile, JsonHelper.Serialize(_state));
        }
        catch (Exception ex) { _log.Debug("Toolbox save failed: " + ex.Message); }
    }
}

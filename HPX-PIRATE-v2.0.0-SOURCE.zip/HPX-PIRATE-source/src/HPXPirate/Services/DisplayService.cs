using HPXPirate.Interop;
using HPXPirate.Models;

namespace HPXPirate.Services;

/// <summary>
/// Reads the real display mode (resolution + refresh rate) from the OS and enumerates the
/// supported modes so the FPS Boost engine can warn when the panel is capped below its maximum.
/// If the OS refuses to report a mode we return Available=false \u2014 never a fabricated number.
/// </summary>
public sealed class DisplayService
{
    private readonly ILogger _log;
    private DisplayInfo? _cached;

    public DisplayService(ILogger log) => _log = log;

    public DisplayInfo GetDisplayInfo(bool forceRefresh = false)
    {
        if (!forceRefresh && _cached is { Available: true }) return _cached;

        var info = new DisplayInfo();
        try
        {
            var dm = new DisplayInterop.DEVMODE
            {
                dmDeviceName = "",
                dmFormName = "",
                dmSize = (ushort)System.Runtime.InteropServices.Marshal.SizeOf<DisplayInterop.DEVMODE>()
            };

            if (DisplayInterop.EnumDisplaySettings(null, DisplayInterop.ENUM_CURRENT_SETTINGS, ref dm))
            {
                info.Width = (int)dm.dmPelsWidth;
                info.Height = (int)dm.dmPelsHeight;
                info.CurrentRefreshHz = (int)dm.dmDisplayFrequency;
                info.Available = info.Width > 0 && info.Height > 0;
                info.MaxRefreshHz = FindMaxRefresh(dm.dmPelsWidth, dm.dmPelsHeight, info.CurrentRefreshHz);
                // VRR (FreeSync/G-Sync) is not directly exposed by EnumDisplaySettings; we only
                // claim it when the panel reports a max above the current mode (a strong hint).
                info.VrrSupported = info.MaxRefreshHz > info.CurrentRefreshHz;
            }

            if (!info.Available)
            {
                // Fall back to raw screen metrics so at least the resolution is honest.
                int w = NativeMethods.GetSystemMetrics(NativeMethods.SM_CXSCREEN);
                int h = NativeMethods.GetSystemMetrics(NativeMethods.SM_CYSCREEN);
                if (w > 0 && h > 0)
                {
                    info.Width = w;
                    info.Height = h;
                    info.Available = true; // resolution known, refresh unknown
                    info.CurrentRefreshHz = 0;
                    info.MaxRefreshHz = 0;
                }
            }
        }
        catch (Exception ex)
        {
            _log.Debug("Display detection failed: " + ex.Message);
            info.Available = false;
        }

        _cached = info;
        return info;
    }

    /// <summary>Enumerate every mode the adapter exposes and keep the highest Hz for this resolution.</summary>
    private int FindMaxRefresh(uint width, uint height, int fallback)
    {
        int max = fallback;
        try
        {
            var dm = new DisplayInterop.DEVMODE
            {
                dmDeviceName = "",
                dmFormName = "",
                dmSize = (ushort)System.Runtime.InteropServices.Marshal.SizeOf<DisplayInterop.DEVMODE>()
            };

            for (int i = 0; i < 512; i++)
            {
                if (!DisplayInterop.EnumDisplaySettings(null, i, ref dm)) break;
                if (dm.dmPelsWidth != width || dm.dmPelsHeight != height) continue;
                if ((dm.dmFields & DisplayInterop.DM_DISPLAYFREQUENCY) == 0) continue;
                int hz = (int)dm.dmDisplayFrequency;
                if (hz > max && hz <= 1000) max = hz;
            }
        }
        catch { /* keep fallback */ }
        return max;
    }
}

namespace HPXPirate.Models;

/// <summary>Performance modes for the FPS Boost engine.</summary>
public enum BoostMode { Balanced, HighFps, UltraFps, Competitive, Custom }

/// <summary>Which component is the limiting factor. Never guessed — derived from measurements.</summary>
public enum BottleneckKind
{
    Unknown,
    CpuLimited,
    GpuLimited,
    MemoryLimited,
    ThermalLimited,
    GameLimited,
    DisplayLimited,
    FpsCapLimited,
    NotEnoughData
}

/// <summary>Display capability read from the OS.</summary>
public sealed class DisplayInfo
{
    public int CurrentRefreshHz { get; set; }
    public int MaxRefreshHz { get; set; }
    public bool VrrSupported { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public bool Available { get; set; }

    public string Summary => Available
        ? $"{Width}x{Height} @ {CurrentRefreshHz} Hz (max {MaxRefreshHz} Hz)"
        : "DISPLAY DATA NOT AVAILABLE";
}

/// <summary>Hardware capability snapshot used by the pre-check.</summary>
public sealed class HardwareCapability
{
    public string CpuName { get; set; } = "";
    public string GpuName { get; set; } = "";
    public int CpuCores { get; set; }
    public int CpuThreads { get; set; }
    public double RamTotalGb { get; set; }
    public double VramTotalGb { get; set; }
    public bool CpuAvailable { get; set; }
    public bool GpuAvailable { get; set; }
    public bool RamAvailable { get; set; }
}

/// <summary>A measured baseline / post-boost performance sample. All values are real measurements.</summary>
public sealed class PerformanceSample
{
    public DateTime Timestamp { get; set; } = DateTime.Now;
    public string Label { get; set; } = "";
    public double AverageFps { get; set; }
    public double OnePercentLow { get; set; }
    public double PointOnePercentLow { get; set; }
    public double FrameTimeMs { get; set; }
    public double FrameTimeVariance { get; set; }
    public double CpuPercent { get; set; }
    public double GpuPercent { get; set; }
    public double RamPercent { get; set; }
    public double InputLatencyMs { get; set; }
    public int SampleCount { get; set; }

    public bool HasData => SampleCount > 0 && AverageFps > 0;

    /// <summary>Frame-time stability 0..100 derived from variance (real data only).</summary>
    public double Stability
    {
        get
        {
            if (!HasData || FrameTimeMs <= 0) return 0;
            double ratio = FrameTimeVariance / FrameTimeMs; // coefficient of variation
            double score = 100 - ratio * 100;
            return Math.Clamp(score, 0, 100);
        }
    }

    public string StabilityLabel => !HasData ? "NO DATA"
        : Stability >= 90 ? "STABLE"
        : Stability >= 75 ? "MINOR FRAME SPIKES"
        : "HIGH FRAME VARIANCE";
}

/// <summary>A single actionable item in the boost plan. Shown to the user before applying.</summary>
public sealed class BoostPlanItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = "";
    public string Explanation { get; set; } = "";
    public string Category { get; set; } = "";
    public ActionRisk Risk { get; set; } = ActionRisk.Safe;
    public bool Selected { get; set; } = true;
    public bool Reversible { get; set; } = true;

    /// <summary>Set only after the item is actually applied.</summary>
    public bool Applied { get; set; }
    public bool Succeeded { get; set; }
    public string ResultMessage { get; set; } = "";
}

/// <summary>The full boost plan produced after analysis, shown before any change is made.</summary>
public sealed class BoostPlan
{
    public BoostMode Mode { get; set; } = BoostMode.Balanced;
    public int TargetFps { get; set; }
    public bool TargetAuto { get; set; } = true;
    public BottleneckKind Bottleneck { get; set; } = BottleneckKind.Unknown;
    public string BottleneckDetail { get; set; } = "";
    public List<BoostPlanItem> Items { get; set; } = new();
    public List<string> Findings { get; set; } = new();
    public List<string> Recommendations { get; set; } = new();
    public int ReadinessScore { get; set; }
    public string ReadinessLabel { get; set; } = "";
    public DisplayInfo? Display { get; set; }
    public bool CanReachTarget { get; set; }
    public string TargetNote { get; set; } = "";
}

/// <summary>Before/after comparison. The engine only KEEPS changes that measurably help.</summary>
public sealed class BoostComparison
{
    public PerformanceSample? Baseline { get; set; }
    public PerformanceSample? After { get; set; }

    public bool HasBoth => Baseline?.HasData == true && After?.HasData == true;

    public double FpsDelta => HasBoth ? After!.AverageFps - Baseline!.AverageFps : 0;
    public double FrameTimeDelta => HasBoth ? After!.FrameTimeMs - Baseline!.FrameTimeMs : 0;
    public double LatencyDelta => HasBoth ? After!.InputLatencyMs - Baseline!.InputLatencyMs : 0;
    public double StabilityDelta => HasBoth ? After!.Stability - Baseline!.Stability : 0;

    public bool Improved => HasBoth && FpsDelta > 1.0;
    public bool Regressed => HasBoth && FpsDelta < -1.0;

    public string Verdict => !HasBoth
        ? "MEASUREMENT INCOMPLETE"
        : Improved ? "IMPROVED"
        : Regressed ? "REGRESSED"
        : "NO SIGNIFICANT CHANGE";

    public string Recommendation => !HasBoth
        ? "Run both a baseline and a post-boost measurement."
        : Improved ? "Keep the applied optimizations."
        : Regressed ? "Roll back — performance became worse."
        : "No measurable gain. Optimization rolled back to preserve your configuration.";
}

/// <summary>A recorded FPS drop event with real context captured at the moment it happened.</summary>
public sealed class FpsDropEvent
{
    public DateTime Timestamp { get; set; } = DateTime.Now;
    public double FpsBefore { get; set; }
    public double FpsAfter { get; set; }
    public double FrameTimeMs { get; set; }
    public double CpuPercent { get; set; }
    public double GpuPercent { get; set; }
    public double RamPercent { get; set; }
    public string ActiveProcess { get; set; } = "";
    public string PotentialCause { get; set; } = "";

    public double Drop => FpsBefore - FpsAfter;
    public string Summary => $"{Timestamp:HH:mm:ss}  FPS {FpsBefore:0} \u2192 {FpsAfter:0}  ({PotentialCause})";
}

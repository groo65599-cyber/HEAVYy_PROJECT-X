namespace HPXPirate.Models;

/// <summary>A diagnostic bundle the user can review and attach to a bug report.</summary>
public sealed class BugReport
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public DateTime Timestamp { get; set; } = DateTime.Now;
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "General";
    public string ContactEmail { get; set; } = "";

    public string AppVersion { get; set; } = "1.0.0";
    public string OsVersion { get; set; } = "";
    public string Platform { get; set; } = "";
    public string DotNetVersion { get; set; } = "";
    public string HardwareSummary { get; set; } = "";

    public string DiagnosticVerdict { get; set; } = "";
    public int HealthScore { get; set; }
    public List<DiagnosticCheck> Checks { get; set; } = new();
    public List<string> LogLines { get; set; } = new();
    public string SettingsJson { get; set; } = "";

    public string Summary => $"[{Id}] {Title} \u2014 {Category} \u2014 {Timestamp:yyyy-MM-dd HH:mm}";
}

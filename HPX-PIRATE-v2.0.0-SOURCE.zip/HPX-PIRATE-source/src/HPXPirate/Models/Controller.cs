namespace HPXPirate.Models;

/// <summary>A real snapshot of an XInput controller at one instant.</summary>
public sealed class ControllerState
{
    public bool Connected { get; set; }
    public int UserIndex { get; set; }
    public ushort Buttons { get; set; }
    public byte LeftTrigger { get; set; }
    public byte RightTrigger { get; set; }
    public short LeftThumbX { get; set; }
    public short LeftThumbY { get; set; }
    public short RightThumbX { get; set; }
    public short RightThumbY { get; set; }
    public List<string> PressedButtons { get; set; } = new();

    public double LeftThumbMagnitude
    {
        get
        {
            double x = LeftThumbX / 32767.0, y = LeftThumbY / 32767.0;
            return Math.Clamp(Math.Sqrt(x * x + y * y), 0, 1);
        }
    }

    public double RightThumbMagnitude
    {
        get
        {
            double x = RightThumbX / 32767.0, y = RightThumbY / 32767.0;
            return Math.Clamp(Math.Sqrt(x * x + y * y), 0, 1);
        }
    }

    public double LeftTriggerNormalized => LeftTrigger / 255.0;
    public double RightTriggerNormalized => RightTrigger / 255.0;

    public string Summary => !Connected
        ? "No controller connected."
        : $"Buttons: {(PressedButtons.Count == 0 ? "none" : string.Join(", ", PressedButtons))}  \u00b7  LT {LeftTrigger}  RT {RightTrigger}";
}

/// <summary>Result of probing a single XInput slot.</summary>
public sealed class ControllerProbe
{
    public int UserIndex { get; set; }
    public bool Connected { get; set; }
    public uint PacketNumber { get; set; }
}

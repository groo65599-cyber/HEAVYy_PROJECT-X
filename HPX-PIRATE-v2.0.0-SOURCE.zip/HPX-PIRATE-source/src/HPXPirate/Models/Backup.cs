namespace HPXPirate.Models;

/// <summary>A single point-in-time backup of the user's configuration.</summary>
public sealed class BackupEntry
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public DateTime Timestamp { get; set; } = DateTime.Now;
    public string Path { get; set; } = "";
    public long SizeBytes { get; set; }
    public int FileCount { get; set; }
    public bool Auto { get; set; }

    public string Summary => $"{Timestamp:yyyy-MM-dd HH:mm:ss}  \u00b7  {FileCount} file(s)  \u00b7  {SizeBytes / 1024.0:0.0} KB";
    public string Display => string.IsNullOrWhiteSpace(Label) ? Timestamp.ToString("yyyy-MM-dd HH:mm:ss") : Label;
}

/// <summary>Result of validating a settings file.</summary>
public sealed class ValidationResult
{
    public bool IsValid => Issues.Count == 0;
    public List<string> Issues { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    public string Summary => IsValid
        ? (Warnings.Count == 0 ? "Configuration is valid." : $"Valid with {Warnings.Count} warning(s).")
        : $"{Issues.Count} issue(s) found.";
}

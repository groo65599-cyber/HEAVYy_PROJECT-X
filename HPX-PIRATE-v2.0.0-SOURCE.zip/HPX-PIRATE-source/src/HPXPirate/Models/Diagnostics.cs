namespace HPXPirate.Models;

/// <summary>
/// Outcome of a single diagnostic check. "NotSupported" is a first-class state so the UI can
/// honestly show "NOT SUPPORTED / NOT AVAILABLE ON THIS SYSTEM" instead of faking a pass.
/// </summary>
public enum CheckStatus
{
    Ok,          // working / healthy
    Warning,     // usable but attention recommended
    Error,       // broken, action required
    NotSupported // platform/API unavailable — never counted as a failure
}

public enum DiagnosticCategory
{
    Input,
    Mapping,
    Profile,
    Performance,
    Overlay,
    Permissions,
    Compatibility,
    Configuration
}

/// <summary>A single, evidence-backed diagnostic result.</summary>
public sealed class DiagnosticCheck
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    public DiagnosticCategory Category { get; set; } = DiagnosticCategory.Input;
    public CheckStatus Status { get; set; } = CheckStatus.Ok;

    /// <summary>Short human-readable result, e.g. "Input hooks installed".</summary>
    public string Summary { get; set; } = "";

    /// <summary>Why the status is what it is (cause). Empty for a plain OK.</summary>
    public string Cause { get; set; } = "";

    /// <summary>What the user can do about it. Empty when no action is needed.</summary>
    public string RecommendedAction { get; set; } = "";

    /// <summary>True when HPX can safely apply a fix for this specific finding.</summary>
    public bool CanAutoFix { get; set; }

    /// <summary>Identifier the optimizer uses to apply the matching fix (when CanAutoFix).</summary>
    public string? FixActionId { get; set; }

    /// <summary>Raw evidence captured during the check (kept for the diagnostics log).</summary>
    public string Evidence { get; set; } = "";

    public DateTime Timestamp { get; set; } = DateTime.Now;

    public string StatusGlyph => Status switch
    {
        CheckStatus.Ok => "\u2713",
        CheckStatus.Warning => "\u26A0",
        CheckStatus.Error => "\u2715",
        _ => "\u2014"
    };

    public string StatusLabel => Status switch
    {
        CheckStatus.Ok => "WORKING",
        CheckStatus.Warning => "WARNING",
        CheckStatus.Error => "ERROR",
        _ => "NOT SUPPORTED"
    };
}

/// <summary>The full result of a health check run.</summary>
public sealed class DiagnosticReport
{
    public DateTime Timestamp { get; set; } = DateTime.Now;
    public List<DiagnosticCheck> Checks { get; set; } = new();

    public int OkCount => Checks.Count(c => c.Status == CheckStatus.Ok);
    public int WarningCount => Checks.Count(c => c.Status == CheckStatus.Warning);
    public int ErrorCount => Checks.Count(c => c.Status == CheckStatus.Error);
    public int NotSupportedCount => Checks.Count(c => c.Status == CheckStatus.NotSupported);

    /// <summary>
    /// The headline verdict. This is the crux of "FIX ONLY WHAT IS BROKEN": when nothing is
    /// wrong we say so explicitly instead of inventing work to do.
    /// </summary>
    public bool HasIssues => ErrorCount > 0 || WarningCount > 0;

    public string Verdict => !HasIssues
        ? "NO ISSUE DETECTED"
        : (ErrorCount > 0 ? "ISSUE DETECTED" : "ATTENTION RECOMMENDED");

    public string VerdictDetail => !HasIssues
        ? "Current configuration will be preserved."
        : $"{ErrorCount} error(s), {WarningCount} warning(s) found. Review the recommended fixes below.";

    /// <summary>Overall health 0..100 derived from real check results (never a random number).</summary>
    public int HealthScore
    {
        get
        {
            var scored = Checks.Where(c => c.Status != CheckStatus.NotSupported).ToList();
            if (scored.Count == 0) return 100;
            double points = scored.Sum(c => c.Status switch
            {
                CheckStatus.Ok => 1.0,
                CheckStatus.Warning => 0.6,
                CheckStatus.Error => 0.0,
                _ => 1.0
            });
            return (int)Math.Round(points / scored.Count * 100);
        }
    }

    public string HealthLabel => HealthScore >= 90 ? "HEALTHY"
        : HealthScore >= 70 ? "GOOD"
        : HealthScore >= 40 ? "WARNING"
        : "CRITICAL";
}

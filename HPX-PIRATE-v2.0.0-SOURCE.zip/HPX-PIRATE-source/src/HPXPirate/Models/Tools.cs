namespace HPXPirate.Models;

/// <summary>Priority tier for a toolbox tool. Core tools are always safe and useful.</summary>
public enum ToolTier { Core, Advanced, Experimental }

/// <summary>Honest readiness label shown on each tool card.</summary>
public enum ToolReadiness { Functional, RequiresAdmin, NotSupported }

/// <summary>Definition of a single tool in the HPX PIRATE Toolbox.</summary>
public sealed class ToolDefinition
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Icon { get; set; } = "\uE9D9"; // Segoe MDL2 default
    public string Category { get; set; } = "General";
    public ToolTier Tier { get; set; } = ToolTier.Core;

    /// <summary>Navigation key used by the shell to open the tool's view.</summary>
    public string ViewKey { get; set; } = "";

    public bool Favorite { get; set; }

    public ToolReadiness Readiness { get; set; } = ToolReadiness.Functional;

    public string ReadinessLabel => Readiness switch
    {
        ToolReadiness.Functional => "FUNCTIONAL",
        ToolReadiness.RequiresAdmin => "REQUIRES ADMIN",
        _ => "NOT SUPPORTED"
    };

    public string TierLabel => Tier switch
    {
        ToolTier.Core => "CORE",
        ToolTier.Advanced => "ADVANCED",
        _ => "EXPERIMENTAL"
    };
}

/// <summary>Persisted toolbox state (favorites + recent ordering).</summary>
public sealed class ToolboxState
{
    public List<string> Favorites { get; set; } = new();
    public List<string> Recent { get; set; } = new();
}

namespace HPXPirate.Models;

public enum InputDeviceKind { Keyboard, Mouse, Touch, Controller }

/// <summary>A single observed input event with a real timestamp (monotonic ms).</summary>
public sealed class InputEventRecord
{
    public double TimeMs { get; set; }
    public InputDeviceKind Device { get; set; }
    public string Name { get; set; } = "";
    public bool Down { get; set; }
    public string Detail { get; set; } = "";
}

/// <summary>Latency statistics computed from actual samples — never fabricated.</summary>
public sealed class LatencyStats
{
    public string Label { get; set; } = "";
    public List<double> Samples { get; set; } = new();

    public bool HasData => Samples.Count > 0;
    public double Average => HasData ? Samples.Average() : 0;
    public double Minimum => HasData ? Samples.Min() : 0;
    public double Maximum => HasData ? Samples.Max() : 0;

    public double P95
    {
        get
        {
            if (!HasData) return 0;
            var sorted = Samples.OrderBy(x => x).ToList();
            int idx = (int)Math.Ceiling(0.95 * sorted.Count) - 1;
            return sorted[Math.Clamp(idx, 0, sorted.Count - 1)];
        }
    }

    public double StdDev
    {
        get
        {
            if (Samples.Count < 2) return 0;
            double avg = Average;
            return Math.Sqrt(Samples.Sum(s => (s - avg) * (s - avg)) / (Samples.Count - 1));
        }
    }
}

/// <summary>One measured keyboard/mouse/controller key state for the live monitor.</summary>
public sealed class KeyStateModel
{
    public string Key { get; set; } = "";
    public bool Pressed { get; set; }
    public double LastChangeMs { get; set; }
}

/// <summary>Result of a sensitivity test run (tap/drag/swipe/circular).</summary>
public sealed class SensitivityTestResult
{
    public string Mode { get; set; } = "Drag";
    public double DistancePx { get; set; }
    public double DurationMs { get; set; }
    public double SpeedPxPerSec { get; set; }
    public double Acceleration { get; set; }
    public double Consistency { get; set; } // 0..100
    public double LatencyMs { get; set; }
    public int SampleCount { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.Now;

    public bool HasData => SampleCount > 0;
    public string Summary => $"{Mode}: {DistancePx:0} px in {DurationMs:0} ms ({SpeedPxPerSec:0} px/s)";
}

/// <summary>A named, persisted tool result so the user can review/compare history.</summary>
public sealed class ToolResult
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string ToolId { get; set; } = "";
    public string Title { get; set; } = "";
    public string Summary { get; set; } = "";
    public DateTime Timestamp { get; set; } = DateTime.Now;
    public Dictionary<string, string> Fields { get; set; } = new();
}
